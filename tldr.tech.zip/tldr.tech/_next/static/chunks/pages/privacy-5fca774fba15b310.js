(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8915], {
        93027: function(e, t, o) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/privacy", function() {
                return o(39405)
            }])
        },
        39405: function(e, t, o) {
            "use strict";
            o.r(t), o.d(t, {
                default: function() {
                    return a
                }
            });
            var s = o(85893),
                i = o(9008),
                r = o.n(i),
                n = o(5005);

            function a() {
                let e = "TLDR Newsletter - A Byte Sized Daily Tech Newsletter",
                    t = "TLDR is a daily newsletter with links and TLDRs of the most interesting stories in startups, tech and programming!";
                return (0, s.jsxs)("div", {
                    children: [(0, s.jsxs)(r(), {
                        children: [(0, s.jsx)(n.w7, {}), (0, s.jsx)("title", {
                            children: e
                        }), (0, s.jsx)("meta", {
                            property: "og:title",
                            content: e
                        }), (0, s.jsx)("meta", {
                            name: "description",
                            content: t
                        }), (0, s.jsx)("meta", {
                            property: "og:description",
                            content: t
                        })]
                    }), (0, s.jsx)(n.W_, {}), (0, s.jsx)("div", {
                        className: "flex justify-center h-screen",
                        children: (0, s.jsxs)("div", {
                            className: "content-center max-w-xl mt-5",
                            children: [(0, s.jsx)("h3", {
                                className: "mt-5 text-center",
                                children: "TLDR Privacy Policy"
                            }), (0, s.jsxs)("div", {
                                className: "pb-5 pl-5 pr-5 pt-3",
                                children: [(0, s.jsx)("p", {
                                    children: "TLDR is determined to protect and maintain your privacy. We are privileged to be trusted with your personal information and do not wish to jeopardize that trust."
                                }), (0, s.jsx)("p", {
                                    children: "However, in order to use some of our services, it’s necessary for you to give us details such as your email address."
                                }), (0, s.jsx)("p", {
                                    children: "Please note that we do NOT store credit/debit card numbers, nor do we share customer details with any 3rd parties."
                                }), (0, s.jsx)("p", {
                                    children: "This document explains how and why we collect information from our users, how we use it, and how you can access or change it. This document does not cover third-party sites we link to or which link to us. Those sites should have their own privacy policies."
                                }), (0, s.jsxs)("p", {
                                    children: ["If you have any problem with this policy or wish to ask questions, please contact me at ", (0, s.jsx)("a", {
                                        href: "mailto:dan@tldr.tech",
                                        children: "dan@tldr.tech"
                                    }), "."]
                                }), (0, s.jsx)("h3", {
                                    className: "mt-3",
                                    children: "What Information We Collect"
                                }), (0, s.jsx)("p", {
                                    children: "On our site, there are pages where you will be requested to enter your email address in order to receive specific benefits of information in response."
                                }), (0, s.jsx)("p", {
                                    children: "We also may use cookies on our site(s) in order to track your particular ‘session’ on our site. This is not used for contextual advertising purposes and, in general, is not directly traceable to you."
                                }), (0, s.jsx)("p", {
                                    children: "We use Google Analytics on our site in order to track the number of visitors, how those visitors came to our site, and which pages those visitors visit on our site. This is all handled under Google’s privacy policy."
                                }), (0, s.jsx)("h3", {
                                    className: "mt-3",
                                    children: "What We Do With Your Information"
                                }), (0, s.jsx)("p", {
                                    children: "We may use your information in order to track your relationship with us and our site as well as to send you emails about information you have requested or other information or promotions specifically relevant to TLDR and its activities. Essentially, your data will only be used for the specific purposes for which it was collected (as per the Data Protection Act 1998 (UK))."
                                }), (0, s.jsx)("p", {
                                    children: "We may, occasionally, send surveys or even direct one-to-one mail in order to manage our customer service processes."
                                }), (0, s.jsx)("p", {
                                    children: "We do NOT share your information with third parties, we do NOT share your email addresses with sponsors or any third parties, and we do NOT run exclusive ‘sponsored’ emails on behalf of third parties. We may, however, have sponsors or advertisers for emails you would otherwise be choosing to receive but will not send mails specifically for the purpose of advertising third parties or their products."
                                }), (0, s.jsx)("p", {
                                    children: "Information will not be disclosed to other parties without the consent of the individual whom it is about, unless there is legislation or other overriding legitimate reason to share the information (for example, the prevention or detection of crime)."
                                }), (0, s.jsx)("h3", {
                                    className: "mt-3",
                                    children: "Acquisition of TLDR Assets"
                                }), (0, s.jsx)("p", {
                                    children: "In the case that TLDR or its assets are acquired by another company, the privacy policies of those other companies will apply to the information referenced herein."
                                }), (0, s.jsx)("h3", {
                                    className: "mt-3",
                                    children: "COPPA – Children’s Online Privacy Protection Act (USA)"
                                }), (0, s.jsx)("p", {
                                    children: "We do not and will not knowingly collect or store information on sites we control about children who are under the age of 13. Our sites are also not targeted or designed to attract children under the age of 13. If you feel a child under the age of 13 may be listed in our databases, please contact us immediately."
                                }), (0, s.jsx)("h3", {
                                    className: "mt-3",
                                    children: "Access To Information We Store About You"
                                }), (0, s.jsx)("p", {
                                    children: "As per the Data Protection Act 1998 (UK), you are able to ask us to send you all of the information we hold about you (subject to certain legal limitations). To do this, please use the email address below and provide any information we may need in order to locate information we store about you."
                                }), (0, s.jsx)("h3", {
                                    className: "mt-3",
                                    children: "Any Questions?"
                                }), (0, s.jsxs)("p", {
                                    children: ["If you have questions or suggestions, please email me at", " ", (0, s.jsx)("a", {
                                        href: "mailto:dan@tldr.tech",
                                        children: "dan@tldr.tech."
                                    })]
                                })]
                            })]
                        })
                    })]
                })
            }
        }
    },
    function(e) {
        e.O(0, [5445, 6586, 794, 1755, 2900, 3029, 4889, 5005, 9774, 2888, 179], function() {
            return e(e.s = 93027)
        }), _N_E = e.O()
    }
]);