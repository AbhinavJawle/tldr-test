(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5405], {
        48312: function(e, t, s) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/", function() {
                return s(14186)
            }])
        },
        14186: function(e, t, s) {
            "use strict";
            s.r(t), s.d(t, {
                default: function() {
                    return r
                }
            });
            var n = s(85893),
                i = s(5005);

            function r() {
                return (0, n.jsxs)(i.U8, {
                    title: "TLDR Newsletter - A Byte Sized Daily Tech Newsletter",
                    description: "TLDR is the free daily newsletter with the most interesting stories in startups, tech and programming!",
                    footerLinks: [{
                        text: "Privacy",
                        href: "/privacy"
                    }, {
                        text: "Advertise",
                        href: "/tech/advertise"
                    }],
                    children: [(0, n.jsxs)("div", {
                        className: "flex justify-center",
                        children: [(0, n.jsx)("span", {
                            className: "floating text-3xl md:text-4xl",
                            children: "\uD83E\uDDEC"
                        }), (0, n.jsx)("span", {
                            className: "floating2 text-3xl md:text-4xl",
                            children: "\uD83E\uDD16"
                        }), (0, n.jsx)("span", {
                            className: "floating3 text-3xl md:text-4xl",
                            children: "\uD83D\uDC68‍\uD83D\uDCBB"
                        }), (0, n.jsx)("span", {
                            className: "floating4 text-3xl md:text-4xl",
                            children: "\uD83D\uDCF1"
                        }), (0, n.jsx)("span", {
                            className: "floating5 text-3xl md:text-4xl",
                            children: "\uD83D\uDE80"
                        })]
                    }), (0, n.jsx)("h1", {
                        className: "mt-3 text-center text-glow text-3xl md:text-5xl",
                        children: "TLDR"
                    }), (0, n.jsx)("div", {
                        className: "text-center text-lg",
                        children: "Byte sized news for busy techies"
                    }), (0, n.jsx)(i.v5, {
                        description: "TLDR is the free daily newsletter with links and TLDRs of the most interesting stories in startups \uD83D\uDE80, tech \uD83D\uDCF1, and programming \uD83D\uDCBB!",
                        newsletter: "tech",
                        readers: "750,000",
                        focus: !0
                    })]
                })
            }
        }
    },
    function(e) {
        e.O(0, [5445, 6586, 794, 1755, 2900, 3029, 4889, 5005, 9774, 2888, 179], function() {
            return e(e.s = 48312)
        }), _N_E = e.O()
    }
]);