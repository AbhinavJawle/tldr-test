(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [629], {
        51464: function(e, t, s) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/tech/advertise", function() {
                return s(25268)
            }])
        },
        25268: function(e, t, s) {
            "use strict";
            s.r(t), s.d(t, {
                default: function() {
                    return h
                }
            });
            var a = s(85893),
                i = s(9008),
                r = s.n(i),
                l = s(25675),
                n = s.n(l),
                c = s(11163),
                o = s.n(c),
                d = s(5005);

            function h() {
                let e = "Advertise With TLDR Newsletter",
                    t = "Advertise with TLDR Newsletter, a daily curated tech and programming newsletter with over ".concat("750,000", " subscribers."),
                    s = (0, c.useRouter)();
                s.query.email;
                let i = async e => {
                    e.preventDefault(), o().push("https://danni763618.typeform.com/to/K4Gdz1")
                };
                return (0, a.jsxs)("div", {
                    children: [(0, a.jsxs)(r(), {
                        children: [(0, a.jsx)(d.w7, {}), (0, a.jsx)("title", {
                            children: e
                        }), (0, a.jsx)("meta", {
                            property: "og:title",
                            content: e
                        }), (0, a.jsx)("meta", {
                            name: "description",
                            content: t
                        }), (0, a.jsx)("meta", {
                            property: "og:description",
                            content: t
                        })]
                    }), (0, a.jsx)(d.W_, {}), (0, a.jsx)("div", {
                        className: "flex flex-row min-h-screen justify-center sm:px-8 md:px-16 lg:px-24 max-width-xl",
                        children: (0, a.jsxs)("div", {
                            className: "content-center max-w-xl mt-5 p-3",
                            children: [(0, a.jsx)("h1", {
                                className: "text-center text-lg font-bold text-center",
                                children: e
                            }), (0, a.jsxs)("div", {
                                className: "mt-3",
                                children: ["TLDR is a daily newsletter read by over ", "750,000", " ", "software engineers, tech executives and decisionmakers, and other tech employees."]
                            }), (0, a.jsx)("div", {
                                className: "mt-3",
                                children: "It is the ideal place to advertise B2B SaaS, developer tools, fintech, cybersecurity, tech jobs, tech conferences and other products designed for a tech-savvy audience."
                            }), (0, a.jsxs)("div", {
                                className: "mt-5",
                                children: [(0, a.jsxs)("div", {
                                    className: "grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-0 mt-0 md:mt-3",
                                    children: [(0, a.jsx)("div", {
                                        className: "flex justify-self-center self-center",
                                        children: (0, a.jsx)(n(), {
                                            alt: "aws-logo",
                                            src: "/aws.png",
                                            className: "object-center white-logo",
                                            width: 125,
                                            height: 125
                                        })
                                    }), (0, a.jsx)("div", {
                                        className: "flex justify-self-center self-center",
                                        children: (0, a.jsx)(n(), {
                                            alt: "azure-logo",
                                            src: "/azure.png",
                                            className: "mt-1 white-logo",
                                            width: 125,
                                            height: 50
                                        })
                                    }), (0, a.jsx)("div", {
                                        className: "flex justify-self-center self-center",
                                        children: (0, a.jsx)(n(), {
                                            alt: "datadog-logo",
                                            src: "/datadog.png",
                                            className: "mt-2 white-logo",
                                            width: 125,
                                            height: 125
                                        })
                                    }), (0, a.jsx)("div", {
                                        className: "flex justify-self-center self-center",
                                        children: (0, a.jsx)(n(), {
                                            alt: "splunk-logo",
                                            src: "/splunk.png",
                                            className: "mt-2 white-logo",
                                            width: 125,
                                            height: 125
                                        })
                                    })]
                                }), (0, a.jsxs)("div", {
                                    className: "grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-0 mt-3",
                                    children: [(0, a.jsx)("div", {
                                        className: "flex justify-self-center self-center",
                                        children: (0, a.jsx)(n(), {
                                            alt: "cloudflare-logo",
                                            src: "/cloudflare.png",
                                            className: "white-logo",
                                            width: 125,
                                            height: 125
                                        })
                                    }), (0, a.jsx)("div", {
                                        className: "flex justify-self-center self-center",
                                        children: (0, a.jsx)(n(), {
                                            alt: "ramp-logo",
                                            src: "/ramp.png",
                                            className: "mt-2 white-logo",
                                            width: 125,
                                            height: 125
                                        })
                                    }), (0, a.jsx)("div", {
                                        className: "flex justify-self-center self-center",
                                        children: (0, a.jsx)(n(), {
                                            alt: "retool-logo",
                                            src: "/retool.png",
                                            className: "mt-2 white-logo",
                                            width: 125,
                                            height: 125
                                        })
                                    }), (0, a.jsx)("div", {
                                        className: "flex justify-self-center self-center",
                                        children: (0, a.jsx)(n(), {
                                            alt: "loom-logo",
                                            src: "/loom.png",
                                            className: "mt-2 white-logo",
                                            width: 125,
                                            height: 125
                                        })
                                    })]
                                })]
                            }), (0, a.jsxs)("div", {
                                className: "mt-5 text-sm",
                                children: [(0, a.jsx)("div", {
                                    className: "italic mt-5",
                                    children: '"TLDR helps us reach C-level executives, VPs, and other high-level decision makers within our ideal customer profile. The team has been an absolute pleasure to work with, and we’ve been able to prove a solid ROI for the partnership."'
                                }), (0, a.jsx)("div", {
                                    children: "Pinja Dodik, Marketing Manager at Swarmia"
                                }), (0, a.jsx)("div", {
                                    className: "italic mt-5",
                                    children: '"TLDR has been a cornerstone of Modern Treasury’s developer marketing strategy. It’s easily been our most efficient way of reaching a large and highly technical audience, both in terms of time and ROI. Dan and his team are a pleasure to work with and they really help you craft promotional material that resonates well with technical audiences."'
                                }), (0, a.jsx)("div", {
                                    children: "Rishub Nahar, Growth Marketer at Modern Treasury"
                                }), (0, a.jsx)("div", {
                                    className: "italic mt-5",
                                    children: '"TLDR\'s audience has been great for Hired because we are reaching the high quality candidates our employer partners are looking for in a cost-effective manner. Working with the TLDR team has been very easy and insightful."'
                                }), (0, a.jsx)("div", {
                                    children: "Vim Chand, Growth Marketing Manager at Hired"
                                })]
                            }), (0, a.jsx)("div", {
                                className: "flex justify-center mt-5",
                                children: (0, a.jsx)(d.zx, {
                                    className: "h-8 min-w-[80%] w-9/12 mt-2 md:min-w-0 md:mt-0 md:w-fit",
                                    onClick: i,
                                    children: "Advertise with TLDR"
                                })
                            })]
                        })
                    })]
                })
            }
        }
    },
    function(e) {
        e.O(0, [5445, 6586, 794, 1755, 2900, 3029, 4889, 5005, 9774, 2888, 179], function() {
            return e(e.s = 51464)
        }), _N_E = e.O()
    }
]);