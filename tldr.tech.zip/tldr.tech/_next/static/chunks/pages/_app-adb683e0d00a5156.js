(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2888], {
        57542: function(e, t, r) {
            "use strict";
            var i = Object.defineProperty,
                s = Object.getOwnPropertyDescriptor,
                n = Object.getOwnPropertyNames,
                o = Object.prototype.hasOwnProperty,
                a = {};
            ((e, t) => {
                for (var r in t) i(e, r, {
                    get: t[r],
                    enumerable: !0
                })
            })(a, {
                createBrowserSupabaseClient: () => _,
                createMiddlewareSupabaseClient: () => E,
                createServerComponentSupabaseClient: () => S,
                createServerSupabaseClient: () => k,
                logger: () => w,
                withApiAuth: () => y,
                withMiddlewareAuth: () => p,
                withPageAuth: () => m
            }), e.exports = ((e, t, r, a) => {
                if (t && "object" == typeof t || "function" == typeof t)
                    for (let l of n(t)) o.call(e, l) || void 0 === l || i(e, l, {
                        get: () => t[l],
                        enumerable: !(a = s(t, l)) || a.enumerable
                    });
                return e
            })(i({}, "__esModule", {
                value: !0
            }), a);
            var l = r(96961),
                u = "@supabase/auth-helpers-nextjs",
                h = "0.5.2",
                c = r(97385),
                d = r(96961),
                f = class extends Error {
                    constructor(e) {
                        super(e), this.name = "NoPermissionError"
                    }
                },
                p = (e = {}) => async t => {
                    var r;
                    try {
                        let i = c.NextResponse.next(),
                            s = (0, d.createServerSupabaseClient)({
                                supabaseUrl: "https://jwwrbzsvyukwfpbuimxf.supabase.co",
                                supabaseKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3d3JienN2eXVrd2ZwYnVpbXhmIiwicm9sZSI6ImFub24iLCJpYXQiOjE2Njc0MTMwNjcsImV4cCI6MTk4Mjk4OTA2N30.qDCRabW7g-uIEgLPijOIjMWc3_GhfFn_fopYNbtp13I",
                                getCookie(e) {
                                    var r;
                                    let i = (0, d.parseCookies)(null != (r = t.headers.get("cookie")) ? r : "");
                                    return i[e]
                                },
                                setCookie(e, t, r) {
                                    let s = (0, d.serializeCookie)(e, t, { ...r,
                                        httpOnly: !1
                                    });
                                    i.headers.append(e, s)
                                },
                                getRequestHeader(e) {
                                    var r;
                                    let i = null != (r = t.headers.get(e)) ? r : void 0;
                                    return i
                                },
                                options: {
                                    global: {
                                        headers: {
                                            "X-Client-Info": `${u}@${h}`
                                        }
                                    }
                                },
                                cookieOptions: e.cookieOptions
                            }),
                            {
                                data: {
                                    session: n
                                },
                                error: o
                            } = await s.auth.getSession();
                        if (o) throw Error(`Authorization error, redirecting to login page: ${o.message}`);
                        if (n) {
                            if (e.authGuard && !await e.authGuard.isPermitted(n.user, s)) throw new f("User is not permitted, redirecting")
                        } else throw Error("No auth session, redirecting");
                        return i
                    } catch (p) {
                        let {
                            redirectTo: a = "/"
                        } = e;
                        p instanceof f && (null == (r = null == e ? void 0 : e.authGuard) ? void 0 : r.redirectTo) && (a = e.authGuard.redirectTo), p instanceof Error && console.log(`Could not authenticate request, redirecting to ${a}:`, p);
                        let l = t.nextUrl.clone();
                        return l.pathname = a, l.searchParams.set("redirectedFrom", t.nextUrl.pathname), c.NextResponse.redirect(l)
                    }
                },
                g = r(96961);

            function m({
                authRequired: e = !0,
                redirectTo: t = "/",
                getServerSideProps: r,
                cookieOptions: i = {}
            } = {}) {
                return async s => {
                    var n;
                    try {
                        if (!s.req.cookies) throw new g.CookieNotParsed;
                        let o = (0, g.createServerSupabaseClient)({
                                supabaseUrl: "https://jwwrbzsvyukwfpbuimxf.supabase.co",
                                supabaseKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3d3JienN2eXVrd2ZwYnVpbXhmIiwicm9sZSI6ImFub24iLCJpYXQiOjE2Njc0MTMwNjcsImV4cCI6MTk4Mjk4OTA2N30.qDCRabW7g-uIEgLPijOIjMWc3_GhfFn_fopYNbtp13I",
                                getRequestHeader: e => s.req.headers[e],
                                getCookie: e => s.req.cookies[e],
                                setCookie(e, t, r) {
                                    var i, n;
                                    let o = (0, g.filterCookies)((0, g.ensureArray)(null != (n = null == (i = s.res.getHeader("set-cookie")) ? void 0 : i.toString()) ? n : []), e),
                                        a = (0, g.serializeCookie)(e, t, { ...r,
                                            httpOnly: !1
                                        });
                                    s.res.setHeader("set-cookie", [...o, a])
                                },
                                options: {
                                    global: {
                                        headers: {
                                            "X-Client-Info": `${u}@${h}`
                                        }
                                    }
                                },
                                cookieOptions: i
                            }),
                            {
                                data: {
                                    session: a
                                },
                                error: l
                            } = await o.auth.getSession();
                        if (l) throw l;
                        if (e && !a) throw new g.AuthHelperError("Unauthenticated", "unauthenticated");
                        let c = {
                            props: {}
                        };
                        if (r) try {
                            c = await r(s, o)
                        } catch (d) {
                            c = {
                                props: {
                                    error: String(d)
                                }
                            }
                        }
                        return { ...c,
                            props: {
                                initialSession: a,
                                user: null != (n = null == a ? void 0 : a.user) ? n : null,
                                ...c.props
                            }
                        }
                    } catch (f) {
                        if (e) return {
                            redirect: {
                                destination: t,
                                permanent: !1
                            }
                        };
                        return {
                            props: {}
                        }
                    }
                }
            }
            var v = r(96961);

            function y(e, t = {}) {
                return async (r, i) => {
                    try {
                        let s = (0, v.createServerSupabaseClient)({
                                supabaseUrl: "https://jwwrbzsvyukwfpbuimxf.supabase.co",
                                supabaseKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3d3JienN2eXVrd2ZwYnVpbXhmIiwicm9sZSI6ImFub24iLCJpYXQiOjE2Njc0MTMwNjcsImV4cCI6MTk4Mjk4OTA2N30.qDCRabW7g-uIEgLPijOIjMWc3_GhfFn_fopYNbtp13I",
                                getCookie: e => r.cookies[e],
                                setCookie(e, t, r) {
                                    var s, n;
                                    let o = (0, v.filterCookies)((0, v.ensureArray)(null != (n = null == (s = i.getHeader("set-cookie")) ? void 0 : s.toString()) ? n : []), e),
                                        a = (0, v.serializeCookie)(e, t, { ...r,
                                            httpOnly: !1
                                        });
                                    i.setHeader("set-cookie", [...o, a])
                                },
                                getRequestHeader(e) {
                                    let t = r.headers[e];
                                    return "number" == typeof t ? String(t) : t
                                },
                                options: {
                                    global: {
                                        headers: {
                                            "X-Client-Info": `${u}@${h}`
                                        }
                                    }
                                },
                                cookieOptions: t.cookieOptions
                            }),
                            {
                                data: {
                                    session: n
                                },
                                error: o
                            } = await s.auth.getSession();
                        if (o) throw o;
                        if (!n) throw new v.AuthHelperError("Unauthenticated", "unauthenticated");
                        try {
                            await e(r, i, s)
                        } catch (a) {
                            i.status(500).json({
                                error: String(a)
                            });
                            return
                        }
                    } catch (l) {
                        i.status(401).json({
                            error: "not_authenticated",
                            description: "The user does not have an active session or is not authenticated"
                        });
                        return
                    }
                }
            }
            var b = {
                    log(e, ...t) {},
                    error(e, ...t) {
                        console.error(e, ...t)
                    },
                    info(e, ...t) {
                        b.log(e, ...t)
                    },
                    debug(e, ...t) {
                        b.log(e, ...t)
                    },
                    warn(e, ...t) {}
                },
                w = b;

            function _({
                cookieOptions: e
            } = {}) {
                return (0, l.createBrowserSupabaseClient)({
                    supabaseUrl: "https://jwwrbzsvyukwfpbuimxf.supabase.co",
                    supabaseKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3d3JienN2eXVrd2ZwYnVpbXhmIiwicm9sZSI6ImFub24iLCJpYXQiOjE2Njc0MTMwNjcsImV4cCI6MTk4Mjk4OTA2N30.qDCRabW7g-uIEgLPijOIjMWc3_GhfFn_fopYNbtp13I",
                    cookieOptions: e
                })
            }

            function k(e, {
                cookieOptions: t
            } = {}) {
                return (0, l.createServerSupabaseClient)({
                    supabaseUrl: "https://jwwrbzsvyukwfpbuimxf.supabase.co",
                    supabaseKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3d3JienN2eXVrd2ZwYnVpbXhmIiwicm9sZSI6ImFub24iLCJpYXQiOjE2Njc0MTMwNjcsImV4cCI6MTk4Mjk4OTA2N30.qDCRabW7g-uIEgLPijOIjMWc3_GhfFn_fopYNbtp13I",
                    getRequestHeader: t => e.req.headers[t],
                    getCookie: t => e.req.cookies[t],
                    setCookie(t, r, i) {
                        var s, n;
                        let o = (0, l.filterCookies)((0, l.ensureArray)(null != (n = null == (s = e.res.getHeader("set-cookie")) ? void 0 : s.toString()) ? n : []), t),
                            a = (0, l.serializeCookie)(t, r, { ...i,
                                httpOnly: !1
                            });
                        e.res.setHeader("set-cookie", [...o, a])
                    },
                    options: {
                        global: {
                            headers: {
                                "X-Client-Info": `${u}@${h}`
                            }
                        }
                    },
                    cookieOptions: t
                })
            }

            function E(e, {
                cookieOptions: t
            } = {}) {
                return (0, l.createServerSupabaseClient)({
                    supabaseUrl: "https://jwwrbzsvyukwfpbuimxf.supabase.co",
                    supabaseKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3d3JienN2eXVrd2ZwYnVpbXhmIiwicm9sZSI6ImFub24iLCJpYXQiOjE2Njc0MTMwNjcsImV4cCI6MTk4Mjk4OTA2N30.qDCRabW7g-uIEgLPijOIjMWc3_GhfFn_fopYNbtp13I",
                    getCookie(t) {
                        var r;
                        let i = (0, l.parseCookies)(null != (r = e.req.headers.get("cookie")) ? r : "");
                        return i[t]
                    },
                    setCookie(t, r, i) {
                        let s = (0, l.serializeCookie)(t, r, { ...i,
                            httpOnly: !1
                        });
                        e.req.headers.append("cookie", s), e.res.headers.set("set-cookie", s)
                    },
                    getRequestHeader(t) {
                        var r;
                        let i = null != (r = e.req.headers.get(t)) ? r : void 0;
                        return i
                    },
                    options: {
                        global: {
                            headers: {
                                "X-Client-Info": `${u}@${h}`
                            }
                        }
                    },
                    cookieOptions: t
                })
            }

            function S({
                headers: e,
                cookies: t,
                cookieOptions: r
            }) {
                return (0, l.createServerSupabaseClient)({
                    supabaseUrl: "https://jwwrbzsvyukwfpbuimxf.supabase.co",
                    supabaseKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3d3JienN2eXVrd2ZwYnVpbXhmIiwicm9sZSI6ImFub24iLCJpYXQiOjE2Njc0MTMwNjcsImV4cCI6MTk4Mjk4OTA2N30.qDCRabW7g-uIEgLPijOIjMWc3_GhfFn_fopYNbtp13I",
                    getRequestHeader(t) {
                        let r = e();
                        return r.get(t)
                    },
                    getCookie(e) {
                        var r;
                        let i = t();
                        return null == (r = i.get(e)) ? void 0 : r.value
                    },
                    setCookie() {},
                    options: {
                        global: {
                            headers: {
                                "X-Client-Info": `${u}@${h}`
                            }
                        }
                    },
                    cookieOptions: r
                })
            }
        },
        84053: function(e, t, r) {
            var i, s, n = Object.create,
                o = Object.defineProperty,
                a = Object.getOwnPropertyDescriptor,
                l = Object.getOwnPropertyNames,
                u = Object.getPrototypeOf,
                h = Object.prototype.hasOwnProperty,
                c = (e, t, r, i) => {
                    if (t && "object" == typeof t || "function" == typeof t)
                        for (let s of l(t)) h.call(e, s) || s === r || o(e, s, {
                            get: () => t[s],
                            enumerable: !(i = a(t, s)) || i.enumerable
                        });
                    return e
                },
                d = {};
            ((e, t) => {
                for (var r in t) o(e, r, {
                    get: t[r],
                    enumerable: !0
                })
            })(d, {
                SessionContextProvider: () => g,
                useSession: () => y,
                useSessionContext: () => m,
                useSupabaseClient: () => v,
                useUser: () => b
            }), e.exports = c(o({}, "__esModule", {
                value: !0
            }), d);
            var f = (s = null != (i = r(67294)) ? n(u(i)) : {}, c(i && i.__esModule ? s : o(s, "default", {
                    value: i,
                    enumerable: !0
                }), i)),
                p = (0, f.createContext)({
                    isLoading: !0,
                    session: null,
                    error: null,
                    supabaseClient: {}
                }),
                g = ({
                    supabaseClient: e,
                    initialSession: t = null,
                    children: r
                }) => {
                    let [i, s] = (0, f.useState)(t), [n, o] = (0, f.useState)(!t), [a, l] = (0, f.useState)();
                    (0, f.useEffect)(() => {
                        (async function() {
                            let {
                                data: {
                                    session: t
                                },
                                error: r
                            } = await e.auth.getSession();
                            if (r) {
                                l(r), o(!1);
                                return
                            }
                            s(t), o(!1)
                        })()
                    }, []), (0, f.useEffect)(() => {
                        let {
                            data: {
                                subscription: t
                            }
                        } = e.auth.onAuthStateChange((e, t) => {
                            t && ("SIGNED_IN" === e || "TOKEN_REFRESHED" === e) && s(t), "SIGNED_OUT" === e && s(null)
                        });
                        return () => {
                            t.unsubscribe()
                        }
                    }, []);
                    let u = (0, f.useMemo)(() => n ? {
                        isLoading: !0,
                        session: null,
                        error: null,
                        supabaseClient: e
                    } : a ? {
                        isLoading: !1,
                        session: null,
                        error: a,
                        supabaseClient: e
                    } : {
                        isLoading: !1,
                        session: i,
                        error: null,
                        supabaseClient: e
                    }, [n, i, a]);
                    return f.default.createElement(p.Provider, {
                        value: u
                    }, r)
                },
                m = () => {
                    let e = (0, f.useContext)(p);
                    if (void 0 === e) throw Error("useSessionContext must be used within a SessionContextProvider.");
                    return e
                };

            function v() {
                let e = (0, f.useContext)(p);
                if (void 0 === e) throw Error("useSupabaseClient must be used within a SessionContextProvider.");
                return e.supabaseClient
            }
            var y = () => {
                    let e = (0, f.useContext)(p);
                    if (void 0 === e) throw Error("useSession must be used within a SessionContextProvider.");
                    return e.session
                },
                b = () => {
                    var e, t;
                    let r = (0, f.useContext)(p);
                    if (void 0 === r) throw Error("useUser must be used within a SessionContextProvider.");
                    return null != (t = null == (e = r.session) ? void 0 : e.user) ? t : null
                }
        },
        49802: function(e, t, r) {
            "use strict";
            r.r(t), r.d(t, {
                AuthApiError: function() {
                    return eF
                },
                AuthError: function() {
                    return eM
                },
                AuthImplicitGrantRedirectError: function() {
                    return eG
                },
                AuthInvalidCredentialsError: function() {
                    return eY
                },
                AuthRetryableFetchError: function() {
                    return eV
                },
                AuthSessionMissingError: function() {
                    return eH
                },
                AuthUnknownError: function() {
                    return ez
                },
                CustomAuthError: function() {
                    return eq
                },
                FunctionsError: function() {
                    return s
                },
                FunctionsFetchError: function() {
                    return n
                },
                FunctionsHttpError: function() {
                    return a
                },
                FunctionsRelayError: function() {
                    return o
                },
                GoTrueAdminApi: function() {
                    return e9
                },
                GoTrueClient: function() {
                    return ti
                },
                REALTIME_LISTEN_TYPES: function() {
                    return v
                },
                REALTIME_POSTGRES_CHANGES_LISTEN_EVENT: function() {
                    return m
                },
                REALTIME_PRESENCE_LISTEN_EVENTS: function() {
                    return p
                },
                REALTIME_SUBSCRIBE_STATES: function() {
                    return y
                },
                RealtimeChannel: function() {
                    return Z
                },
                RealtimeClient: function() {
                    return ee
                },
                RealtimePresence: function() {
                    return F
                },
                SupabaseClient: function() {
                    return tu
                },
                createClient: function() {
                    return th
                },
                isAuthApiError: function() {
                    return eJ
                },
                isAuthError: function() {
                    return eD
                }
            });
            let i = e => {
                let t;
                return t = e || ("undefined" == typeof fetch ? (...e) => {
                    var t, i, s, n;
                    return t = void 0, i = void 0, s = void 0, n = function*() {
                        return yield(yield Promise.resolve().then(r.t.bind(r, 54098, 23))).fetch(...e)
                    }, new(s || (s = Promise))(function(e, r) {
                        function o(e) {
                            try {
                                l(n.next(e))
                            } catch (t) {
                                r(t)
                            }
                        }

                        function a(e) {
                            try {
                                l(n.throw(e))
                            } catch (t) {
                                r(t)
                            }
                        }

                        function l(t) {
                            var r;
                            t.done ? e(t.value) : ((r = t.value) instanceof s ? r : new s(function(e) {
                                e(r)
                            })).then(o, a)
                        }
                        l((n = n.apply(t, i || [])).next())
                    })
                } : fetch), (...e) => t(...e)
            };
            class s extends Error {
                constructor(e, t = "FunctionsError", r) {
                    super(e), super.name = t, this.context = r
                }
            }
            class n extends s {
                constructor(e) {
                    super("Failed to send a request to the Edge Function", "FunctionsFetchError", e)
                }
            }
            class o extends s {
                constructor(e) {
                    super("Relay Error invoking the Edge Function", "FunctionsRelayError", e)
                }
            }
            class a extends s {
                constructor(e) {
                    super("Edge Function returned a non-2xx status code", "FunctionsHttpError", e)
                }
            }
            class l {
                constructor(e, {
                    headers: t = {},
                    customFetch: r
                } = {}) {
                    this.url = e, this.headers = t, this.fetch = i(r)
                }
                setAuth(e) {
                    this.headers.Authorization = `Bearer ${e}`
                }
                invoke(e, t = {}) {
                    var r, i, s, l, u;
                    return i = this, s = void 0, l = void 0, u = function*() {
                        try {
                            let i, s;
                            let {
                                headers: l,
                                body: u
                            } = t, h = {};
                            u && (l && !Object.prototype.hasOwnProperty.call(l, "Content-Type") || !l) && ("undefined" != typeof Blob && u instanceof Blob || u instanceof ArrayBuffer ? (h["Content-Type"] = "application/octet-stream", i = u) : "string" == typeof u ? (h["Content-Type"] = "text/plain", i = u) : "undefined" != typeof FormData && u instanceof FormData ? i = u : (h["Content-Type"] = "application/json", i = JSON.stringify(u)));
                            let c = yield this.fetch(`${this.url}/${e}`, {
                                method: "POST",
                                headers: Object.assign(Object.assign(Object.assign({}, h), this.headers), l),
                                body: i
                            }).catch(e => {
                                throw new n(e)
                            }), d = c.headers.get("x-relay-error");
                            if (d && "true" === d) throw new o(c);
                            if (!c.ok) throw new a(c);
                            let f = (null !== (r = c.headers.get("Content-Type")) && void 0 !== r ? r : "text/plain").split(";")[0].trim();
                            return s = "application/json" === f ? yield c.json(): "application/octet-stream" === f ? yield c.blob(): "multipart/form-data" === f ? yield c.formData(): yield c.text(), {
                                data: s,
                                error: null
                            }
                        } catch (p) {
                            return {
                                data: null,
                                error: p
                            }
                        }
                    }, new(l || (l = Promise))(function(e, t) {
                        function r(e) {
                            try {
                                o(u.next(e))
                            } catch (r) {
                                t(r)
                            }
                        }

                        function n(e) {
                            try {
                                o(u.throw(e))
                            } catch (r) {
                                t(r)
                            }
                        }

                        function o(t) {
                            var i;
                            t.done ? e(t.value) : ((i = t.value) instanceof l ? i : new l(function(e) {
                                e(i)
                            })).then(r, n)
                        }
                        o((u = u.apply(i, s || [])).next())
                    })
                }
            }
            var u, h, c, d, f, p, g, m, v, y, b, w, _, k, E, S, x, T, O, A = r(54098),
                P = r.n(A);
            class C {
                constructor(e) {
                    this.shouldThrowOnError = !1, this.method = e.method, this.url = e.url, this.headers = e.headers, this.schema = e.schema, this.body = e.body, this.shouldThrowOnError = e.shouldThrowOnError, this.signal = e.signal, this.allowEmpty = e.allowEmpty, e.fetch ? this.fetch = e.fetch : "undefined" == typeof fetch ? this.fetch = P() : this.fetch = fetch
                }
                throwOnError() {
                    return this.shouldThrowOnError = !0, this
                }
                then(e, t) {
                    void 0 === this.schema || (["GET", "HEAD"].includes(this.method) ? this.headers["Accept-Profile"] = this.schema : this.headers["Content-Profile"] = this.schema), "GET" !== this.method && "HEAD" !== this.method && (this.headers["Content-Type"] = "application/json");
                    let r = this.fetch,
                        i = r(this.url.toString(), {
                            method: this.method,
                            headers: this.headers,
                            body: JSON.stringify(this.body),
                            signal: this.signal
                        }).then(e => {
                            var t, r, i, s;
                            return t = this, r = void 0, i = void 0, s = function*() {
                                var t, r, i;
                                let s = null,
                                    n = null,
                                    o = null,
                                    a = e.status,
                                    l = e.statusText;
                                if (e.ok) {
                                    if ("HEAD" !== this.method) {
                                        let u = yield e.text();
                                        "" === u || (n = "text/csv" === this.headers.Accept ? u : this.headers.Accept && this.headers.Accept.includes("application/vnd.pgrst.plan+text") ? u : JSON.parse(u))
                                    }
                                    let h = null === (t = this.headers.Prefer) || void 0 === t ? void 0 : t.match(/count=(exact|planned|estimated)/),
                                        c = null === (r = e.headers.get("content-range")) || void 0 === r ? void 0 : r.split("/");
                                    h && c && c.length > 1 && (o = parseInt(c[1]))
                                } else {
                                    let d = yield e.text();
                                    try {
                                        s = JSON.parse(d), Array.isArray(s) && 404 === e.status && (n = [], s = null, a = 200, l = "OK")
                                    } catch (f) {
                                        404 === e.status && "" === d ? (a = 204, l = "No Content") : s = {
                                            message: d
                                        }
                                    }
                                    if (s && this.allowEmpty && (null === (i = null == s ? void 0 : s.details) || void 0 === i ? void 0 : i.includes("Results contain 0 rows")) && (s = null, a = 200, l = "OK"), s && this.shouldThrowOnError) throw s
                                }
                                let p = {
                                    error: s,
                                    data: n,
                                    count: o,
                                    status: a,
                                    statusText: l
                                };
                                return p
                            }, new(i || (i = Promise))(function(e, n) {
                                function o(e) {
                                    try {
                                        l(s.next(e))
                                    } catch (t) {
                                        n(t)
                                    }
                                }

                                function a(e) {
                                    try {
                                        l(s.throw(e))
                                    } catch (t) {
                                        n(t)
                                    }
                                }

                                function l(t) {
                                    var r;
                                    t.done ? e(t.value) : ((r = t.value) instanceof i ? r : new i(function(e) {
                                        e(r)
                                    })).then(o, a)
                                }
                                l((s = s.apply(t, r || [])).next())
                            })
                        });
                    return this.shouldThrowOnError || (i = i.catch(e => ({
                        error: {
                            message: `FetchError: ${e.message}`,
                            details: "",
                            hint: "",
                            code: e.code || ""
                        },
                        data: null,
                        count: null,
                        status: 0,
                        statusText: ""
                    }))), i.then(e, t)
                }
            }
            class j extends C {
                select(e) {
                    let t = !1,
                        r = (null != e ? e : "*").split("").map(e => /\s/.test(e) && !t ? "" : ('"' === e && (t = !t), e)).join("");
                    return this.url.searchParams.set("select", r), this.headers.Prefer && (this.headers.Prefer += ","), this.headers.Prefer += "return=representation", this
                }
                order(e, {
                    ascending: t = !0,
                    nullsFirst: r,
                    foreignTable: i
                } = {}) {
                    let s = i ? `${i}.order` : "order",
                        n = this.url.searchParams.get(s);
                    return this.url.searchParams.set(s, `${n?`${n},`:""}${e}.${t?"asc":"desc"}${void 0===r?"":r?".nullsfirst":".nullslast"}`), this
                }
                limit(e, {
                    foreignTable: t
                } = {}) {
                    let r = void 0 === t ? "limit" : `${t}.limit`;
                    return this.url.searchParams.set(r, `${e}`), this
                }
                range(e, t, {
                    foreignTable: r
                } = {}) {
                    let i = void 0 === r ? "offset" : `${r}.offset`,
                        s = void 0 === r ? "limit" : `${r}.limit`;
                    return this.url.searchParams.set(i, `${e}`), this.url.searchParams.set(s, `${t-e+1}`), this
                }
                abortSignal(e) {
                    return this.signal = e, this
                }
                single() {
                    return this.headers.Accept = "application/vnd.pgrst.object+json", this
                }
                maybeSingle() {
                    return this.headers.Accept = "application/vnd.pgrst.object+json", this.allowEmpty = !0, this
                }
                csv() {
                    return this.headers.Accept = "text/csv", this
                }
                geojson() {
                    return this.headers.Accept = "application/geo+json", this
                }
                explain({
                    analyze: e = !1,
                    verbose: t = !1,
                    settings: r = !1,
                    buffers: i = !1,
                    wal: s = !1,
                    format: n = "text"
                } = {}) {
                    let o = [e ? "analyze" : null, t ? "verbose" : null, r ? "settings" : null, i ? "buffers" : null, s ? "wal" : null].filter(Boolean).join("|"),
                        a = this.headers.Accept;
                    return this.headers.Accept = `application/vnd.pgrst.plan+${n}; for="${a}"; options=${o};`, this
                }
                rollback() {
                    var e;
                    return (null !== (e = this.headers.Prefer) && void 0 !== e ? e : "").trim().length > 0 ? this.headers.Prefer += ",tx=rollback" : this.headers.Prefer = "tx=rollback", this
                }
                returns() {
                    return this
                }
            }
            class R extends j {
                eq(e, t) {
                    return this.url.searchParams.append(e, `eq.${t}`), this
                }
                neq(e, t) {
                    return this.url.searchParams.append(e, `neq.${t}`), this
                }
                gt(e, t) {
                    return this.url.searchParams.append(e, `gt.${t}`), this
                }
                gte(e, t) {
                    return this.url.searchParams.append(e, `gte.${t}`), this
                }
                lt(e, t) {
                    return this.url.searchParams.append(e, `lt.${t}`), this
                }
                lte(e, t) {
                    return this.url.searchParams.append(e, `lte.${t}`), this
                }
                like(e, t) {
                    return this.url.searchParams.append(e, `like.${t}`), this
                }
                ilike(e, t) {
                    return this.url.searchParams.append(e, `ilike.${t}`), this
                }
                is(e, t) {
                    return this.url.searchParams.append(e, `is.${t}`), this
                } in (e, t) {
                    let r = t.map(e => "string" == typeof e && RegExp("[,()]").test(e) ? `"${e}"` : `${e}`).join(",");
                    return this.url.searchParams.append(e, `in.(${r})`), this
                }
                contains(e, t) {
                    return "string" == typeof t ? this.url.searchParams.append(e, `cs.${t}`) : Array.isArray(t) ? this.url.searchParams.append(e, `cs.{${t.join(",")}}`) : this.url.searchParams.append(e, `cs.${JSON.stringify(t)}`), this
                }
                containedBy(e, t) {
                    return "string" == typeof t ? this.url.searchParams.append(e, `cd.${t}`) : Array.isArray(t) ? this.url.searchParams.append(e, `cd.{${t.join(",")}}`) : this.url.searchParams.append(e, `cd.${JSON.stringify(t)}`), this
                }
                rangeGt(e, t) {
                    return this.url.searchParams.append(e, `sr.${t}`), this
                }
                rangeGte(e, t) {
                    return this.url.searchParams.append(e, `nxl.${t}`), this
                }
                rangeLt(e, t) {
                    return this.url.searchParams.append(e, `sl.${t}`), this
                }
                rangeLte(e, t) {
                    return this.url.searchParams.append(e, `nxr.${t}`), this
                }
                rangeAdjacent(e, t) {
                    return this.url.searchParams.append(e, `adj.${t}`), this
                }
                overlaps(e, t) {
                    return "string" == typeof t ? this.url.searchParams.append(e, `ov.${t}`) : this.url.searchParams.append(e, `ov.{${t.join(",")}}`), this
                }
                textSearch(e, t, {
                    config: r,
                    type: i
                } = {}) {
                    let s = "";
                    "plain" === i ? s = "pl" : "phrase" === i ? s = "ph" : "websearch" === i && (s = "w");
                    let n = void 0 === r ? "" : `(${r})`;
                    return this.url.searchParams.append(e, `${s}fts${n}.${t}`), this
                }
                match(e) {
                    return Object.entries(e).forEach(([e, t]) => {
                        this.url.searchParams.append(e, `eq.${t}`)
                    }), this
                }
                not(e, t, r) {
                    return this.url.searchParams.append(e, `not.${t}.${r}`), this
                }
                or(e, {
                    foreignTable: t
                } = {}) {
                    let r = t ? `${t}.or` : "or";
                    return this.url.searchParams.append(r, `(${e})`), this
                }
                filter(e, t, r) {
                    return this.url.searchParams.append(e, `${t}.${r}`), this
                }
            }
            class I {
                constructor(e, {
                    headers: t = {},
                    schema: r,
                    fetch: i
                }) {
                    this.url = e, this.headers = t, this.schema = r, this.fetch = i
                }
                select(e, {
                    head: t = !1,
                    count: r
                } = {}) {
                    let i = !1,
                        s = (null != e ? e : "*").split("").map(e => /\s/.test(e) && !i ? "" : ('"' === e && (i = !i), e)).join("");
                    return this.url.searchParams.set("select", s), r && (this.headers.Prefer = `count=${r}`), new R({
                        method: t ? "HEAD" : "GET",
                        url: this.url,
                        headers: this.headers,
                        schema: this.schema,
                        fetch: this.fetch,
                        allowEmpty: !1
                    })
                }
                insert(e, {
                    count: t
                } = {}) {
                    let r = [];
                    if (t && r.push(`count=${t}`), this.headers.Prefer && r.unshift(this.headers.Prefer), this.headers.Prefer = r.join(","), Array.isArray(e)) {
                        let i = e.reduce((e, t) => e.concat(Object.keys(t)), []);
                        if (i.length > 0) {
                            let s = [...new Set(i)].map(e => `"${e}"`);
                            this.url.searchParams.set("columns", s.join(","))
                        }
                    }
                    return new R({
                        method: "POST",
                        url: this.url,
                        headers: this.headers,
                        schema: this.schema,
                        body: e,
                        fetch: this.fetch,
                        allowEmpty: !1
                    })
                }
                upsert(e, {
                    onConflict: t,
                    ignoreDuplicates: r = !1,
                    count: i
                } = {}) {
                    let s = [`resolution=${r?"ignore":"merge"}-duplicates`];
                    return void 0 !== t && this.url.searchParams.set("on_conflict", t), i && s.push(`count=${i}`), this.headers.Prefer && s.unshift(this.headers.Prefer), this.headers.Prefer = s.join(","), new R({
                        method: "POST",
                        url: this.url,
                        headers: this.headers,
                        schema: this.schema,
                        body: e,
                        fetch: this.fetch,
                        allowEmpty: !1
                    })
                }
                update(e, {
                    count: t
                } = {}) {
                    let r = [];
                    return t && r.push(`count=${t}`), this.headers.Prefer && r.unshift(this.headers.Prefer), this.headers.Prefer = r.join(","), new R({
                        method: "PATCH",
                        url: this.url,
                        headers: this.headers,
                        schema: this.schema,
                        body: e,
                        fetch: this.fetch,
                        allowEmpty: !1
                    })
                }
                delete({
                    count: e
                } = {}) {
                    let t = [];
                    return e && t.push(`count=${e}`), this.headers.Prefer && t.unshift(this.headers.Prefer), this.headers.Prefer = t.join(","), new R({
                        method: "DELETE",
                        url: this.url,
                        headers: this.headers,
                        schema: this.schema,
                        fetch: this.fetch,
                        allowEmpty: !1
                    })
                }
            }
            let N = {
                "X-Client-Info": "postgrest-js/1.1.1"
            };
            class U {
                constructor(e, {
                    headers: t = {},
                    schema: r,
                    fetch: i
                } = {}) {
                    this.url = e, this.headers = Object.assign(Object.assign({}, N), t), this.schema = r, this.fetch = i
                }
                from(e) {
                    let t = new URL(`${this.url}/${e}`);
                    return new I(t, {
                        headers: Object.assign({}, this.headers),
                        schema: this.schema,
                        fetch: this.fetch
                    })
                }
                rpc(e, t = {}, {
                    head: r = !1,
                    count: i
                } = {}) {
                    let s, n;
                    let o = new URL(`${this.url}/rpc/${e}`);
                    r ? (s = "HEAD", Object.entries(t).forEach(([e, t]) => {
                        o.searchParams.append(e, `${t}`)
                    })) : (s = "POST", n = t);
                    let a = Object.assign({}, this.headers);
                    return i && (a.Prefer = `count=${i}`), new R({
                        method: s,
                        url: o,
                        headers: a,
                        schema: this.schema,
                        body: n,
                        fetch: this.fetch,
                        allowEmpty: !1
                    })
                }
            }
            var $ = r(45840);
            let L = {
                "X-Client-Info": "realtime-js/2.1.0"
            };
            (b = u || (u = {}))[b.connecting = 0] = "connecting", b[b.open = 1] = "open", b[b.closing = 2] = "closing", b[b.closed = 3] = "closed", (w = h || (h = {})).closed = "closed", w.errored = "errored", w.joined = "joined", w.joining = "joining", w.leaving = "leaving", (_ = c || (c = {})).close = "phx_close", _.error = "phx_error", _.join = "phx_join", _.reply = "phx_reply", _.leave = "phx_leave", _.access_token = "access_token", (d || (d = {})).websocket = "websocket", (k = f || (f = {})).Connecting = "connecting", k.Open = "open", k.Closing = "closing", k.Closed = "closed";
            class B {
                constructor(e, t) {
                    this.callback = e, this.timerCalc = t, this.timer = void 0, this.tries = 0, this.callback = e, this.timerCalc = t
                }
                reset() {
                    this.tries = 0, clearTimeout(this.timer)
                }
                scheduleTimeout() {
                    clearTimeout(this.timer), this.timer = setTimeout(() => {
                        this.tries = this.tries + 1, this.callback()
                    }, this.timerCalc(this.tries + 1))
                }
            }
            class M {
                constructor() {
                    this.HEADER_LENGTH = 1
                }
                decode(e, t) {
                    return e.constructor === ArrayBuffer ? t(this._binaryDecode(e)) : "string" == typeof e ? t(JSON.parse(e)) : t({})
                }
                _binaryDecode(e) {
                    let t = new DataView(e),
                        r = new TextDecoder;
                    return this._decodeBroadcast(e, t, r)
                }
                _decodeBroadcast(e, t, r) {
                    let i = t.getUint8(1),
                        s = t.getUint8(2),
                        n = this.HEADER_LENGTH + 2,
                        o = r.decode(e.slice(n, n + i));
                    n += i;
                    let a = r.decode(e.slice(n, n + s));
                    n += s;
                    let l = JSON.parse(r.decode(e.slice(n, e.byteLength)));
                    return {
                        ref: null,
                        topic: o,
                        event: a,
                        payload: l
                    }
                }
            }
            class D {
                constructor(e, t, r = {}, i = 1e4) {
                    this.channel = e, this.event = t, this.payload = r, this.timeout = i, this.sent = !1, this.timeoutTimer = void 0, this.ref = "", this.receivedResp = null, this.recHooks = [], this.refEvent = null, this.rateLimited = !1
                }
                resend(e) {
                    this.timeout = e, this._cancelRefEvent(), this.ref = "", this.refEvent = null, this.receivedResp = null, this.sent = !1, this.send()
                }
                send() {
                    if (this._hasReceived("timeout")) return;
                    this.startTimeout(), this.sent = !0;
                    let e = this.channel.socket.push({
                        topic: this.channel.topic,
                        event: this.event,
                        payload: this.payload,
                        ref: this.ref,
                        join_ref: this.channel._joinRef()
                    });
                    "rate limited" === e && (this.rateLimited = !0)
                }
                updatePayload(e) {
                    this.payload = Object.assign(Object.assign({}, this.payload), e)
                }
                receive(e, t) {
                    var r;
                    return this._hasReceived(e) && t(null === (r = this.receivedResp) || void 0 === r ? void 0 : r.response), this.recHooks.push({
                        status: e,
                        callback: t
                    }), this
                }
                startTimeout() {
                    if (this.timeoutTimer) return;
                    this.ref = this.channel.socket._makeRef(), this.refEvent = this.channel._replyEventName(this.ref);
                    let e = e => {
                        this._cancelRefEvent(), this._cancelTimeout(), this.receivedResp = e, this._matchReceive(e)
                    };
                    this.channel._on(this.refEvent, {}, e), this.timeoutTimer = setTimeout(() => {
                        this.trigger("timeout", {})
                    }, this.timeout)
                }
                trigger(e, t) {
                    this.refEvent && this.channel._trigger(this.refEvent, {
                        status: e,
                        response: t
                    })
                }
                destroy() {
                    this._cancelRefEvent(), this._cancelTimeout()
                }
                _cancelRefEvent() {
                    this.refEvent && this.channel._off(this.refEvent, {})
                }
                _cancelTimeout() {
                    clearTimeout(this.timeoutTimer), this.timeoutTimer = void 0
                }
                _matchReceive({
                    status: e,
                    response: t
                }) {
                    this.recHooks.filter(t => t.status === e).forEach(e => e.callback(t))
                }
                _hasReceived(e) {
                    return this.receivedResp && this.receivedResp.status === e
                }
            }(E = p || (p = {})).SYNC = "sync", E.JOIN = "join", E.LEAVE = "leave";
            class F {
                constructor(e, t) {
                    this.channel = e, this.state = {}, this.pendingDiffs = [], this.joinRef = null, this.caller = {
                        onJoin() {},
                        onLeave() {},
                        onSync() {}
                    };
                    let r = (null == t ? void 0 : t.events) || {
                        state: "presence_state",
                        diff: "presence_diff"
                    };
                    this.channel._on(r.state, {}, e => {
                        let {
                            onJoin: t,
                            onLeave: r,
                            onSync: i
                        } = this.caller;
                        this.joinRef = this.channel._joinRef(), this.state = F.syncState(this.state, e, t, r), this.pendingDiffs.forEach(e => {
                            this.state = F.syncDiff(this.state, e, t, r)
                        }), this.pendingDiffs = [], i()
                    }), this.channel._on(r.diff, {}, e => {
                        let {
                            onJoin: t,
                            onLeave: r,
                            onSync: i
                        } = this.caller;
                        this.inPendingSyncState() ? this.pendingDiffs.push(e) : (this.state = F.syncDiff(this.state, e, t, r), i())
                    }), this.onJoin((e, t, r) => {
                        this.channel._trigger("presence", {
                            event: "join",
                            key: e,
                            currentPresences: t,
                            newPresences: r
                        })
                    }), this.onLeave((e, t, r) => {
                        this.channel._trigger("presence", {
                            event: "leave",
                            key: e,
                            currentPresences: t,
                            leftPresences: r
                        })
                    }), this.onSync(() => {
                        this.channel._trigger("presence", {
                            event: "sync"
                        })
                    })
                }
                static syncState(e, t, r, i) {
                    let s = this.cloneDeep(e),
                        n = this.transformState(t),
                        o = {},
                        a = {};
                    return this.map(s, (e, t) => {
                        n[e] || (a[e] = t)
                    }), this.map(n, (e, t) => {
                        let r = s[e];
                        if (r) {
                            let i = t.map(e => e.presence_ref),
                                n = r.map(e => e.presence_ref),
                                l = t.filter(e => 0 > n.indexOf(e.presence_ref)),
                                u = r.filter(e => 0 > i.indexOf(e.presence_ref));
                            l.length > 0 && (o[e] = l), u.length > 0 && (a[e] = u)
                        } else o[e] = t
                    }), this.syncDiff(s, {
                        joins: o,
                        leaves: a
                    }, r, i)
                }
                static syncDiff(e, t, r, i) {
                    let {
                        joins: s,
                        leaves: n
                    } = {
                        joins: this.transformState(t.joins),
                        leaves: this.transformState(t.leaves)
                    };
                    return r || (r = () => {}), i || (i = () => {}), this.map(s, (t, i) => {
                        var s;
                        let n = null !== (s = e[t]) && void 0 !== s ? s : [];
                        if (e[t] = this.cloneDeep(i), n.length > 0) {
                            let o = e[t].map(e => e.presence_ref),
                                a = n.filter(e => 0 > o.indexOf(e.presence_ref));
                            e[t].unshift(...a)
                        }
                        r(t, n, i)
                    }), this.map(n, (t, r) => {
                        let s = e[t];
                        if (!s) return;
                        let n = r.map(e => e.presence_ref);
                        s = s.filter(e => 0 > n.indexOf(e.presence_ref)), e[t] = s, i(t, s, r), 0 === s.length && delete e[t]
                    }), e
                }
                static map(e, t) {
                    return Object.getOwnPropertyNames(e).map(r => t(r, e[r]))
                }
                static transformState(e) {
                    return Object.getOwnPropertyNames(e = this.cloneDeep(e)).reduce((t, r) => {
                        let i = e[r];
                        return "metas" in i ? t[r] = i.metas.map(e => (e.presence_ref = e.phx_ref, delete e.phx_ref, delete e.phx_ref_prev, e)) : t[r] = i, t
                    }, {})
                }
                static cloneDeep(e) {
                    return JSON.parse(JSON.stringify(e))
                }
                onJoin(e) {
                    this.caller.onJoin = e
                }
                onLeave(e) {
                    this.caller.onLeave = e
                }
                onSync(e) {
                    this.caller.onSync = e
                }
                inPendingSyncState() {
                    return !this.joinRef || this.joinRef !== this.channel._joinRef()
                }
            }(S = g || (g = {})).abstime = "abstime", S.bool = "bool", S.date = "date", S.daterange = "daterange", S.float4 = "float4", S.float8 = "float8", S.int2 = "int2", S.int4 = "int4", S.int4range = "int4range", S.int8 = "int8", S.int8range = "int8range", S.json = "json", S.jsonb = "jsonb", S.money = "money", S.numeric = "numeric", S.oid = "oid", S.reltime = "reltime", S.text = "text", S.time = "time", S.timestamp = "timestamp", S.timestamptz = "timestamptz", S.timetz = "timetz", S.tsrange = "tsrange", S.tstzrange = "tstzrange";
            let J = (e, t, r = {}) => {
                    var i;
                    let s = null !== (i = r.skipTypes) && void 0 !== i ? i : [];
                    return Object.keys(t).reduce((r, i) => (r[i] = z(i, e, t, s), r), {})
                },
                z = (e, t, r, i) => {
                    let s = t.find(t => t.name === e),
                        n = null == s ? void 0 : s.type,
                        o = r[e];
                    return n && !i.includes(n) ? q(n, o) : H(o)
                },
                q = (e, t) => {
                    if ("_" === e.charAt(0)) {
                        let r = e.slice(1, e.length);
                        return X(t, r)
                    }
                    switch (e) {
                        case g.bool:
                            return Y(t);
                        case g.float4:
                        case g.float8:
                        case g.int2:
                        case g.int4:
                        case g.int8:
                        case g.numeric:
                        case g.oid:
                            return G(t);
                        case g.json:
                        case g.jsonb:
                            return V(t);
                        case g.timestamp:
                            return W(t);
                        case g.abstime:
                        case g.date:
                        case g.daterange:
                        case g.int4range:
                        case g.int8range:
                        case g.money:
                        case g.reltime:
                        case g.text:
                        case g.time:
                        case g.timestamptz:
                        case g.timetz:
                        case g.tsrange:
                        case g.tstzrange:
                        default:
                            return H(t)
                    }
                },
                H = e => e,
                Y = e => {
                    switch (e) {
                        case "t":
                            return !0;
                        case "f":
                            return !1;
                        default:
                            return e
                    }
                },
                G = e => {
                    if ("string" == typeof e) {
                        let t = parseFloat(e);
                        if (!Number.isNaN(t)) return t
                    }
                    return e
                },
                V = e => {
                    if ("string" == typeof e) try {
                        return JSON.parse(e)
                    } catch (t) {
                        console.log(`JSON parse error: ${t}`)
                    }
                    return e
                },
                X = (e, t) => {
                    if ("string" != typeof e) return e;
                    let r = e.length - 1,
                        i = e[r],
                        s = e[0];
                    if ("{" === s && "}" === i) {
                        let n;
                        let o = e.slice(1, r);
                        try {
                            n = JSON.parse("[" + o + "]")
                        } catch (a) {
                            n = o ? o.split(",") : []
                        }
                        return n.map(e => q(t, e))
                    }
                    return e
                },
                W = e => "string" == typeof e ? e.replace(" ", "T") : e;
            var K = function(e, t, r, i) {
                return new(r || (r = Promise))(function(s, n) {
                    function o(e) {
                        try {
                            l(i.next(e))
                        } catch (t) {
                            n(t)
                        }
                    }

                    function a(e) {
                        try {
                            l(i.throw(e))
                        } catch (t) {
                            n(t)
                        }
                    }

                    function l(e) {
                        var t;
                        e.done ? s(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                            e(t)
                        })).then(o, a)
                    }
                    l((i = i.apply(e, t || [])).next())
                })
            };
            (x = m || (m = {})).ALL = "*", x.INSERT = "INSERT", x.UPDATE = "UPDATE", x.DELETE = "DELETE", (T = v || (v = {})).BROADCAST = "broadcast", T.PRESENCE = "presence", T.POSTGRES_CHANGES = "postgres_changes", (O = y || (y = {})).SUBSCRIBED = "SUBSCRIBED", O.TIMED_OUT = "TIMED_OUT", O.CLOSED = "CLOSED", O.CHANNEL_ERROR = "CHANNEL_ERROR";
            class Z {
                constructor(e, t = {
                    config: {}
                }, r) {
                    this.topic = e, this.params = t, this.socket = r, this.bindings = {}, this.state = h.closed, this.joinedOnce = !1, this.pushBuffer = [], this.params.config = Object.assign({
                        broadcast: {
                            ack: !1,
                            self: !1
                        },
                        presence: {
                            key: ""
                        }
                    }, t.config), this.timeout = this.socket.timeout, this.joinPush = new D(this, c.join, this.params, this.timeout), this.rejoinTimer = new B(() => this._rejoinUntilConnected(), this.socket.reconnectAfterMs), this.joinPush.receive("ok", () => {
                        this.state = h.joined, this.rejoinTimer.reset(), this.pushBuffer.forEach(e => e.send()), this.pushBuffer = []
                    }), this._onClose(() => {
                        this.rejoinTimer.reset(), this.socket.log("channel", `close ${this.topic} ${this._joinRef()}`), this.state = h.closed, this.socket._remove(this)
                    }), this._onError(e => {
                        this._isLeaving() || this._isClosed() || (this.socket.log("channel", `error ${this.topic}`, e), this.state = h.errored, this.rejoinTimer.scheduleTimeout())
                    }), this.joinPush.receive("timeout", () => {
                        this._isJoining() && (this.socket.log("channel", `timeout ${this.topic}`, this.joinPush.timeout), this.state = h.errored, this.rejoinTimer.scheduleTimeout())
                    }), this._on(c.reply, {}, (e, t) => {
                        this._trigger(this._replyEventName(t), e)
                    }), this.presence = new F(this)
                }
                subscribe(e, t = this.timeout) {
                    var r, i;
                    if (this.joinedOnce) throw "tried to subscribe multiple times. 'subscribe' can only be called a single time per channel instance"; {
                        let {
                            config: {
                                broadcast: s,
                                presence: n
                            }
                        } = this.params;
                        this._onError(t => e && e("CHANNEL_ERROR", t)), this._onClose(() => e && e("CLOSED"));
                        let o = {},
                            a = {
                                broadcast: s,
                                presence: n,
                                postgres_changes: null !== (i = null === (r = this.bindings.postgres_changes) || void 0 === r ? void 0 : r.map(e => e.filter)) && void 0 !== i ? i : []
                            };
                        this.socket.accessToken && (o.access_token = this.socket.accessToken), this.updateJoinPayload(Object.assign({
                            config: a
                        }, o)), this.joinedOnce = !0, this._rejoin(t), this.joinPush.receive("ok", ({
                            postgres_changes: t
                        }) => {
                            var r;
                            if (this.socket.accessToken && this.socket.setAuth(this.socket.accessToken), void 0 === t) {
                                e && e("SUBSCRIBED");
                                return
                            } {
                                let i = this.bindings.postgres_changes,
                                    s = null !== (r = null == i ? void 0 : i.length) && void 0 !== r ? r : 0,
                                    n = [];
                                for (let o = 0; o < s; o++) {
                                    let a = i[o],
                                        {
                                            filter: {
                                                event: l,
                                                schema: u,
                                                table: h,
                                                filter: c
                                            }
                                        } = a,
                                        d = t && t[o];
                                    if (d && d.event === l && d.schema === u && d.table === h && d.filter === c) n.push(Object.assign(Object.assign({}, a), {
                                        id: d.id
                                    }));
                                    else {
                                        this.unsubscribe(), e && e("CHANNEL_ERROR", Error("mismatch between server and client bindings for postgres changes"));
                                        return
                                    }
                                }
                                this.bindings.postgres_changes = n, e && e("SUBSCRIBED");
                                return
                            }
                        }).receive("error", t => {
                            e && e("CHANNEL_ERROR", Error(JSON.stringify(Object.values(t).join(", ") || "error")))
                        }).receive("timeout", () => {
                            e && e("TIMED_OUT")
                        })
                    }
                    return this
                }
                presenceState() {
                    return this.presence.state
                }
                track(e, t = {}) {
                    return K(this, void 0, void 0, function*() {
                        return yield this.send({
                            type: "presence",
                            event: "track",
                            payload: e
                        }, t.timeout || this.timeout)
                    })
                }
                untrack(e = {}) {
                    return K(this, void 0, void 0, function*() {
                        return yield this.send({
                            type: "presence",
                            event: "untrack"
                        }, e)
                    })
                }
                on(e, t, r) {
                    return this._on(e, t, r)
                }
                send(e, t = {}) {
                    return new Promise(r => {
                        var i, s, n;
                        let o = this._push(e.type, e, t.timeout || this.timeout);
                        o.rateLimited && r("rate limited"), "broadcast" !== e.type || (null === (n = null === (s = null === (i = this.params) || void 0 === i ? void 0 : i.config) || void 0 === s ? void 0 : s.broadcast) || void 0 === n ? void 0 : n.ack) || r("ok"), o.receive("ok", () => r("ok")), o.receive("timeout", () => r("timed out"))
                    })
                }
                updateJoinPayload(e) {
                    this.joinPush.updatePayload(e)
                }
                unsubscribe(e = this.timeout) {
                    this.state = h.leaving;
                    let t = () => {
                        this.socket.log("channel", `leave ${this.topic}`), this._trigger(c.close, "leave", this._joinRef())
                    };
                    return this.rejoinTimer.reset(), this.joinPush.destroy(), new Promise(r => {
                        let i = new D(this, c.leave, {}, e);
                        i.receive("ok", () => {
                            t(), r("ok")
                        }).receive("timeout", () => {
                            t(), r("timed out")
                        }).receive("error", () => {
                            r("error")
                        }), i.send(), this._canPush() || i.trigger("ok", {})
                    })
                }
                _push(e, t, r = this.timeout) {
                    if (!this.joinedOnce) throw `tried to push '${e}' to '${this.topic}' before joining. Use channel.subscribe() before pushing events`;
                    let i = new D(this, e, t, r);
                    return this._canPush() ? i.send() : (i.startTimeout(), this.pushBuffer.push(i)), i
                }
                _onMessage(e, t, r) {
                    return t
                }
                _isMember(e) {
                    return this.topic === e
                }
                _joinRef() {
                    return this.joinPush.ref
                }
                _trigger(e, t, r) {
                    var i, s;
                    let n = e.toLocaleLowerCase(),
                        {
                            close: o,
                            error: a,
                            leave: l,
                            join: u
                        } = c;
                    if (r && [o, a, l, u].indexOf(n) >= 0 && r !== this._joinRef()) return;
                    let h = this._onMessage(n, t, r);
                    if (t && !h) throw "channel onMessage callbacks must return the payload, modified or unmodified";
                    ["insert", "update", "delete"].includes(n) ? null === (i = this.bindings.postgres_changes) || void 0 === i || i.filter(e => {
                        var t, r, i;
                        return (null === (t = e.filter) || void 0 === t ? void 0 : t.event) === "*" || (null === (i = null === (r = e.filter) || void 0 === r ? void 0 : r.event) || void 0 === i ? void 0 : i.toLocaleLowerCase()) === n
                    }).map(e => e.callback(h, r)) : null === (s = this.bindings[n]) || void 0 === s || s.filter(e => {
                        var r, i, s, o, a, l;
                        if (!["broadcast", "presence", "postgres_changes"].includes(n)) return e.type.toLocaleLowerCase() === n;
                        if ("id" in e) {
                            let u = e.id,
                                h = null === (r = e.filter) || void 0 === r ? void 0 : r.event;
                            return u && (null === (i = t.ids) || void 0 === i ? void 0 : i.includes(u)) && ("*" === h || (null == h ? void 0 : h.toLocaleLowerCase()) === (null === (s = t.data) || void 0 === s ? void 0 : s.type.toLocaleLowerCase()))
                        } {
                            let c = null === (a = null === (o = null == e ? void 0 : e.filter) || void 0 === o ? void 0 : o.event) || void 0 === a ? void 0 : a.toLocaleLowerCase();
                            return "*" === c || c === (null === (l = null == t ? void 0 : t.event) || void 0 === l ? void 0 : l.toLocaleLowerCase())
                        }
                    }).map(e => {
                        if ("object" == typeof h && "ids" in h) {
                            let t = h.data,
                                {
                                    schema: i,
                                    table: s,
                                    commit_timestamp: n,
                                    type: o,
                                    errors: a
                                } = t;
                            h = Object.assign(Object.assign({}, {
                                schema: i,
                                table: s,
                                commit_timestamp: n,
                                eventType: o,
                                new: {},
                                old: {},
                                errors: a
                            }), this._getPayloadRecords(t))
                        }
                        e.callback(h, r)
                    })
                }
                _isClosed() {
                    return this.state === h.closed
                }
                _isJoined() {
                    return this.state === h.joined
                }
                _isJoining() {
                    return this.state === h.joining
                }
                _isLeaving() {
                    return this.state === h.leaving
                }
                _replyEventName(e) {
                    return `chan_reply_${e}`
                }
                _on(e, t, r) {
                    let i = e.toLocaleLowerCase(),
                        s = {
                            type: i,
                            filter: t,
                            callback: r
                        };
                    return this.bindings[i] ? this.bindings[i].push(s) : this.bindings[i] = [s], this
                }
                _off(e, t) {
                    let r = e.toLocaleLowerCase();
                    return this.bindings[r] = this.bindings[r].filter(e => {
                        var i;
                        return !((null === (i = e.type) || void 0 === i ? void 0 : i.toLocaleLowerCase()) === r && Z.isEqual(e.filter, t))
                    }), this
                }
                static isEqual(e, t) {
                    if (Object.keys(e).length !== Object.keys(t).length) return !1;
                    for (let r in e)
                        if (e[r] !== t[r]) return !1;
                    return !0
                }
                _rejoinUntilConnected() {
                    this.rejoinTimer.scheduleTimeout(), this.socket.isConnected() && this._rejoin()
                }
                _onClose(e) {
                    this._on(c.close, {}, e)
                }
                _onError(e) {
                    this._on(c.error, {}, t => e(t))
                }
                _canPush() {
                    return this.socket.isConnected() && this._isJoined()
                }
                _rejoin(e = this.timeout) {
                    this._isLeaving() || (this.socket._leaveOpenTopic(this.topic), this.state = h.joining, this.joinPush.resend(e))
                }
                _getPayloadRecords(e) {
                    let t = {
                        new: {},
                        old: {}
                    };
                    return ("INSERT" === e.type || "UPDATE" === e.type) && (t.new = J(e.columns, e.record)), ("UPDATE" === e.type || "DELETE" === e.type) && (t.old = J(e.columns, e.old_record)), t
                }
            }
            let Q = () => {};
            class ee {
                constructor(e, t) {
                    var r;
                    this.accessToken = null, this.channels = [], this.endPoint = "", this.headers = L, this.params = {}, this.timeout = 1e4, this.transport = $.w3cwebsocket, this.heartbeatIntervalMs = 3e4, this.heartbeatTimer = void 0, this.pendingHeartbeatRef = null, this.ref = 0, this.logger = Q, this.conn = null, this.sendBuffer = [], this.serializer = new M, this.stateChangeCallbacks = {
                        open: [],
                        close: [],
                        error: [],
                        message: []
                    }, this.eventsPerSecondLimitMs = 100, this.inThrottle = !1, this.endPoint = `${e}/${d.websocket}`, (null == t ? void 0 : t.params) && (this.params = t.params), (null == t ? void 0 : t.headers) && (this.headers = Object.assign(Object.assign({}, this.headers), t.headers)), (null == t ? void 0 : t.timeout) && (this.timeout = t.timeout), (null == t ? void 0 : t.logger) && (this.logger = t.logger), (null == t ? void 0 : t.transport) && (this.transport = t.transport), (null == t ? void 0 : t.heartbeatIntervalMs) && (this.heartbeatIntervalMs = t.heartbeatIntervalMs);
                    let i = null === (r = null == t ? void 0 : t.params) || void 0 === r ? void 0 : r.eventsPerSecond;
                    i && (this.eventsPerSecondLimitMs = Math.floor(1e3 / i)), this.reconnectAfterMs = (null == t ? void 0 : t.reconnectAfterMs) ? t.reconnectAfterMs : e => [1e3, 2e3, 5e3, 1e4][e - 1] || 1e4, this.encode = (null == t ? void 0 : t.encode) ? t.encode : (e, t) => t(JSON.stringify(e)), this.decode = (null == t ? void 0 : t.decode) ? t.decode : this.serializer.decode.bind(this.serializer), this.reconnectTimer = new B(() => {
                        var e, t, r, i;
                        return e = this, t = void 0, i = function*() {
                            this.disconnect(), this.connect()
                        }, new(r = void 0, r = Promise)(function(s, n) {
                            function o(e) {
                                try {
                                    l(i.next(e))
                                } catch (t) {
                                    n(t)
                                }
                            }

                            function a(e) {
                                try {
                                    l(i.throw(e))
                                } catch (t) {
                                    n(t)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? s(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                                    e(t)
                                })).then(o, a)
                            }
                            l((i = i.apply(e, t || [])).next())
                        })
                    }, this.reconnectAfterMs)
                }
                connect() {
                    !this.conn && (this.conn = new this.transport(this._endPointURL(), [], null, this.headers), this.conn && (this.conn.binaryType = "arraybuffer", this.conn.onopen = () => this._onConnOpen(), this.conn.onerror = e => this._onConnError(e), this.conn.onmessage = e => this._onConnMessage(e), this.conn.onclose = e => this._onConnClose(e)))
                }
                disconnect(e, t) {
                    this.conn && (this.conn.onclose = function() {}, e ? this.conn.close(e, null != t ? t : "") : this.conn.close(), this.conn = null, this.heartbeatTimer && clearInterval(this.heartbeatTimer), this.reconnectTimer.reset())
                }
                getChannels() {
                    return this.channels
                }
                removeChannel(e) {
                    return e.unsubscribe().then(e => (0 === this.channels.length && this.disconnect(), e))
                }
                removeAllChannels() {
                    return Promise.all(this.channels.map(e => e.unsubscribe())).then(e => (this.disconnect(), e))
                }
                log(e, t, r) {
                    this.logger(e, t, r)
                }
                connectionState() {
                    switch (this.conn && this.conn.readyState) {
                        case u.connecting:
                            return f.Connecting;
                        case u.open:
                            return f.Open;
                        case u.closing:
                            return f.Closing;
                        default:
                            return f.Closed
                    }
                }
                isConnected() {
                    return this.connectionState() === f.Open
                }
                channel(e, t = {
                    config: {}
                }) {
                    this.isConnected() || this.connect();
                    let r = new Z(`realtime:${e}`, t, this);
                    return this.channels.push(r), r
                }
                push(e) {
                    let {
                        topic: t,
                        event: r,
                        payload: i,
                        ref: s
                    } = e, n = () => {
                        this.encode(e, e => {
                            var t;
                            null === (t = this.conn) || void 0 === t || t.send(e)
                        })
                    };
                    if (this.log("push", `${t} ${r} (${s})`, i), this.isConnected()) {
                        if (["broadcast", "presence", "postgres_changes"].includes(r)) {
                            let o = this._throttle(n)();
                            if (o) return "rate limited"
                        } else n()
                    } else this.sendBuffer.push(n)
                }
                setAuth(e) {
                    this.accessToken = e, this.channels.forEach(t => {
                        e && t.updateJoinPayload({
                            access_token: e
                        }), t.joinedOnce && t._isJoined() && t._push(c.access_token, {
                            access_token: e
                        })
                    })
                }
                _makeRef() {
                    let e = this.ref + 1;
                    return e === this.ref ? this.ref = 0 : this.ref = e, this.ref.toString()
                }
                _leaveOpenTopic(e) {
                    let t = this.channels.find(t => t.topic === e && (t._isJoined() || t._isJoining()));
                    t && (this.log("transport", `leaving duplicate topic "${e}"`), t.unsubscribe())
                }
                _remove(e) {
                    this.channels = this.channels.filter(t => t._joinRef() !== e._joinRef())
                }
                _endPointURL() {
                    return this._appendParams(this.endPoint, Object.assign({}, this.params, {
                        vsn: "1.0.0"
                    }))
                }
                _onConnMessage(e) {
                    this.decode(e.data, e => {
                        let {
                            topic: t,
                            event: r,
                            payload: i,
                            ref: s
                        } = e;
                        (s && s === this.pendingHeartbeatRef || r === (null == i ? void 0 : i.type)) && (this.pendingHeartbeatRef = null), this.log("receive", `${i.status||""} ${t} ${r} ${s&&"("+s+")"||""}`, i), this.channels.filter(e => e._isMember(t)).forEach(e => e._trigger(r, i, s)), this.stateChangeCallbacks.message.forEach(t => t(e))
                    })
                }
                _onConnOpen() {
                    this.log("transport", `connected to ${this._endPointURL()}`), this._flushSendBuffer(), this.reconnectTimer.reset(), this.heartbeatTimer && clearInterval(this.heartbeatTimer), this.heartbeatTimer = setInterval(() => this._sendHeartbeat(), this.heartbeatIntervalMs), this.stateChangeCallbacks.open.forEach(e => e())
                }
                _onConnClose(e) {
                    this.log("transport", "close", e), this._triggerChanError(), this.heartbeatTimer && clearInterval(this.heartbeatTimer), this.reconnectTimer.scheduleTimeout(), this.stateChangeCallbacks.close.forEach(t => t(e))
                }
                _onConnError(e) {
                    this.log("transport", e.message), this._triggerChanError(), this.stateChangeCallbacks.error.forEach(t => t(e))
                }
                _triggerChanError() {
                    this.channels.forEach(e => e._trigger(c.error))
                }
                _appendParams(e, t) {
                    if (0 === Object.keys(t).length) return e;
                    let r = e.match(/\?/) ? "&" : "?",
                        i = new URLSearchParams(t);
                    return `${e}${r}${i}`
                }
                _flushSendBuffer() {
                    this.isConnected() && this.sendBuffer.length > 0 && (this.sendBuffer.forEach(e => e()), this.sendBuffer = [])
                }
                _sendHeartbeat() {
                    var e;
                    if (this.isConnected()) {
                        if (this.pendingHeartbeatRef) {
                            this.pendingHeartbeatRef = null, this.log("transport", "heartbeat timeout. Attempting to re-establish connection"), null === (e = this.conn) || void 0 === e || e.close(1e3, "hearbeat timeout");
                            return
                        }
                        this.pendingHeartbeatRef = this._makeRef(), this.push({
                            topic: "phoenix",
                            event: "heartbeat",
                            payload: {},
                            ref: this.pendingHeartbeatRef
                        }), this.setAuth(this.accessToken)
                    }
                }
                _throttle(e, t = this.eventsPerSecondLimitMs) {
                    return () => !!this.inThrottle || (e(), this.inThrottle = !0, setTimeout(() => {
                        this.inThrottle = !1
                    }, t), !1)
                }
            }
            class et extends Error {
                constructor(e) {
                    super(e), this.__isStorageError = !0, this.name = "StorageError"
                }
            }

            function er(e) {
                return "object" == typeof e && null !== e && "__isStorageError" in e
            }
            class ei extends et {
                constructor(e, t) {
                    super(e), this.name = "StorageApiError", this.status = t
                }
                toJSON() {
                    return {
                        name: this.name,
                        message: this.message,
                        status: this.status
                    }
                }
            }
            class es extends et {
                constructor(e, t) {
                    super(e), this.name = "StorageUnknownError", this.originalError = t
                }
            }
            var en = function(e, t, r, i) {
                return new(r || (r = Promise))(function(s, n) {
                    function o(e) {
                        try {
                            l(i.next(e))
                        } catch (t) {
                            n(t)
                        }
                    }

                    function a(e) {
                        try {
                            l(i.throw(e))
                        } catch (t) {
                            n(t)
                        }
                    }

                    function l(e) {
                        var t;
                        e.done ? s(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                            e(t)
                        })).then(o, a)
                    }
                    l((i = i.apply(e, t || [])).next())
                })
            };
            let eo = e => {
                    let t;
                    return t = e || ("undefined" == typeof fetch ? (...e) => en(void 0, void 0, void 0, function*() {
                        return yield(yield Promise.resolve().then(r.t.bind(r, 54098, 23))).fetch(...e)
                    }) : fetch), (...e) => t(...e)
                },
                ea = () => en(void 0, void 0, void 0, function*() {
                    return "undefined" == typeof Response ? (yield Promise.resolve().then(r.t.bind(r, 54098, 23))).Response : Response
                });
            var el = function(e, t, r, i) {
                return new(r || (r = Promise))(function(s, n) {
                    function o(e) {
                        try {
                            l(i.next(e))
                        } catch (t) {
                            n(t)
                        }
                    }

                    function a(e) {
                        try {
                            l(i.throw(e))
                        } catch (t) {
                            n(t)
                        }
                    }

                    function l(e) {
                        var t;
                        e.done ? s(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                            e(t)
                        })).then(o, a)
                    }
                    l((i = i.apply(e, t || [])).next())
                })
            };
            let eu = e => e.msg || e.message || e.error_description || e.error || JSON.stringify(e),
                eh = (e, t) => el(void 0, void 0, void 0, function*() {
                    let r = yield ea();
                    e instanceof r ? e.json().then(r => {
                        t(new ei(eu(r), e.status || 500))
                    }) : t(new es(eu(e), e))
                }),
                ec = (e, t, r, i) => {
                    let s = {
                        method: e,
                        headers: (null == t ? void 0 : t.headers) || {}
                    };
                    return "GET" === e ? s : (s.headers = Object.assign({
                        "Content-Type": "application/json"
                    }, null == t ? void 0 : t.headers), s.body = JSON.stringify(i), Object.assign(Object.assign({}, s), r))
                };

            function ed(e, t, r, i, s, n) {
                return el(this, void 0, void 0, function*() {
                    return new Promise((o, a) => {
                        e(r, ec(t, i, s, n)).then(e => {
                            if (!e.ok) throw e;
                            return (null == i ? void 0 : i.noResolveJson) ? e : e.json()
                        }).then(e => o(e)).catch(e => eh(e, a))
                    })
                })
            }

            function ef(e, t, r, i) {
                return el(this, void 0, void 0, function*() {
                    return ed(e, "GET", t, r, i)
                })
            }

            function ep(e, t, r, i, s) {
                return el(this, void 0, void 0, function*() {
                    return ed(e, "POST", t, i, s, r)
                })
            }

            function eg(e, t, r, i, s) {
                return el(this, void 0, void 0, function*() {
                    return ed(e, "DELETE", t, i, s, r)
                })
            }
            var em = function(e, t, r, i) {
                return new(r || (r = Promise))(function(s, n) {
                    function o(e) {
                        try {
                            l(i.next(e))
                        } catch (t) {
                            n(t)
                        }
                    }

                    function a(e) {
                        try {
                            l(i.throw(e))
                        } catch (t) {
                            n(t)
                        }
                    }

                    function l(e) {
                        var t;
                        e.done ? s(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                            e(t)
                        })).then(o, a)
                    }
                    l((i = i.apply(e, t || [])).next())
                })
            };
            let ev = {
                    limit: 100,
                    offset: 0,
                    sortBy: {
                        column: "name",
                        order: "asc"
                    }
                },
                ey = {
                    cacheControl: "3600",
                    contentType: "text/plain;charset=UTF-8",
                    upsert: !1
                };
            class eb {
                constructor(e, t = {}, r, i) {
                    this.url = e, this.headers = t, this.bucketId = r, this.fetch = eo(i)
                }
                uploadOrUpdate(e, t, r, i) {
                    return em(this, void 0, void 0, function*() {
                        try {
                            let s;
                            let n = Object.assign(Object.assign({}, ey), i),
                                o = Object.assign(Object.assign({}, this.headers), "POST" === e && {
                                    "x-upsert": String(n.upsert)
                                });
                            "undefined" != typeof Blob && r instanceof Blob ? ((s = new FormData).append("cacheControl", n.cacheControl), s.append("", r)) : "undefined" != typeof FormData && r instanceof FormData ? (s = r).append("cacheControl", n.cacheControl) : (s = r, o["cache-control"] = `max-age=${n.cacheControl}`, o["content-type"] = n.contentType);
                            let a = this._removeEmptyFolders(t),
                                l = this._getFinalPath(a),
                                u = yield this.fetch(`${this.url}/object/${l}`, {
                                    method: e,
                                    body: s,
                                    headers: o
                                });
                            if (u.ok) return {
                                data: {
                                    path: a
                                },
                                error: null
                            }; {
                                let h = yield u.json();
                                return {
                                    data: null,
                                    error: h
                                }
                            }
                        } catch (c) {
                            if (er(c)) return {
                                data: null,
                                error: c
                            };
                            throw c
                        }
                    })
                }
                upload(e, t, r) {
                    return em(this, void 0, void 0, function*() {
                        return this.uploadOrUpdate("POST", e, t, r)
                    })
                }
                update(e, t, r) {
                    return em(this, void 0, void 0, function*() {
                        return this.uploadOrUpdate("PUT", e, t, r)
                    })
                }
                move(e, t) {
                    return em(this, void 0, void 0, function*() {
                        try {
                            let r = yield ep(this.fetch, `${this.url}/object/move`, {
                                bucketId: this.bucketId,
                                sourceKey: e,
                                destinationKey: t
                            }, {
                                headers: this.headers
                            });
                            return {
                                data: r,
                                error: null
                            }
                        } catch (i) {
                            if (er(i)) return {
                                data: null,
                                error: i
                            };
                            throw i
                        }
                    })
                }
                copy(e, t) {
                    return em(this, void 0, void 0, function*() {
                        try {
                            let r = yield ep(this.fetch, `${this.url}/object/copy`, {
                                bucketId: this.bucketId,
                                sourceKey: e,
                                destinationKey: t
                            }, {
                                headers: this.headers
                            });
                            return {
                                data: {
                                    path: r.Key
                                },
                                error: null
                            }
                        } catch (i) {
                            if (er(i)) return {
                                data: null,
                                error: i
                            };
                            throw i
                        }
                    })
                }
                createSignedUrl(e, t, r) {
                    return em(this, void 0, void 0, function*() {
                        try {
                            let i = yield ep(this.fetch, `${this.url}/object/sign/${this._getFinalPath(e)}`, Object.assign({
                                expiresIn: t
                            }, (null == r ? void 0 : r.transform) ? {
                                transform: r.transform
                            } : {}), {
                                headers: this.headers
                            }), s = (null == r ? void 0 : r.download) ? `&download=${!0===r.download?"":r.download}` : "", n = encodeURI(`${this.url}${i.signedURL}${s}`);
                            return i = {
                                signedUrl: n
                            }, {
                                data: i,
                                error: null
                            }
                        } catch (o) {
                            if (er(o)) return {
                                data: null,
                                error: o
                            };
                            throw o
                        }
                    })
                }
                createSignedUrls(e, t, r) {
                    return em(this, void 0, void 0, function*() {
                        try {
                            let i = yield ep(this.fetch, `${this.url}/object/sign/${this.bucketId}`, {
                                expiresIn: t,
                                paths: e
                            }, {
                                headers: this.headers
                            }), s = (null == r ? void 0 : r.download) ? `&download=${!0===r.download?"":r.download}` : "";
                            return {
                                data: i.map(e => Object.assign(Object.assign({}, e), {
                                    signedUrl: e.signedURL ? encodeURI(`${this.url}${e.signedURL}${s}`) : null
                                })),
                                error: null
                            }
                        } catch (n) {
                            if (er(n)) return {
                                data: null,
                                error: n
                            };
                            throw n
                        }
                    })
                }
                download(e, t) {
                    return em(this, void 0, void 0, function*() {
                        let r = void 0 !== (null == t ? void 0 : t.transform),
                            i = this.transformOptsToQueryString((null == t ? void 0 : t.transform) || {}),
                            s = i ? `?${i}` : "";
                        try {
                            let n = this._getFinalPath(e),
                                o = yield ef(this.fetch, `${this.url}/${r?"render/image/authenticated":"object"}/${n}${s}`, {
                                    headers: this.headers,
                                    noResolveJson: !0
                                }), a = yield o.blob();
                            return {
                                data: a,
                                error: null
                            }
                        } catch (l) {
                            if (er(l)) return {
                                data: null,
                                error: l
                            };
                            throw l
                        }
                    })
                }
                getPublicUrl(e, t) {
                    let r = this._getFinalPath(e),
                        i = [],
                        s = (null == t ? void 0 : t.download) ? `download=${!0===t.download?"":t.download}` : "";
                    "" !== s && i.push(s);
                    let n = void 0 !== (null == t ? void 0 : t.transform),
                        o = this.transformOptsToQueryString((null == t ? void 0 : t.transform) || {});
                    "" !== o && i.push(o);
                    let a = i.join("&");
                    return "" !== a && (a = `?${a}`), {
                        data: {
                            publicUrl: encodeURI(`${this.url}/${n?"render/image":"object"}/public/${r}${a}`)
                        }
                    }
                }
                remove(e) {
                    return em(this, void 0, void 0, function*() {
                        try {
                            let t = yield eg(this.fetch, `${this.url}/object/${this.bucketId}`, {
                                prefixes: e
                            }, {
                                headers: this.headers
                            });
                            return {
                                data: t,
                                error: null
                            }
                        } catch (r) {
                            if (er(r)) return {
                                data: null,
                                error: r
                            };
                            throw r
                        }
                    })
                }
                list(e, t, r) {
                    return em(this, void 0, void 0, function*() {
                        try {
                            let i = Object.assign(Object.assign(Object.assign({}, ev), t), {
                                    prefix: e || ""
                                }),
                                s = yield ep(this.fetch, `${this.url}/object/list/${this.bucketId}`, i, {
                                    headers: this.headers
                                }, r);
                            return {
                                data: s,
                                error: null
                            }
                        } catch (n) {
                            if (er(n)) return {
                                data: null,
                                error: n
                            };
                            throw n
                        }
                    })
                }
                _getFinalPath(e) {
                    return `${this.bucketId}/${e}`
                }
                _removeEmptyFolders(e) {
                    return e.replace(/^\/|\/$/g, "").replace(/\/+/g, "/")
                }
                transformOptsToQueryString(e) {
                    let t = [];
                    return e.width && t.push(`width=${e.width}`), e.height && t.push(`height=${e.height}`), e.resize && t.push(`resize=${e.resize}`), t.join("&")
                }
            }
            let ew = {
                "X-Client-Info": "storage-js/2.1.0"
            };
            var e_ = function(e, t, r, i) {
                return new(r || (r = Promise))(function(s, n) {
                    function o(e) {
                        try {
                            l(i.next(e))
                        } catch (t) {
                            n(t)
                        }
                    }

                    function a(e) {
                        try {
                            l(i.throw(e))
                        } catch (t) {
                            n(t)
                        }
                    }

                    function l(e) {
                        var t;
                        e.done ? s(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                            e(t)
                        })).then(o, a)
                    }
                    l((i = i.apply(e, t || [])).next())
                })
            };
            class ek {
                constructor(e, t = {}, r) {
                    this.url = e, this.headers = Object.assign(Object.assign({}, ew), t), this.fetch = eo(r)
                }
                listBuckets() {
                    return e_(this, void 0, void 0, function*() {
                        try {
                            let e = yield ef(this.fetch, `${this.url}/bucket`, {
                                headers: this.headers
                            });
                            return {
                                data: e,
                                error: null
                            }
                        } catch (t) {
                            if (er(t)) return {
                                data: null,
                                error: t
                            };
                            throw t
                        }
                    })
                }
                getBucket(e) {
                    return e_(this, void 0, void 0, function*() {
                        try {
                            let t = yield ef(this.fetch, `${this.url}/bucket/${e}`, {
                                headers: this.headers
                            });
                            return {
                                data: t,
                                error: null
                            }
                        } catch (r) {
                            if (er(r)) return {
                                data: null,
                                error: r
                            };
                            throw r
                        }
                    })
                }
                createBucket(e, t = {
                    public: !1
                }) {
                    return e_(this, void 0, void 0, function*() {
                        try {
                            let r = yield ep(this.fetch, `${this.url}/bucket`, {
                                id: e,
                                name: e,
                                public: t.public
                            }, {
                                headers: this.headers
                            });
                            return {
                                data: r,
                                error: null
                            }
                        } catch (i) {
                            if (er(i)) return {
                                data: null,
                                error: i
                            };
                            throw i
                        }
                    })
                }
                updateBucket(e, t) {
                    return e_(this, void 0, void 0, function*() {
                        try {
                            let r = yield function(e, t, r, i, s) {
                                return el(this, void 0, void 0, function*() {
                                    return ed(e, "PUT", t, i, void 0, r)
                                })
                            }(this.fetch, `${this.url}/bucket/${e}`, {
                                id: e,
                                name: e,
                                public: t.public
                            }, {
                                headers: this.headers
                            });
                            return {
                                data: r,
                                error: null
                            }
                        } catch (i) {
                            if (er(i)) return {
                                data: null,
                                error: i
                            };
                            throw i
                        }
                    })
                }
                emptyBucket(e) {
                    return e_(this, void 0, void 0, function*() {
                        try {
                            let t = yield ep(this.fetch, `${this.url}/bucket/${e}/empty`, {}, {
                                headers: this.headers
                            });
                            return {
                                data: t,
                                error: null
                            }
                        } catch (r) {
                            if (er(r)) return {
                                data: null,
                                error: r
                            };
                            throw r
                        }
                    })
                }
                deleteBucket(e) {
                    return e_(this, void 0, void 0, function*() {
                        try {
                            let t = yield eg(this.fetch, `${this.url}/bucket/${e}`, {}, {
                                headers: this.headers
                            });
                            return {
                                data: t,
                                error: null
                            }
                        } catch (r) {
                            if (er(r)) return {
                                data: null,
                                error: r
                            };
                            throw r
                        }
                    })
                }
            }
            class eE extends ek {
                constructor(e, t = {}, r) {
                    super(e, t, r)
                }
                from(e) {
                    return new eb(this.url, this.headers, e, this.fetch)
                }
            }
            let eS = e => {
                    let t;
                    return t = e || ("undefined" == typeof fetch ? P() : fetch), (...e) => t(...e)
                },
                ex = () => "undefined" == typeof Headers ? A.Headers : Headers,
                eT = (e, t, r) => {
                    let i = eS(r),
                        s = ex();
                    return (r, n) => {
                        var o, a, l, u;
                        return o = void 0, a = void 0, l = void 0, u = function*() {
                            var o;
                            let a = null !== (o = yield t()) && void 0 !== o ? o : e,
                                l = new s(null == n ? void 0 : n.headers);
                            return l.has("apikey") || l.set("apikey", e), l.has("Authorization") || l.set("Authorization", `Bearer ${a}`), i(r, Object.assign(Object.assign({}, n), {
                                headers: l
                            }))
                        }, new(l || (l = Promise))(function(e, t) {
                            function r(e) {
                                try {
                                    s(u.next(e))
                                } catch (r) {
                                    t(r)
                                }
                            }

                            function i(e) {
                                try {
                                    s(u.throw(e))
                                } catch (r) {
                                    t(r)
                                }
                            }

                            function s(t) {
                                var s;
                                t.done ? e(t.value) : ((s = t.value) instanceof l ? s : new l(function(e) {
                                    e(s)
                                })).then(r, i)
                            }
                            s((u = u.apply(o, a || [])).next())
                        })
                    }
                };
            var eO = r(48764).Buffer,
                eA = function(e, t, r, i) {
                    return new(r || (r = Promise))(function(s, n) {
                        function o(e) {
                            try {
                                l(i.next(e))
                            } catch (t) {
                                n(t)
                            }
                        }

                        function a(e) {
                            try {
                                l(i.throw(e))
                            } catch (t) {
                                n(t)
                            }
                        }

                        function l(e) {
                            var t;
                            e.done ? s(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                                e(t)
                            })).then(o, a)
                        }
                        l((i = i.apply(e, t || [])).next())
                    })
                };
            let eP = () => "undefined" != typeof document;

            function eC(e, t) {
                var r;
                t || (t = (null === (r = null == window ? void 0 : window.location) || void 0 === r ? void 0 : r.href) || ""), e = e.replace(/[\[\]]/g, "\\$&");
                let i = RegExp("[?&#]" + e + "(=([^&#]*)|&|#|$)"),
                    s = i.exec(t);
                return s ? s[2] ? decodeURIComponent(s[2].replace(/\+/g, " ")) : "" : null
            }
            let ej = e => {
                    let t;
                    return t = e || ("undefined" == typeof fetch ? (...e) => eA(void 0, void 0, void 0, function*() {
                        return yield(yield Promise.resolve().then(r.t.bind(r, 54098, 23))).fetch(...e)
                    }) : fetch), (...e) => t(...e)
                },
                eR = e => "object" == typeof e && null !== e && "status" in e && "ok" in e && "json" in e && "function" == typeof e.json,
                eI = (e, t, r) => eA(void 0, void 0, void 0, function*() {
                    yield e.setItem(t, JSON.stringify(r))
                }),
                eN = (e, t) => eA(void 0, void 0, void 0, function*() {
                    let r = yield e.getItem(t);
                    if (!r) return null;
                    try {
                        return JSON.parse(r)
                    } catch (i) {
                        return r
                    }
                }),
                eU = (e, t) => eA(void 0, void 0, void 0, function*() {
                    yield e.removeItem(t)
                }),
                e$ = e => {
                    try {
                        return decodeURIComponent(atob(e.replace(/[-]/g, "+").replace(/[_]/g, "/")).split("").map(e => "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2)).join(""))
                    } catch (t) {
                        if (t instanceof ReferenceError) return eO.from(e, "base64").toString("utf-8");
                        throw t
                    }
                };
            class eL {
                constructor() {
                    this.promise = new eL.promiseConstructor((e, t) => {
                        this.resolve = e, this.reject = t
                    })
                }
            }

            function eB(e) {
                let t = e.split(".");
                if (3 !== t.length) throw Error("JWT is not valid: not a JWT structure");
                if (!/^([a-z0-9_-]{4})*($|[a-z0-9_-]{3}=?$|[a-z0-9_-]{2}(==)?$)$/i.test(t[1])) throw Error("JWT is not valid: payload is not in base64url format");
                let r = t[1];
                return JSON.parse(e$(r))
            }
            eL.promiseConstructor = Promise;
            class eM extends Error {
                constructor(e) {
                    super(e), this.__isAuthError = !0, this.name = "AuthError"
                }
            }

            function eD(e) {
                return "object" == typeof e && null !== e && "__isAuthError" in e
            }
            class eF extends eM {
                constructor(e, t) {
                    super(e), this.name = "AuthApiError", this.status = t
                }
                toJSON() {
                    return {
                        name: this.name,
                        message: this.message,
                        status: this.status
                    }
                }
            }

            function eJ(e) {
                return eD(e) && "AuthApiError" === e.name
            }
            class ez extends eM {
                constructor(e, t) {
                    super(e), this.name = "AuthUnknownError", this.originalError = t
                }
            }
            class eq extends eM {
                constructor(e, t, r) {
                    super(e), this.name = t, this.status = r
                }
                toJSON() {
                    return {
                        name: this.name,
                        message: this.message,
                        status: this.status
                    }
                }
            }
            class eH extends eq {
                constructor() {
                    super("Auth session missing!", "AuthSessionMissingError", 400)
                }
            }
            class eY extends eq {
                constructor(e) {
                    super(e, "AuthInvalidCredentialsError", 400)
                }
            }
            class eG extends eq {
                constructor(e, t = null) {
                    super(e, "AuthImplicitGrantRedirectError", 500), this.details = null, this.details = t
                }
                toJSON() {
                    return {
                        name: this.name,
                        message: this.message,
                        status: this.status,
                        details: this.details
                    }
                }
            }
            class eV extends eq {
                constructor(e, t) {
                    super(e, "AuthRetryableFetchError", t)
                }
            }
            var eX = function(e, t, r, i) {
                    return new(r || (r = Promise))(function(s, n) {
                        function o(e) {
                            try {
                                l(i.next(e))
                            } catch (t) {
                                n(t)
                            }
                        }

                        function a(e) {
                            try {
                                l(i.throw(e))
                            } catch (t) {
                                n(t)
                            }
                        }

                        function l(e) {
                            var t;
                            e.done ? s(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                                e(t)
                            })).then(o, a)
                        }
                        l((i = i.apply(e, t || [])).next())
                    })
                },
                eW = function(e, t) {
                    var r = {};
                    for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && 0 > t.indexOf(i) && (r[i] = e[i]);
                    if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                        for (var s = 0, i = Object.getOwnPropertySymbols(e); s < i.length; s++) 0 > t.indexOf(i[s]) && Object.prototype.propertyIsEnumerable.call(e, i[s]) && (r[i[s]] = e[i[s]]);
                    return r
                };
            let eK = e => e.msg || e.message || e.error_description || e.error || JSON.stringify(e),
                eZ = (e, t) => eX(void 0, void 0, void 0, function*() {
                    eR(e) ? [502, 503, 504].includes(e.status) ? t(new eV(eK(e), e.status)) : e.json().then(r => {
                        t(new eF(eK(r), e.status || 500))
                    }).catch(e => {
                        t(new ez(eK(e), e))
                    }) : t(new eV(eK(e), 0))
                }),
                eQ = (e, t, r, i) => {
                    let s = {
                        method: e,
                        headers: (null == t ? void 0 : t.headers) || {}
                    };
                    return "GET" === e ? s : (s.headers = Object.assign({
                        "Content-Type": "application/json;charset=UTF-8"
                    }, null == t ? void 0 : t.headers), s.body = JSON.stringify(i), Object.assign(Object.assign({}, s), r))
                };

            function e0(e, t, r, i) {
                var s;
                return eX(this, void 0, void 0, function*() {
                    let n = Object.assign({}, null == i ? void 0 : i.headers);
                    (null == i ? void 0 : i.jwt) && (n.Authorization = `Bearer ${i.jwt}`);
                    let o = null !== (s = null == i ? void 0 : i.query) && void 0 !== s ? s : {};
                    (null == i ? void 0 : i.redirectTo) && (o.redirect_to = i.redirectTo);
                    let a = Object.keys(o).length ? "?" + new URLSearchParams(o).toString() : "",
                        l = yield function(e, t, r, i, s, n) {
                            return eX(this, void 0, void 0, function*() {
                                return new Promise((o, a) => {
                                    e(r, eQ(t, i, s, n)).then(e => {
                                        if (!e.ok) throw e;
                                        return (null == i ? void 0 : i.noResolveJson) ? e : e.json()
                                    }).then(e => o(e)).catch(e => eZ(e, a))
                                })
                            })
                        }(e, t, r + a, {
                            headers: n,
                            noResolveJson: null == i ? void 0 : i.noResolveJson
                        }, {}, null == i ? void 0 : i.body);
                    return (null == i ? void 0 : i.xform) ? null == i ? void 0 : i.xform(l) : {
                        data: Object.assign({}, l),
                        error: null
                    }
                })
            }

            function e1(e) {
                var t;
                let r = null;
                e.access_token && e.refresh_token && e.expires_in && ((r = Object.assign({}, e)).expires_at = function(e) {
                    let t = Math.round(Date.now() / 1e3);
                    return t + e
                }(e.expires_in));
                let i = null !== (t = e.user) && void 0 !== t ? t : e;
                return {
                    data: {
                        session: r,
                        user: i
                    },
                    error: null
                }
            }

            function e2(e) {
                var t;
                let r = null !== (t = e.user) && void 0 !== t ? t : e;
                return {
                    data: {
                        user: r
                    },
                    error: null
                }
            }

            function e3(e) {
                return {
                    data: e,
                    error: null
                }
            }

            function e4(e) {
                let {
                    action_link: t,
                    email_otp: r,
                    hashed_token: i,
                    redirect_to: s,
                    verification_type: n
                } = e, o = eW(e, ["action_link", "email_otp", "hashed_token", "redirect_to", "verification_type"]), a = Object.assign({}, o);
                return {
                    data: {
                        properties: {
                            action_link: t,
                            email_otp: r,
                            hashed_token: i,
                            redirect_to: s,
                            verification_type: n
                        },
                        user: a
                    },
                    error: null
                }
            }

            function e6(e) {
                return e
            }
            var e8 = function(e, t, r, i) {
                    return new(r || (r = Promise))(function(s, n) {
                        function o(e) {
                            try {
                                l(i.next(e))
                            } catch (t) {
                                n(t)
                            }
                        }

                        function a(e) {
                            try {
                                l(i.throw(e))
                            } catch (t) {
                                n(t)
                            }
                        }

                        function l(e) {
                            var t;
                            e.done ? s(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                                e(t)
                            })).then(o, a)
                        }
                        l((i = i.apply(e, t || [])).next())
                    })
                },
                e5 = function(e, t) {
                    var r = {};
                    for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && 0 > t.indexOf(i) && (r[i] = e[i]);
                    if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                        for (var s = 0, i = Object.getOwnPropertySymbols(e); s < i.length; s++) 0 > t.indexOf(i[s]) && Object.prototype.propertyIsEnumerable.call(e, i[s]) && (r[i[s]] = e[i[s]]);
                    return r
                };
            class e9 {
                constructor({
                    url: e = "",
                    headers: t = {},
                    fetch: r
                }) {
                    this.url = e, this.headers = t, this.fetch = ej(r), this.mfa = {
                        listFactors: this._listFactors.bind(this),
                        deleteFactor: this._deleteFactor.bind(this)
                    }
                }
                signOut(e) {
                    return e8(this, void 0, void 0, function*() {
                        try {
                            return yield e0(this.fetch, "POST", `${this.url}/logout`, {
                                headers: this.headers,
                                jwt: e,
                                noResolveJson: !0
                            }), {
                                data: null,
                                error: null
                            }
                        } catch (t) {
                            if (eD(t)) return {
                                data: null,
                                error: t
                            };
                            throw t
                        }
                    })
                }
                inviteUserByEmail(e, t = {}) {
                    return e8(this, void 0, void 0, function*() {
                        try {
                            return yield e0(this.fetch, "POST", `${this.url}/invite`, {
                                body: {
                                    email: e,
                                    data: t.data
                                },
                                headers: this.headers,
                                redirectTo: t.redirectTo,
                                xform: e2
                            })
                        } catch (r) {
                            if (eD(r)) return {
                                data: {
                                    user: null
                                },
                                error: r
                            };
                            throw r
                        }
                    })
                }
                generateLink(e) {
                    return e8(this, void 0, void 0, function*() {
                        try {
                            let {
                                options: t
                            } = e, r = e5(e, ["options"]), i = Object.assign(Object.assign({}, r), t);
                            return "newEmail" in r && (i.new_email = null == r ? void 0 : r.newEmail, delete i.newEmail), yield e0(this.fetch, "POST", `${this.url}/admin/generate_link`, {
                                body: i,
                                headers: this.headers,
                                xform: e4,
                                redirectTo: null == t ? void 0 : t.redirectTo
                            })
                        } catch (s) {
                            if (eD(s)) return {
                                data: {
                                    properties: null,
                                    user: null
                                },
                                error: s
                            };
                            throw s
                        }
                    })
                }
                createUser(e) {
                    return e8(this, void 0, void 0, function*() {
                        try {
                            return yield e0(this.fetch, "POST", `${this.url}/admin/users`, {
                                body: e,
                                headers: this.headers,
                                xform: e2
                            })
                        } catch (t) {
                            if (eD(t)) return {
                                data: {
                                    user: null
                                },
                                error: t
                            };
                            throw t
                        }
                    })
                }
                listUsers(e) {
                    var t, r, i, s, n, o, a;
                    return e8(this, void 0, void 0, function*() {
                        try {
                            let l = {
                                    nextPage: null,
                                    lastPage: 0,
                                    total: 0
                                },
                                u = yield e0(this.fetch, "GET", `${this.url}/admin/users`, {
                                    headers: this.headers,
                                    noResolveJson: !0,
                                    query: {
                                        page: null !== (r = null === (t = null == e ? void 0 : e.page) || void 0 === t ? void 0 : t.toString()) && void 0 !== r ? r : "",
                                        per_page: null !== (s = null === (i = null == e ? void 0 : e.perPage) || void 0 === i ? void 0 : i.toString()) && void 0 !== s ? s : ""
                                    },
                                    xform: e6
                                });
                            if (u.error) throw u.error;
                            let h = yield u.json(), c = null !== (n = u.headers.get("x-total-count")) && void 0 !== n ? n : 0, d = null !== (a = null === (o = u.headers.get("link")) || void 0 === o ? void 0 : o.split(",")) && void 0 !== a ? a : [];
                            return d.length > 0 && (d.forEach(e => {
                                let t = parseInt(e.split(";")[0].split("=")[1].substring(0, 1)),
                                    r = JSON.parse(e.split(";")[1].split("=")[1]);
                                l[`${r}Page`] = t
                            }), l.total = parseInt(c)), {
                                data: Object.assign(Object.assign({}, h), l),
                                error: null
                            }
                        } catch (f) {
                            if (eD(f)) return {
                                data: {
                                    users: []
                                },
                                error: f
                            };
                            throw f
                        }
                    })
                }
                getUserById(e) {
                    return e8(this, void 0, void 0, function*() {
                        try {
                            return yield e0(this.fetch, "GET", `${this.url}/admin/users/${e}`, {
                                headers: this.headers,
                                xform: e2
                            })
                        } catch (t) {
                            if (eD(t)) return {
                                data: {
                                    user: null
                                },
                                error: t
                            };
                            throw t
                        }
                    })
                }
                updateUserById(e, t) {
                    return e8(this, void 0, void 0, function*() {
                        try {
                            return yield e0(this.fetch, "PUT", `${this.url}/admin/users/${e}`, {
                                body: t,
                                headers: this.headers,
                                xform: e2
                            })
                        } catch (r) {
                            if (eD(r)) return {
                                data: {
                                    user: null
                                },
                                error: r
                            };
                            throw r
                        }
                    })
                }
                deleteUser(e) {
                    return e8(this, void 0, void 0, function*() {
                        try {
                            return yield e0(this.fetch, "DELETE", `${this.url}/admin/users/${e}`, {
                                headers: this.headers,
                                xform: e2
                            })
                        } catch (t) {
                            if (eD(t)) return {
                                data: {
                                    user: null
                                },
                                error: t
                            };
                            throw t
                        }
                    })
                }
                _listFactors(e) {
                    return e8(this, void 0, void 0, function*() {
                        try {
                            let {
                                data: t,
                                error: r
                            } = yield e0(this.fetch, "GET", `${this.url}/admin/users/${e.userId}/factors`, {
                                headers: this.headers,
                                xform: e => ({
                                    data: {
                                        factors: e
                                    },
                                    error: null
                                })
                            });
                            return {
                                data: t,
                                error: r
                            }
                        } catch (i) {
                            if (eD(i)) return {
                                data: null,
                                error: i
                            };
                            throw i
                        }
                    })
                }
                _deleteFactor(e) {
                    return e8(this, void 0, void 0, function*() {
                        try {
                            let t = yield e0(this.fetch, "DELETE", `${this.url}/admin/users/${e.userId}/factors/${e.id}`, {
                                headers: this.headers
                            });
                            return {
                                data: t,
                                error: null
                            }
                        } catch (r) {
                            if (eD(r)) return {
                                data: null,
                                error: r
                            };
                            throw r
                        }
                    })
                }
            }
            let e7 = {
                MAX_RETRIES: 10,
                RETRY_INTERVAL: 2
            };
            var te = {
                    getItem: e => eP() ? globalThis.localStorage.getItem(e) : null,
                    setItem(e, t) {
                        eP() && globalThis.localStorage.setItem(e, t)
                    },
                    removeItem(e) {
                        eP() && globalThis.localStorage.removeItem(e)
                    }
                },
                tt = function(e, t, r, i) {
                    return new(r || (r = Promise))(function(s, n) {
                        function o(e) {
                            try {
                                l(i.next(e))
                            } catch (t) {
                                n(t)
                            }
                        }

                        function a(e) {
                            try {
                                l(i.throw(e))
                            } catch (t) {
                                n(t)
                            }
                        }

                        function l(e) {
                            var t;
                            e.done ? s(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                                e(t)
                            })).then(o, a)
                        }
                        l((i = i.apply(e, t || [])).next())
                    })
                };
            ! function() {
                if ("object" != typeof globalThis) try {
                    Object.defineProperty(Object.prototype, "__magic__", {
                        get: function() {
                            return this
                        },
                        configurable: !0
                    }), __magic__.globalThis = __magic__, delete Object.prototype.__magic__
                } catch (e) {
                    "undefined" != typeof self && (self.globalThis = self)
                }
            }();
            let tr = {
                url: "http://localhost:9999",
                storageKey: "supabase.auth.token",
                autoRefreshToken: !0,
                persistSession: !0,
                detectSessionInUrl: !0,
                headers: {
                    "X-Client-Info": "gotrue-js/2.6.1"
                }
            };
            class ti {
                constructor(e) {
                    this.stateChangeEmitters = new Map, this.networkRetries = 0, this.refreshingDeferred = null, this.initializePromise = null, this.detectSessionInUrl = !0;
                    let t = Object.assign(Object.assign({}, tr), e);
                    this.inMemorySession = null, this.storageKey = t.storageKey, this.autoRefreshToken = t.autoRefreshToken, this.persistSession = t.persistSession, this.storage = t.storage || te, this.admin = new e9({
                        url: t.url,
                        headers: t.headers,
                        fetch: t.fetch
                    }), this.url = t.url, this.headers = t.headers, this.fetch = ej(t.fetch), this.detectSessionInUrl = t.detectSessionInUrl, this.initialize(), this.mfa = {
                        verify: this._verify.bind(this),
                        enroll: this._enroll.bind(this),
                        unenroll: this._unenroll.bind(this),
                        challenge: this._challenge.bind(this),
                        listFactors: this._listFactors.bind(this),
                        challengeAndVerify: this._challengeAndVerify.bind(this),
                        getAuthenticatorAssuranceLevel: this._getAuthenticatorAssuranceLevel.bind(this)
                    }
                }
                initialize() {
                    return this.initializePromise || (this.initializePromise = this._initialize()), this.initializePromise
                }
                _initialize() {
                    return tt(this, void 0, void 0, function*() {
                        if (this.initializePromise) return this.initializePromise;
                        try {
                            if (this.detectSessionInUrl && this._isImplicitGrantFlow()) {
                                let {
                                    data: e,
                                    error: t
                                } = yield this._getSessionFromUrl();
                                if (t) return yield this._removeSession(), {
                                    error: t
                                };
                                let {
                                    session: r,
                                    redirectType: i
                                } = e;
                                return yield this._saveSession(r), this._notifyAllSubscribers("SIGNED_IN", r), "recovery" === i && this._notifyAllSubscribers("PASSWORD_RECOVERY", r), {
                                    error: null
                                }
                            }
                            return yield this._recoverAndRefresh(), {
                                error: null
                            }
                        } catch (s) {
                            if (eD(s)) return {
                                error: s
                            };
                            return {
                                error: new ez("Unexpected error during initialization", s)
                            }
                        } finally {
                            this._handleVisibilityChange()
                        }
                    })
                }
                signUp(e) {
                    var t, r;
                    return tt(this, void 0, void 0, function*() {
                        try {
                            let i;
                            if (yield this._removeSession(), "email" in e) {
                                let {
                                    email: s,
                                    password: n,
                                    options: o
                                } = e;
                                i = yield e0(this.fetch, "POST", `${this.url}/signup`, {
                                    headers: this.headers,
                                    redirectTo: null == o ? void 0 : o.emailRedirectTo,
                                    body: {
                                        email: s,
                                        password: n,
                                        data: null !== (t = null == o ? void 0 : o.data) && void 0 !== t ? t : {},
                                        gotrue_meta_security: {
                                            captcha_token: null == o ? void 0 : o.captchaToken
                                        }
                                    },
                                    xform: e1
                                })
                            } else if ("phone" in e) {
                                let {
                                    phone: a,
                                    password: l,
                                    options: u
                                } = e;
                                i = yield e0(this.fetch, "POST", `${this.url}/signup`, {
                                    headers: this.headers,
                                    body: {
                                        phone: a,
                                        password: l,
                                        data: null !== (r = null == u ? void 0 : u.data) && void 0 !== r ? r : {},
                                        gotrue_meta_security: {
                                            captcha_token: null == u ? void 0 : u.captchaToken
                                        }
                                    },
                                    xform: e1
                                })
                            } else throw new eY("You must provide either an email or phone number and a password");
                            let {
                                data: h,
                                error: c
                            } = i;
                            if (c || !h) return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: c
                            };
                            let d = h.session,
                                f = h.user;
                            return h.session && (yield this._saveSession(h.session), this._notifyAllSubscribers("SIGNED_IN", d)), {
                                data: {
                                    user: f,
                                    session: d
                                },
                                error: null
                            }
                        } catch (p) {
                            if (eD(p)) return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: p
                            };
                            throw p
                        }
                    })
                }
                signInWithPassword(e) {
                    var t, r;
                    return tt(this, void 0, void 0, function*() {
                        try {
                            let i;
                            if (yield this._removeSession(), "email" in e) {
                                let {
                                    email: s,
                                    password: n,
                                    options: o
                                } = e;
                                i = yield e0(this.fetch, "POST", `${this.url}/token?grant_type=password`, {
                                    headers: this.headers,
                                    body: {
                                        email: s,
                                        password: n,
                                        data: null !== (t = null == o ? void 0 : o.data) && void 0 !== t ? t : {},
                                        gotrue_meta_security: {
                                            captcha_token: null == o ? void 0 : o.captchaToken
                                        }
                                    },
                                    xform: e1
                                })
                            } else if ("phone" in e) {
                                let {
                                    phone: a,
                                    password: l,
                                    options: u
                                } = e;
                                i = yield e0(this.fetch, "POST", `${this.url}/token?grant_type=password`, {
                                    headers: this.headers,
                                    body: {
                                        phone: a,
                                        password: l,
                                        data: null !== (r = null == u ? void 0 : u.data) && void 0 !== r ? r : {},
                                        gotrue_meta_security: {
                                            captcha_token: null == u ? void 0 : u.captchaToken
                                        }
                                    },
                                    xform: e1
                                })
                            } else throw new eY("You must provide either an email or phone number and a password");
                            let {
                                data: h,
                                error: c
                            } = i;
                            if (c || !h) return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: c
                            };
                            return h.session && (yield this._saveSession(h.session), this._notifyAllSubscribers("SIGNED_IN", h.session)), {
                                data: h,
                                error: c
                            }
                        } catch (d) {
                            if (eD(d)) return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: d
                            };
                            throw d
                        }
                    })
                }
                signInWithOAuth(e) {
                    var t, r, i;
                    return tt(this, void 0, void 0, function*() {
                        return yield this._removeSession(), this._handleProviderSignIn(e.provider, {
                            redirectTo: null === (t = e.options) || void 0 === t ? void 0 : t.redirectTo,
                            scopes: null === (r = e.options) || void 0 === r ? void 0 : r.scopes,
                            queryParams: null === (i = e.options) || void 0 === i ? void 0 : i.queryParams
                        })
                    })
                }
                signInWithOtp(e) {
                    var t, r, i, s;
                    return tt(this, void 0, void 0, function*() {
                        try {
                            if (yield this._removeSession(), "email" in e) {
                                let {
                                    email: n,
                                    options: o
                                } = e, {
                                    error: a
                                } = yield e0(this.fetch, "POST", `${this.url}/otp`, {
                                    headers: this.headers,
                                    body: {
                                        email: n,
                                        data: null !== (t = null == o ? void 0 : o.data) && void 0 !== t ? t : {},
                                        create_user: null === (r = null == o ? void 0 : o.shouldCreateUser) || void 0 === r || r,
                                        gotrue_meta_security: {
                                            captcha_token: null == o ? void 0 : o.captchaToken
                                        }
                                    },
                                    redirectTo: null == o ? void 0 : o.emailRedirectTo
                                });
                                return {
                                    data: {
                                        user: null,
                                        session: null
                                    },
                                    error: a
                                }
                            }
                            if ("phone" in e) {
                                let {
                                    phone: l,
                                    options: u
                                } = e, {
                                    error: h
                                } = yield e0(this.fetch, "POST", `${this.url}/otp`, {
                                    headers: this.headers,
                                    body: {
                                        phone: l,
                                        data: null !== (i = null == u ? void 0 : u.data) && void 0 !== i ? i : {},
                                        create_user: null === (s = null == u ? void 0 : u.shouldCreateUser) || void 0 === s || s,
                                        gotrue_meta_security: {
                                            captcha_token: null == u ? void 0 : u.captchaToken
                                        }
                                    }
                                });
                                return {
                                    data: {
                                        user: null,
                                        session: null
                                    },
                                    error: h
                                }
                            }
                            throw new eY("You must provide either an email or phone number.")
                        } catch (c) {
                            if (eD(c)) return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: c
                            };
                            throw c
                        }
                    })
                }
                verifyOtp(e) {
                    var t, r;
                    return tt(this, void 0, void 0, function*() {
                        try {
                            yield this._removeSession();
                            let {
                                data: i,
                                error: s
                            } = yield e0(this.fetch, "POST", `${this.url}/verify`, {
                                headers: this.headers,
                                body: Object.assign(Object.assign({}, e), {
                                    gotrue_meta_security: {
                                        captcha_token: null === (t = e.options) || void 0 === t ? void 0 : t.captchaToken
                                    }
                                }),
                                redirectTo: null === (r = e.options) || void 0 === r ? void 0 : r.redirectTo,
                                xform: e1
                            });
                            if (s) throw s;
                            if (!i) throw "An error occurred on token verification.";
                            let n = i.session,
                                o = i.user;
                            return (null == n ? void 0 : n.access_token) && (yield this._saveSession(n), this._notifyAllSubscribers("SIGNED_IN", n)), {
                                data: {
                                    user: o,
                                    session: n
                                },
                                error: null
                            }
                        } catch (a) {
                            if (eD(a)) return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: a
                            };
                            throw a
                        }
                    })
                }
                signInWithSSO(e) {
                    var t, r, i;
                    return tt(this, void 0, void 0, function*() {
                        try {
                            return yield this._removeSession(), yield e0(this.fetch, "POST", `${this.url}/sso`, {
                                body: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, "providerId" in e ? {
                                    provider_id: e.providerId
                                } : null), "domain" in e ? {
                                    domain: e.domain
                                } : null), {
                                    redirect_to: null !== (r = null === (t = e.options) || void 0 === t ? void 0 : t.redirectTo) && void 0 !== r ? r : void 0
                                }), (null === (i = null == e ? void 0 : e.options) || void 0 === i ? void 0 : i.captchaToken) ? {
                                    gotrue_meta_security: {
                                        captcha_token: e.options.captchaToken
                                    }
                                } : null), {
                                    skip_http_redirect: !0
                                }),
                                headers: this.headers,
                                xform: e3
                            })
                        } catch (s) {
                            if (eD(s)) return {
                                data: null,
                                error: s
                            };
                            throw s
                        }
                    })
                }
                getSession() {
                    return tt(this, void 0, void 0, function*() {
                        yield this.initializePromise;
                        let e = null;
                        if (this.persistSession) {
                            let t = yield eN(this.storage, this.storageKey);
                            null !== t && (this._isValidSession(t) ? e = t : yield this._removeSession())
                        } else e = this.inMemorySession;
                        if (!e) return {
                            data: {
                                session: null
                            },
                            error: null
                        };
                        let r = !!e.expires_at && e.expires_at <= Date.now() / 1e3;
                        if (!r) return {
                            data: {
                                session: e
                            },
                            error: null
                        };
                        let {
                            session: i,
                            error: s
                        } = yield this._callRefreshToken(e.refresh_token);
                        return s ? {
                            data: {
                                session: null
                            },
                            error: s
                        } : {
                            data: {
                                session: i
                            },
                            error: null
                        }
                    })
                }
                getUser(e) {
                    var t, r;
                    return tt(this, void 0, void 0, function*() {
                        try {
                            if (!e) {
                                let {
                                    data: i,
                                    error: s
                                } = yield this.getSession();
                                if (s) throw s;
                                e = null !== (r = null === (t = i.session) || void 0 === t ? void 0 : t.access_token) && void 0 !== r ? r : void 0
                            }
                            return yield e0(this.fetch, "GET", `${this.url}/user`, {
                                headers: this.headers,
                                jwt: e,
                                xform: e2
                            })
                        } catch (n) {
                            if (eD(n)) return {
                                data: {
                                    user: null
                                },
                                error: n
                            };
                            throw n
                        }
                    })
                }
                updateUser(e) {
                    return tt(this, void 0, void 0, function*() {
                        try {
                            let {
                                data: t,
                                error: r
                            } = yield this.getSession();
                            if (r) throw r;
                            if (!t.session) throw new eH;
                            let i = t.session,
                                {
                                    data: s,
                                    error: n
                                } = yield e0(this.fetch, "PUT", `${this.url}/user`, {
                                    headers: this.headers,
                                    body: e,
                                    jwt: i.access_token,
                                    xform: e2
                                });
                            if (n) throw n;
                            return i.user = s.user, yield this._saveSession(i), this._notifyAllSubscribers("USER_UPDATED", i), {
                                data: {
                                    user: i.user
                                },
                                error: null
                            }
                        } catch (o) {
                            if (eD(o)) return {
                                data: {
                                    user: null
                                },
                                error: o
                            };
                            throw o
                        }
                    })
                }
                _decodeJWT(e) {
                    return eB(e)
                }
                setSession(e) {
                    return tt(this, void 0, void 0, function*() {
                        try {
                            if (!e.access_token || !e.refresh_token) throw new eH;
                            let t = Date.now() / 1e3,
                                r = t,
                                i = !0,
                                s = null,
                                n = eB(e.access_token);
                            if (n.exp && (i = (r = n.exp) <= t), i) {
                                let {
                                    session: o,
                                    error: a
                                } = yield this._callRefreshToken(e.refresh_token);
                                if (a) return {
                                    data: {
                                        user: null,
                                        session: null
                                    },
                                    error: a
                                };
                                if (!o) return {
                                    data: {
                                        user: null,
                                        session: null
                                    },
                                    error: null
                                };
                                s = o
                            } else {
                                let {
                                    data: l,
                                    error: u
                                } = yield this.getUser(e.access_token);
                                if (u) throw u;
                                yield this._saveSession(s = {
                                    access_token: e.access_token,
                                    refresh_token: e.refresh_token,
                                    user: l.user,
                                    token_type: "bearer",
                                    expires_in: r - t,
                                    expires_at: r
                                })
                            }
                            return {
                                data: {
                                    user: s.user,
                                    session: s
                                },
                                error: null
                            }
                        } catch (h) {
                            if (eD(h)) return {
                                data: {
                                    session: null,
                                    user: null
                                },
                                error: h
                            };
                            throw h
                        }
                    })
                }
                refreshSession(e) {
                    var t;
                    return tt(this, void 0, void 0, function*() {
                        try {
                            if (!e) {
                                let {
                                    data: r,
                                    error: i
                                } = yield this.getSession();
                                if (i) throw i;
                                e = null !== (t = r.session) && void 0 !== t ? t : void 0
                            }
                            if (!(null == e ? void 0 : e.refresh_token)) throw new eH;
                            let {
                                session: s,
                                error: n
                            } = yield this._callRefreshToken(e.refresh_token);
                            if (n) return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: n
                            };
                            if (!s) return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: null
                            };
                            return {
                                data: {
                                    user: s.user,
                                    session: s
                                },
                                error: null
                            }
                        } catch (o) {
                            if (eD(o)) return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: o
                            };
                            throw o
                        }
                    })
                }
                _getSessionFromUrl() {
                    return tt(this, void 0, void 0, function*() {
                        try {
                            if (!eP()) throw new eG("No browser detected.");
                            if (!this._isImplicitGrantFlow()) throw new eG("Not a valid implicit grant flow url.");
                            let e = eC("error_description");
                            if (e) {
                                let t = eC("error_code");
                                if (!t) throw new eG("No error_code detected.");
                                let r = eC("error");
                                if (!r) throw new eG("No error detected.");
                                throw new eG(e, {
                                    error: r,
                                    code: t
                                })
                            }
                            let i = eC("provider_token"),
                                s = eC("provider_refresh_token"),
                                n = eC("access_token");
                            if (!n) throw new eG("No access_token detected.");
                            let o = eC("expires_in");
                            if (!o) throw new eG("No expires_in detected.");
                            let a = eC("refresh_token");
                            if (!a) throw new eG("No refresh_token detected.");
                            let l = eC("token_type");
                            if (!l) throw new eG("No token_type detected.");
                            let u = Math.round(Date.now() / 1e3),
                                h = u + parseInt(o),
                                {
                                    data: c,
                                    error: d
                                } = yield this.getUser(n);
                            if (d) throw d;
                            let f = c.user,
                                p = {
                                    provider_token: i,
                                    provider_refresh_token: s,
                                    access_token: n,
                                    expires_in: parseInt(o),
                                    expires_at: h,
                                    refresh_token: a,
                                    token_type: l,
                                    user: f
                                },
                                g = eC("type");
                            return window.location.hash = "", {
                                data: {
                                    session: p,
                                    redirectType: g
                                },
                                error: null
                            }
                        } catch (m) {
                            if (eD(m)) return {
                                data: {
                                    session: null,
                                    redirectType: null
                                },
                                error: m
                            };
                            throw m
                        }
                    })
                }
                _isImplicitGrantFlow() {
                    return eP() && (Boolean(eC("access_token")) || Boolean(eC("error_description")))
                }
                signOut() {
                    var e;
                    return tt(this, void 0, void 0, function*() {
                        let {
                            data: t,
                            error: r
                        } = yield this.getSession();
                        if (r) return {
                            error: r
                        };
                        let i = null === (e = t.session) || void 0 === e ? void 0 : e.access_token;
                        if (i) {
                            let {
                                error: s
                            } = yield this.admin.signOut(i);
                            if (s && !(eJ(s) && (404 === s.status || 401 === s.status))) return {
                                error: s
                            }
                        }
                        return yield this._removeSession(), this._notifyAllSubscribers("SIGNED_OUT", null), {
                            error: null
                        }
                    })
                }
                onAuthStateChange(e) {
                    let t = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
                            let t = 16 * Math.random() | 0;
                            return ("x" == e ? t : 3 & t | 8).toString(16)
                        }),
                        r = {
                            id: t,
                            callback: e,
                            unsubscribe: () => {
                                this.stateChangeEmitters.delete(t)
                            }
                        };
                    return this.stateChangeEmitters.set(t, r), {
                        data: {
                            subscription: r
                        }
                    }
                }
                resetPasswordForEmail(e, t = {}) {
                    return tt(this, void 0, void 0, function*() {
                        try {
                            return yield e0(this.fetch, "POST", `${this.url}/recover`, {
                                body: {
                                    email: e,
                                    gotrue_meta_security: {
                                        captcha_token: t.captchaToken
                                    }
                                },
                                headers: this.headers,
                                redirectTo: t.redirectTo
                            })
                        } catch (r) {
                            if (eD(r)) return {
                                data: null,
                                error: r
                            };
                            throw r
                        }
                    })
                }
                _refreshAccessToken(e) {
                    return tt(this, void 0, void 0, function*() {
                        try {
                            return yield e0(this.fetch, "POST", `${this.url}/token?grant_type=refresh_token`, {
                                body: {
                                    refresh_token: e
                                },
                                headers: this.headers,
                                xform: e1
                            })
                        } catch (t) {
                            if (eD(t)) return {
                                data: {
                                    session: null,
                                    user: null
                                },
                                error: t
                            };
                            throw t
                        }
                    })
                }
                _isValidSession(e) {
                    return "object" == typeof e && null !== e && "access_token" in e && "refresh_token" in e && "expires_at" in e
                }
                _handleProviderSignIn(e, t = {}) {
                    let r = this._getUrlForProvider(e, {
                        redirectTo: t.redirectTo,
                        scopes: t.scopes,
                        queryParams: t.queryParams
                    });
                    return eP() && (window.location.href = r), {
                        data: {
                            provider: e,
                            url: r
                        },
                        error: null
                    }
                }
                _recoverAndRefresh() {
                    var e;
                    return tt(this, void 0, void 0, function*() {
                        try {
                            let t = yield eN(this.storage, this.storageKey);
                            if (!this._isValidSession(t)) {
                                null !== t && (yield this._removeSession());
                                return
                            }
                            let r = Math.round(Date.now() / 1e3);
                            if ((null !== (e = t.expires_at) && void 0 !== e ? e : 1 / 0) < r + 10) {
                                if (this.autoRefreshToken && t.refresh_token) {
                                    this.networkRetries++;
                                    let {
                                        error: i
                                    } = yield this._callRefreshToken(t.refresh_token);
                                    if (i) {
                                        if (console.log(i.message), i instanceof eV && this.networkRetries < e7.MAX_RETRIES) {
                                            this.refreshTokenTimer && clearTimeout(this.refreshTokenTimer), this.refreshTokenTimer = setTimeout(() => this._recoverAndRefresh(), 100 * Math.pow(e7.RETRY_INTERVAL, this.networkRetries));
                                            return
                                        }
                                        yield this._removeSession()
                                    }
                                    this.networkRetries = 0
                                } else yield this._removeSession()
                            } else this.persistSession && (yield this._saveSession(t)), this._notifyAllSubscribers("SIGNED_IN", t)
                        } catch (s) {
                            console.error(s);
                            return
                        }
                    })
                }
                _callRefreshToken(e) {
                    var t, r;
                    return tt(this, void 0, void 0, function*() {
                        if (this.refreshingDeferred) return this.refreshingDeferred.promise;
                        try {
                            if (this.refreshingDeferred = new eL, !e) throw new eH;
                            let {
                                data: i,
                                error: s
                            } = yield this._refreshAccessToken(e);
                            if (s) throw s;
                            if (!i.session) throw new eH;
                            yield this._saveSession(i.session), this._notifyAllSubscribers("TOKEN_REFRESHED", i.session);
                            let n = {
                                session: i.session,
                                error: null
                            };
                            return this.refreshingDeferred.resolve(n), n
                        } catch (a) {
                            if (eD(a)) {
                                let o = {
                                    session: null,
                                    error: a
                                };
                                return null === (t = this.refreshingDeferred) || void 0 === t || t.resolve(o), o
                            }
                            throw null === (r = this.refreshingDeferred) || void 0 === r || r.reject(a), a
                        } finally {
                            this.refreshingDeferred = null
                        }
                    })
                }
                _notifyAllSubscribers(e, t) {
                    this.stateChangeEmitters.forEach(r => r.callback(e, t))
                }
                _saveSession(e) {
                    return tt(this, void 0, void 0, function*() {
                        this.persistSession || (this.inMemorySession = e);
                        let t = e.expires_at;
                        if (t) {
                            let r = Math.round(Date.now() / 1e3),
                                i = t - r;
                            this._startAutoRefreshToken((i - (i > 10 ? 10 : .5)) * 1e3)
                        }
                        this.persistSession && e.expires_at && (yield this._persistSession(e))
                    })
                }
                _persistSession(e) {
                    return eI(this.storage, this.storageKey, e)
                }
                _removeSession() {
                    return tt(this, void 0, void 0, function*() {
                        this.persistSession ? yield eU(this.storage, this.storageKey): this.inMemorySession = null, this.refreshTokenTimer && clearTimeout(this.refreshTokenTimer)
                    })
                }
                _startAutoRefreshToken(e) {
                    this.refreshTokenTimer && clearTimeout(this.refreshTokenTimer), !(e <= 0) && this.autoRefreshToken && (this.refreshTokenTimer = setTimeout(() => tt(this, void 0, void 0, function*() {
                        this.networkRetries++;
                        let {
                            data: {
                                session: e
                            },
                            error: t
                        } = yield this.getSession();
                        if (!t && e) {
                            let {
                                error: r
                            } = yield this._callRefreshToken(e.refresh_token);
                            r || (this.networkRetries = 0), r instanceof eV && this.networkRetries < e7.MAX_RETRIES && this._startAutoRefreshToken(100 * Math.pow(e7.RETRY_INTERVAL, this.networkRetries))
                        }
                    }), e), "function" == typeof this.refreshTokenTimer.unref && this.refreshTokenTimer.unref())
                }
                _handleVisibilityChange() {
                    if (!eP() || !(null == window ? void 0 : window.addEventListener)) return !1;
                    try {
                        null == window || window.addEventListener("visibilitychange", () => tt(this, void 0, void 0, function*() {
                            "visible" === document.visibilityState && (yield this.initializePromise, yield this._recoverAndRefresh())
                        }))
                    } catch (e) {
                        console.error("_handleVisibilityChange", e)
                    }
                }
                _getUrlForProvider(e, t) {
                    let r = [`provider=${encodeURIComponent(e)}`];
                    if ((null == t ? void 0 : t.redirectTo) && r.push(`redirect_to=${encodeURIComponent(t.redirectTo)}`), (null == t ? void 0 : t.scopes) && r.push(`scopes=${encodeURIComponent(t.scopes)}`), null == t ? void 0 : t.queryParams) {
                        let i = new URLSearchParams(t.queryParams);
                        r.push(i.toString())
                    }
                    return `${this.url}/authorize?${r.join("&")}`
                }
                _unenroll(e) {
                    var t;
                    return tt(this, void 0, void 0, function*() {
                        try {
                            let {
                                data: r,
                                error: i
                            } = yield this.getSession();
                            if (i) return {
                                data: null,
                                error: i
                            };
                            return yield e0(this.fetch, "DELETE", `${this.url}/factors/${e.factorId}`, {
                                headers: this.headers,
                                jwt: null === (t = null == r ? void 0 : r.session) || void 0 === t ? void 0 : t.access_token
                            })
                        } catch (s) {
                            if (eD(s)) return {
                                data: null,
                                error: s
                            };
                            throw s
                        }
                    })
                }
                _enroll(e) {
                    var t, r;
                    return tt(this, void 0, void 0, function*() {
                        try {
                            let {
                                data: i,
                                error: s
                            } = yield this.getSession();
                            if (s) return {
                                data: null,
                                error: s
                            };
                            let {
                                data: n,
                                error: o
                            } = yield e0(this.fetch, "POST", `${this.url}/factors`, {
                                body: {
                                    friendly_name: e.friendlyName,
                                    factor_type: e.factorType,
                                    issuer: e.issuer
                                },
                                headers: this.headers,
                                jwt: null === (t = null == i ? void 0 : i.session) || void 0 === t ? void 0 : t.access_token
                            });
                            if (o) return {
                                data: null,
                                error: o
                            };
                            return (null === (r = null == n ? void 0 : n.totp) || void 0 === r ? void 0 : r.qr_code) && (n.totp.qr_code = `data:image/svg+xml;utf-8,${n.totp.qr_code}`), {
                                data: n,
                                error: null
                            }
                        } catch (a) {
                            if (eD(a)) return {
                                data: null,
                                error: a
                            };
                            throw a
                        }
                    })
                }
                _verify(e) {
                    var t;
                    return tt(this, void 0, void 0, function*() {
                        try {
                            let {
                                data: r,
                                error: i
                            } = yield this.getSession();
                            if (i) return {
                                data: null,
                                error: i
                            };
                            let {
                                data: s,
                                error: n
                            } = yield e0(this.fetch, "POST", `${this.url}/factors/${e.factorId}/verify`, {
                                body: {
                                    code: e.code,
                                    challenge_id: e.challengeId
                                },
                                headers: this.headers,
                                jwt: null === (t = null == r ? void 0 : r.session) || void 0 === t ? void 0 : t.access_token
                            });
                            if (n) return {
                                data: null,
                                error: n
                            };
                            return yield this._saveSession(Object.assign({
                                expires_at: Math.round(Date.now() / 1e3) + s.expires_in
                            }, s)), this._notifyAllSubscribers("MFA_CHALLENGE_VERIFIED", s), {
                                data: s,
                                error: n
                            }
                        } catch (o) {
                            if (eD(o)) return {
                                data: null,
                                error: o
                            };
                            throw o
                        }
                    })
                }
                _challenge(e) {
                    var t;
                    return tt(this, void 0, void 0, function*() {
                        try {
                            let {
                                data: r,
                                error: i
                            } = yield this.getSession();
                            if (i) return {
                                data: null,
                                error: i
                            };
                            return yield e0(this.fetch, "POST", `${this.url}/factors/${e.factorId}/challenge`, {
                                headers: this.headers,
                                jwt: null === (t = null == r ? void 0 : r.session) || void 0 === t ? void 0 : t.access_token
                            })
                        } catch (s) {
                            if (eD(s)) return {
                                data: null,
                                error: s
                            };
                            throw s
                        }
                    })
                }
                _challengeAndVerify(e) {
                    return tt(this, void 0, void 0, function*() {
                        let {
                            data: t,
                            error: r
                        } = yield this._challenge({
                            factorId: e.factorId
                        });
                        return r ? {
                            data: null,
                            error: r
                        } : yield this._verify({
                            factorId: e.factorId,
                            challengeId: t.id,
                            code: e.code
                        })
                    })
                }
                _listFactors() {
                    return tt(this, void 0, void 0, function*() {
                        let {
                            data: {
                                user: e
                            },
                            error: t
                        } = yield this.getUser();
                        if (t) return {
                            data: null,
                            error: t
                        };
                        let r = (null == e ? void 0 : e.factors) || [],
                            i = r.filter(e => "totp" === e.factor_type && "verified" === e.status);
                        return {
                            data: {
                                all: r,
                                totp: i
                            },
                            error: null
                        }
                    })
                }
                _getAuthenticatorAssuranceLevel() {
                    var e, t;
                    return tt(this, void 0, void 0, function*() {
                        let {
                            data: {
                                session: r
                            },
                            error: i
                        } = yield this.getSession();
                        if (i) return {
                            data: null,
                            error: i
                        };
                        if (!r) return {
                            data: {
                                currentLevel: null,
                                nextLevel: null,
                                currentAuthenticationMethods: []
                            },
                            error: null
                        };
                        let s = this._decodeJWT(r.access_token),
                            n = null;
                        s.aal && (n = s.aal);
                        let o = n,
                            a = null !== (t = null === (e = r.user.factors) || void 0 === e ? void 0 : e.filter(e => "verified" === e.status)) && void 0 !== t ? t : [];
                        a.length > 0 && (o = "aal2");
                        let l = s.amr || [];
                        return {
                            data: {
                                currentLevel: n,
                                nextLevel: o,
                                currentAuthenticationMethods: l
                            },
                            error: null
                        }
                    })
                }
            }
            class ts extends ti {
                constructor(e) {
                    super(e)
                }
            }
            let tn = {
                    headers: {
                        "X-Client-Info": "supabase-js/2.2.2"
                    }
                },
                to = {
                    schema: "public"
                },
                ta = {
                    autoRefreshToken: !0,
                    persistSession: !0,
                    detectSessionInUrl: !0
                },
                tl = {};
            class tu {
                constructor(e, t, r) {
                    var i, s, n, o, a, l, u, h;
                    if (this.supabaseUrl = e, this.supabaseKey = t, !e) throw Error("supabaseUrl is required.");
                    if (!t) throw Error("supabaseKey is required.");
                    let c = e.replace(/\/$/, "");
                    this.realtimeUrl = `${c}/realtime/v1`.replace(/^http/i, "ws"), this.authUrl = `${c}/auth/v1`, this.storageUrl = `${c}/storage/v1`;
                    let d = c.match(/(supabase\.co)|(supabase\.in)/);
                    if (d) {
                        let f = c.split(".");
                        this.functionsUrl = `${f[0]}.functions.${f[1]}.${f[2]}`
                    } else this.functionsUrl = `${c}/functions/v1`;
                    let p = `sb-${new URL(this.authUrl).hostname.split(".")[0]}-auth-token`,
                        g = {
                            db: to,
                            realtime: tl,
                            auth: Object.assign(Object.assign({}, ta), {
                                storageKey: p
                            }),
                            global: tn
                        },
                        m = function(e, t) {
                            let {
                                db: r,
                                auth: i,
                                realtime: s,
                                global: n
                            } = e, {
                                db: o,
                                auth: a,
                                realtime: l,
                                global: u
                            } = t;
                            return {
                                db: Object.assign(Object.assign({}, o), r),
                                auth: Object.assign(Object.assign({}, a), i),
                                realtime: Object.assign(Object.assign({}, l), s),
                                global: Object.assign(Object.assign({}, u), n)
                            }
                        }(null != r ? r : {}, g);
                    this.storageKey = null !== (s = null === (i = m.auth) || void 0 === i ? void 0 : i.storageKey) && void 0 !== s ? s : "", this.headers = null !== (o = null === (n = m.global) || void 0 === n ? void 0 : n.headers) && void 0 !== o ? o : {}, this.auth = this._initSupabaseAuthClient(null !== (a = m.auth) && void 0 !== a ? a : {}, this.headers, null === (l = m.global) || void 0 === l ? void 0 : l.fetch), this.fetch = eT(t, this._getAccessToken.bind(this), null === (u = m.global) || void 0 === u ? void 0 : u.fetch), this.realtime = this._initRealtimeClient(Object.assign({
                        headers: this.headers
                    }, m.realtime)), this.rest = new U(`${c}/rest/v1`, {
                        headers: this.headers,
                        schema: null === (h = m.db) || void 0 === h ? void 0 : h.schema,
                        fetch: this.fetch
                    }), this._listenForAuthEvents()
                }
                get functions() {
                    return new l(this.functionsUrl, {
                        headers: this.headers,
                        customFetch: this.fetch
                    })
                }
                get storage() {
                    return new eE(this.storageUrl, this.headers, this.fetch)
                }
                from(e) {
                    return this.rest.from(e)
                }
                rpc(e, t = {}, r) {
                    return this.rest.rpc(e, t, r)
                }
                channel(e, t = {
                    config: {}
                }) {
                    return this.realtime.channel(e, t)
                }
                getChannels() {
                    return this.realtime.getChannels()
                }
                removeChannel(e) {
                    return this.realtime.removeChannel(e)
                }
                removeAllChannels() {
                    return this.realtime.removeAllChannels()
                }
                _getAccessToken() {
                    var e, t, r, i, s, n;
                    return r = this, i = void 0, s = void 0, n = function*() {
                        let {
                            data: r
                        } = yield this.auth.getSession();
                        return null !== (t = null === (e = r.session) || void 0 === e ? void 0 : e.access_token) && void 0 !== t ? t : null
                    }, new(s || (s = Promise))(function(e, t) {
                        function o(e) {
                            try {
                                l(n.next(e))
                            } catch (r) {
                                t(r)
                            }
                        }

                        function a(e) {
                            try {
                                l(n.throw(e))
                            } catch (r) {
                                t(r)
                            }
                        }

                        function l(t) {
                            var r;
                            t.done ? e(t.value) : ((r = t.value) instanceof s ? r : new s(function(e) {
                                e(r)
                            })).then(o, a)
                        }
                        l((n = n.apply(r, i || [])).next())
                    })
                }
                _initSupabaseAuthClient({
                    autoRefreshToken: e,
                    persistSession: t,
                    detectSessionInUrl: r,
                    storage: i,
                    storageKey: s
                }, n, o) {
                    let a = {
                        Authorization: `Bearer ${this.supabaseKey}`,
                        apikey: `${this.supabaseKey}`
                    };
                    return new ts({
                        url: this.authUrl,
                        headers: Object.assign(Object.assign({}, a), n),
                        storageKey: s,
                        autoRefreshToken: e,
                        persistSession: t,
                        detectSessionInUrl: r,
                        storage: i,
                        fetch: o
                    })
                }
                _initRealtimeClient(e) {
                    return new ee(this.realtimeUrl, Object.assign(Object.assign({}, e), {
                        params: Object.assign({
                            apikey: this.supabaseKey
                        }, null == e ? void 0 : e.params)
                    }))
                }
                _listenForAuthEvents() {
                    return this.auth.onAuthStateChange((e, t) => {
                        this._handleTokenChanged(e, null == t ? void 0 : t.access_token, "CLIENT")
                    })
                }
                _handleTokenChanged(e, t, r) {
                    ("TOKEN_REFRESHED" === e || "SIGNED_IN" === e) && this.changedAccessToken !== t ? (this.realtime.setAuth(null != t ? t : null), this.changedAccessToken = t) : ("SIGNED_OUT" === e || "USER_DELETED" === e) && (this.realtime.setAuth(this.supabaseKey), "STORAGE" == r && this.auth.signOut())
                }
            }
            let th = (e, t, r) => new tu(e, t, r)
        },
        79742: function(e, t) {
            "use strict";
            t.byteLength = function(e) {
                var t = l(e),
                    r = t[0],
                    i = t[1];
                return (r + i) * 3 / 4 - i
            }, t.toByteArray = function(e) {
                var t, r, n = l(e),
                    o = n[0],
                    a = n[1],
                    u = new s((o + a) * 3 / 4 - a),
                    h = 0,
                    c = a > 0 ? o - 4 : o;
                for (r = 0; r < c; r += 4) t = i[e.charCodeAt(r)] << 18 | i[e.charCodeAt(r + 1)] << 12 | i[e.charCodeAt(r + 2)] << 6 | i[e.charCodeAt(r + 3)], u[h++] = t >> 16 & 255, u[h++] = t >> 8 & 255, u[h++] = 255 & t;
                return 2 === a && (t = i[e.charCodeAt(r)] << 2 | i[e.charCodeAt(r + 1)] >> 4, u[h++] = 255 & t), 1 === a && (t = i[e.charCodeAt(r)] << 10 | i[e.charCodeAt(r + 1)] << 4 | i[e.charCodeAt(r + 2)] >> 2, u[h++] = t >> 8 & 255, u[h++] = 255 & t), u
            }, t.fromByteArray = function(e) {
                for (var t, i = e.length, s = i % 3, n = [], o = 0, a = i - s; o < a; o += 16383) n.push(function(e, t, i) {
                    for (var s, n = [], o = t; o < i; o += 3) n.push(r[(s = (e[o] << 16 & 16711680) + (e[o + 1] << 8 & 65280) + (255 & e[o + 2])) >> 18 & 63] + r[s >> 12 & 63] + r[s >> 6 & 63] + r[63 & s]);
                    return n.join("")
                }(e, o, o + 16383 > a ? a : o + 16383));
                return 1 === s ? n.push(r[(t = e[i - 1]) >> 2] + r[t << 4 & 63] + "==") : 2 === s && n.push(r[(t = (e[i - 2] << 8) + e[i - 1]) >> 10] + r[t >> 4 & 63] + r[t << 2 & 63] + "="), n.join("")
            };
            for (var r = [], i = [], s = "undefined" != typeof Uint8Array ? Uint8Array : Array, n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", o = 0, a = n.length; o < a; ++o) r[o] = n[o], i[n.charCodeAt(o)] = o;

            function l(e) {
                var t = e.length;
                if (t % 4 > 0) throw Error("Invalid string. Length must be a multiple of 4");
                var r = e.indexOf("="); - 1 === r && (r = t);
                var i = r === t ? 0 : 4 - r % 4;
                return [r, i]
            }
            i["-".charCodeAt(0)] = 62, i["_".charCodeAt(0)] = 63
        },
        48764: function(e, t, r) {
            "use strict";
            /*!
             * The buffer module from node.js, for the browser.
             *
             * @author   Feross Aboukhadijeh <http://feross.org>
             * @license  MIT
             */
            var i = r(79742),
                s = r(80645),
                n = r(5826);

            function o() {
                return l.TYPED_ARRAY_SUPPORT ? 2147483647 : 1073741823
            }

            function a(e, t) {
                if (o() < t) throw RangeError("Invalid typed array length");
                return l.TYPED_ARRAY_SUPPORT ? (e = new Uint8Array(t)).__proto__ = l.prototype : (null === e && (e = new l(t)), e.length = t), e
            }

            function l(e, t, r) {
                if (!l.TYPED_ARRAY_SUPPORT && !(this instanceof l)) return new l(e, t, r);
                if ("number" == typeof e) {
                    if ("string" == typeof t) throw Error("If encoding is specified then the first argument must be a string");
                    return c(this, e)
                }
                return u(this, e, t, r)
            }

            function u(e, t, r, i) {
                if ("number" == typeof t) throw TypeError('"value" argument must not be a number');
                return "undefined" != typeof ArrayBuffer && t instanceof ArrayBuffer ? function(e, t, r, i) {
                    if (t.byteLength, r < 0 || t.byteLength < r) throw RangeError("'offset' is out of bounds");
                    if (t.byteLength < r + (i || 0)) throw RangeError("'length' is out of bounds");
                    return t = void 0 === r && void 0 === i ? new Uint8Array(t) : void 0 === i ? new Uint8Array(t, r) : new Uint8Array(t, r, i), l.TYPED_ARRAY_SUPPORT ? (e = t).__proto__ = l.prototype : e = d(e, t), e
                }(e, t, r, i) : "string" == typeof t ? function(e, t, r) {
                    if (("string" != typeof r || "" === r) && (r = "utf8"), !l.isEncoding(r)) throw TypeError('"encoding" must be a valid string encoding');
                    var i = 0 | p(t, r),
                        s = (e = a(e, i)).write(t, r);
                    return s !== i && (e = e.slice(0, s)), e
                }(e, t, r) : function(e, t) {
                    if (l.isBuffer(t)) {
                        var r, i = 0 | f(t.length);
                        return 0 === (e = a(e, i)).length || t.copy(e, 0, 0, i), e
                    }
                    if (t) {
                        if ("undefined" != typeof ArrayBuffer && t.buffer instanceof ArrayBuffer || "length" in t) return "number" != typeof t.length || (r = t.length) != r ? a(e, 0) : d(e, t);
                        if ("Buffer" === t.type && n(t.data)) return d(e, t.data)
                    }
                    throw TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.")
                }(e, t)
            }

            function h(e) {
                if ("number" != typeof e) throw TypeError('"size" argument must be a number');
                if (e < 0) throw RangeError('"size" argument must not be negative')
            }

            function c(e, t) {
                if (h(t), e = a(e, t < 0 ? 0 : 0 | f(t)), !l.TYPED_ARRAY_SUPPORT)
                    for (var r = 0; r < t; ++r) e[r] = 0;
                return e
            }

            function d(e, t) {
                var r = t.length < 0 ? 0 : 0 | f(t.length);
                e = a(e, r);
                for (var i = 0; i < r; i += 1) e[i] = 255 & t[i];
                return e
            }

            function f(e) {
                if (e >= o()) throw RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + o().toString(16) + " bytes");
                return 0 | e
            }

            function p(e, t) {
                if (l.isBuffer(e)) return e.length;
                if ("undefined" != typeof ArrayBuffer && "function" == typeof ArrayBuffer.isView && (ArrayBuffer.isView(e) || e instanceof ArrayBuffer)) return e.byteLength;
                "string" != typeof e && (e = "" + e);
                var r = e.length;
                if (0 === r) return 0;
                for (var i = !1;;) switch (t) {
                    case "ascii":
                    case "latin1":
                    case "binary":
                        return r;
                    case "utf8":
                    case "utf-8":
                    case void 0:
                        return A(e).length;
                    case "ucs2":
                    case "ucs-2":
                    case "utf16le":
                    case "utf-16le":
                        return 2 * r;
                    case "hex":
                        return r >>> 1;
                    case "base64":
                        return C(e).length;
                    default:
                        if (i) return A(e).length;
                        t = ("" + t).toLowerCase(), i = !0
                }
            }

            function g(e, t, r) {
                var s, n, o = !1;
                if ((void 0 === t || t < 0) && (t = 0), t > this.length || ((void 0 === r || r > this.length) && (r = this.length), r <= 0 || (r >>>= 0) <= (t >>>= 0))) return "";
                for (e || (e = "utf8");;) switch (e) {
                    case "hex":
                        return function(e, t, r) {
                            var i, s = e.length;
                            (!t || t < 0) && (t = 0), (!r || r < 0 || r > s) && (r = s);
                            for (var n = "", o = t; o < r; ++o) n += (i = e[o]) < 16 ? "0" + i.toString(16) : i.toString(16);
                            return n
                        }(this, t, r);
                    case "utf8":
                    case "utf-8":
                        return b(this, t, r);
                    case "ascii":
                        return function(e, t, r) {
                            var i = "";
                            r = Math.min(e.length, r);
                            for (var s = t; s < r; ++s) i += String.fromCharCode(127 & e[s]);
                            return i
                        }(this, t, r);
                    case "latin1":
                    case "binary":
                        return function(e, t, r) {
                            var i = "";
                            r = Math.min(e.length, r);
                            for (var s = t; s < r; ++s) i += String.fromCharCode(e[s]);
                            return i
                        }(this, t, r);
                    case "base64":
                        return s = t, n = r, 0 === s && n === this.length ? i.fromByteArray(this) : i.fromByteArray(this.slice(s, n));
                    case "ucs2":
                    case "ucs-2":
                    case "utf16le":
                    case "utf-16le":
                        return function(e, t, r) {
                            for (var i = e.slice(t, r), s = "", n = 0; n < i.length; n += 2) s += String.fromCharCode(i[n] + 256 * i[n + 1]);
                            return s
                        }(this, t, r);
                    default:
                        if (o) throw TypeError("Unknown encoding: " + e);
                        e = (e + "").toLowerCase(), o = !0
                }
            }

            function m(e, t, r) {
                var i = e[t];
                e[t] = e[r], e[r] = i
            }

            function v(e, t, r, i, s) {
                if (0 === e.length) return -1;
                if ("string" == typeof r ? (i = r, r = 0) : r > 2147483647 ? r = 2147483647 : r < -2147483648 && (r = -2147483648), isNaN(r = +r) && (r = s ? 0 : e.length - 1), r < 0 && (r = e.length + r), r >= e.length) {
                    if (s) return -1;
                    r = e.length - 1
                } else if (r < 0) {
                    if (!s) return -1;
                    r = 0
                }
                if ("string" == typeof t && (t = l.from(t, i)), l.isBuffer(t)) return 0 === t.length ? -1 : y(e, t, r, i, s);
                if ("number" == typeof t) return (t &= 255, l.TYPED_ARRAY_SUPPORT && "function" == typeof Uint8Array.prototype.indexOf) ? s ? Uint8Array.prototype.indexOf.call(e, t, r) : Uint8Array.prototype.lastIndexOf.call(e, t, r) : y(e, [t], r, i, s);
                throw TypeError("val must be string, number or Buffer")
            }

            function y(e, t, r, i, s) {
                var n, o = 1,
                    a = e.length,
                    l = t.length;
                if (void 0 !== i && ("ucs2" === (i = String(i).toLowerCase()) || "ucs-2" === i || "utf16le" === i || "utf-16le" === i)) {
                    if (e.length < 2 || t.length < 2) return -1;
                    o = 2, a /= 2, l /= 2, r /= 2
                }

                function u(e, t) {
                    return 1 === o ? e[t] : e.readUInt16BE(t * o)
                }
                if (s) {
                    var h = -1;
                    for (n = r; n < a; n++)
                        if (u(e, n) === u(t, -1 === h ? 0 : n - h)) {
                            if (-1 === h && (h = n), n - h + 1 === l) return h * o
                        } else -1 !== h && (n -= n - h), h = -1
                } else
                    for (r + l > a && (r = a - l), n = r; n >= 0; n--) {
                        for (var c = !0, d = 0; d < l; d++)
                            if (u(e, n + d) !== u(t, d)) {
                                c = !1;
                                break
                            }
                        if (c) return n
                    }
                return -1
            }

            function b(e, t, r) {
                r = Math.min(e.length, r);
                for (var i = [], s = t; s < r;) {
                    var n, o, a, l, u = e[s],
                        h = null,
                        c = u > 239 ? 4 : u > 223 ? 3 : u > 191 ? 2 : 1;
                    if (s + c <= r) switch (c) {
                        case 1:
                            u < 128 && (h = u);
                            break;
                        case 2:
                            (192 & (n = e[s + 1])) == 128 && (l = (31 & u) << 6 | 63 & n) > 127 && (h = l);
                            break;
                        case 3:
                            n = e[s + 1], o = e[s + 2], (192 & n) == 128 && (192 & o) == 128 && (l = (15 & u) << 12 | (63 & n) << 6 | 63 & o) > 2047 && (l < 55296 || l > 57343) && (h = l);
                            break;
                        case 4:
                            n = e[s + 1], o = e[s + 2], a = e[s + 3], (192 & n) == 128 && (192 & o) == 128 && (192 & a) == 128 && (l = (15 & u) << 18 | (63 & n) << 12 | (63 & o) << 6 | 63 & a) > 65535 && l < 1114112 && (h = l)
                    }
                    null === h ? (h = 65533, c = 1) : h > 65535 && (h -= 65536, i.push(h >>> 10 & 1023 | 55296), h = 56320 | 1023 & h), i.push(h), s += c
                }
                return function(e) {
                    var t = e.length;
                    if (t <= 4096) return String.fromCharCode.apply(String, e);
                    for (var r = "", i = 0; i < t;) r += String.fromCharCode.apply(String, e.slice(i, i += 4096));
                    return r
                }(i)
            }

            function w(e, t, r) {
                if (e % 1 != 0 || e < 0) throw RangeError("offset is not uint");
                if (e + t > r) throw RangeError("Trying to access beyond buffer length")
            }

            function _(e, t, r, i, s, n) {
                if (!l.isBuffer(e)) throw TypeError('"buffer" argument must be a Buffer instance');
                if (t > s || t < n) throw RangeError('"value" argument is out of bounds');
                if (r + i > e.length) throw RangeError("Index out of range")
            }

            function k(e, t, r, i) {
                t < 0 && (t = 65535 + t + 1);
                for (var s = 0, n = Math.min(e.length - r, 2); s < n; ++s) e[r + s] = (t & 255 << 8 * (i ? s : 1 - s)) >>> (i ? s : 1 - s) * 8
            }

            function E(e, t, r, i) {
                t < 0 && (t = 4294967295 + t + 1);
                for (var s = 0, n = Math.min(e.length - r, 4); s < n; ++s) e[r + s] = t >>> (i ? s : 3 - s) * 8 & 255
            }

            function S(e, t, r, i, s, n) {
                if (r + i > e.length || r < 0) throw RangeError("Index out of range")
            }

            function x(e, t, r, i, n) {
                return n || S(e, t, r, 4, 34028234663852886e22, -34028234663852886e22), s.write(e, t, r, i, 23, 4), r + 4
            }

            function T(e, t, r, i, n) {
                return n || S(e, t, r, 8, 17976931348623157e292, -17976931348623157e292), s.write(e, t, r, i, 52, 8), r + 8
            }
            t.Buffer = l, t.SlowBuffer = function(e) {
                return +e != e && (e = 0), l.alloc(+e)
            }, t.INSPECT_MAX_BYTES = 50, l.TYPED_ARRAY_SUPPORT = void 0 !== r.g.TYPED_ARRAY_SUPPORT ? r.g.TYPED_ARRAY_SUPPORT : function() {
                try {
                    var e = new Uint8Array(1);
                    return e.__proto__ = {
                        __proto__: Uint8Array.prototype,
                        foo: function() {
                            return 42
                        }
                    }, 42 === e.foo() && "function" == typeof e.subarray && 0 === e.subarray(1, 1).byteLength
                } catch (t) {
                    return !1
                }
            }(), t.kMaxLength = o(), l.poolSize = 8192, l._augment = function(e) {
                return e.__proto__ = l.prototype, e
            }, l.from = function(e, t, r) {
                return u(null, e, t, r)
            }, l.TYPED_ARRAY_SUPPORT && (l.prototype.__proto__ = Uint8Array.prototype, l.__proto__ = Uint8Array, "undefined" != typeof Symbol && Symbol.species && l[Symbol.species] === l && Object.defineProperty(l, Symbol.species, {
                value: null,
                configurable: !0
            })), l.alloc = function(e, t, r) {
                return (h(e), e <= 0) ? a(null, e) : void 0 !== t ? "string" == typeof r ? a(null, e).fill(t, r) : a(null, e).fill(t) : a(null, e)
            }, l.allocUnsafe = function(e) {
                return c(null, e)
            }, l.allocUnsafeSlow = function(e) {
                return c(null, e)
            }, l.isBuffer = function(e) {
                return !!(null != e && e._isBuffer)
            }, l.compare = function(e, t) {
                if (!l.isBuffer(e) || !l.isBuffer(t)) throw TypeError("Arguments must be Buffers");
                if (e === t) return 0;
                for (var r = e.length, i = t.length, s = 0, n = Math.min(r, i); s < n; ++s)
                    if (e[s] !== t[s]) {
                        r = e[s], i = t[s];
                        break
                    }
                return r < i ? -1 : i < r ? 1 : 0
            }, l.isEncoding = function(e) {
                switch (String(e).toLowerCase()) {
                    case "hex":
                    case "utf8":
                    case "utf-8":
                    case "ascii":
                    case "latin1":
                    case "binary":
                    case "base64":
                    case "ucs2":
                    case "ucs-2":
                    case "utf16le":
                    case "utf-16le":
                        return !0;
                    default:
                        return !1
                }
            }, l.concat = function(e, t) {
                if (!n(e)) throw TypeError('"list" argument must be an Array of Buffers');
                if (0 === e.length) return l.alloc(0);
                if (void 0 === t)
                    for (r = 0, t = 0; r < e.length; ++r) t += e[r].length;
                var r, i = l.allocUnsafe(t),
                    s = 0;
                for (r = 0; r < e.length; ++r) {
                    var o = e[r];
                    if (!l.isBuffer(o)) throw TypeError('"list" argument must be an Array of Buffers');
                    o.copy(i, s), s += o.length
                }
                return i
            }, l.byteLength = p, l.prototype._isBuffer = !0, l.prototype.swap16 = function() {
                var e = this.length;
                if (e % 2 != 0) throw RangeError("Buffer size must be a multiple of 16-bits");
                for (var t = 0; t < e; t += 2) m(this, t, t + 1);
                return this
            }, l.prototype.swap32 = function() {
                var e = this.length;
                if (e % 4 != 0) throw RangeError("Buffer size must be a multiple of 32-bits");
                for (var t = 0; t < e; t += 4) m(this, t, t + 3), m(this, t + 1, t + 2);
                return this
            }, l.prototype.swap64 = function() {
                var e = this.length;
                if (e % 8 != 0) throw RangeError("Buffer size must be a multiple of 64-bits");
                for (var t = 0; t < e; t += 8) m(this, t, t + 7), m(this, t + 1, t + 6), m(this, t + 2, t + 5), m(this, t + 3, t + 4);
                return this
            }, l.prototype.toString = function() {
                var e = 0 | this.length;
                return 0 === e ? "" : 0 == arguments.length ? b(this, 0, e) : g.apply(this, arguments)
            }, l.prototype.equals = function(e) {
                if (!l.isBuffer(e)) throw TypeError("Argument must be a Buffer");
                return this === e || 0 === l.compare(this, e)
            }, l.prototype.inspect = function() {
                var e = "",
                    r = t.INSPECT_MAX_BYTES;
                return this.length > 0 && (e = this.toString("hex", 0, r).match(/.{2}/g).join(" "), this.length > r && (e += " ... ")), "<Buffer " + e + ">"
            }, l.prototype.compare = function(e, t, r, i, s) {
                if (!l.isBuffer(e)) throw TypeError("Argument must be a Buffer");
                if (void 0 === t && (t = 0), void 0 === r && (r = e ? e.length : 0), void 0 === i && (i = 0), void 0 === s && (s = this.length), t < 0 || r > e.length || i < 0 || s > this.length) throw RangeError("out of range index");
                if (i >= s && t >= r) return 0;
                if (i >= s) return -1;
                if (t >= r) return 1;
                if (t >>>= 0, r >>>= 0, i >>>= 0, s >>>= 0, this === e) return 0;
                for (var n = s - i, o = r - t, a = Math.min(n, o), u = this.slice(i, s), h = e.slice(t, r), c = 0; c < a; ++c)
                    if (u[c] !== h[c]) {
                        n = u[c], o = h[c];
                        break
                    }
                return n < o ? -1 : o < n ? 1 : 0
            }, l.prototype.includes = function(e, t, r) {
                return -1 !== this.indexOf(e, t, r)
            }, l.prototype.indexOf = function(e, t, r) {
                return v(this, e, t, r, !0)
            }, l.prototype.lastIndexOf = function(e, t, r) {
                return v(this, e, t, r, !1)
            }, l.prototype.write = function(e, t, r, i) {
                if (void 0 === t) i = "utf8", r = this.length, t = 0;
                else if (void 0 === r && "string" == typeof t) i = t, r = this.length, t = 0;
                else if (isFinite(t)) t |= 0, isFinite(r) ? (r |= 0, void 0 === i && (i = "utf8")) : (i = r, r = void 0);
                else throw Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
                var s, n, o, a, l, u, h, c, d, f, p, g, m = this.length - t;
                if ((void 0 === r || r > m) && (r = m), e.length > 0 && (r < 0 || t < 0) || t > this.length) throw RangeError("Attempt to write outside buffer bounds");
                i || (i = "utf8");
                for (var v = !1;;) switch (i) {
                    case "hex":
                        return function(e, t, r, i) {
                            r = Number(r) || 0;
                            var s = e.length - r;
                            i ? (i = Number(i)) > s && (i = s) : i = s;
                            var n = t.length;
                            if (n % 2 != 0) throw TypeError("Invalid hex string");
                            i > n / 2 && (i = n / 2);
                            for (var o = 0; o < i; ++o) {
                                var a = parseInt(t.substr(2 * o, 2), 16);
                                if (isNaN(a)) break;
                                e[r + o] = a
                            }
                            return o
                        }(this, e, t, r);
                    case "utf8":
                    case "utf-8":
                        return l = t, u = r, j(A(e, this.length - l), this, l, u);
                    case "ascii":
                        return h = t, c = r, j(P(e), this, h, c);
                    case "latin1":
                    case "binary":
                        return s = this, n = e, o = t, a = r, j(P(n), s, o, a);
                    case "base64":
                        return d = t, f = r, j(C(e), this, d, f);
                    case "ucs2":
                    case "ucs-2":
                    case "utf16le":
                    case "utf-16le":
                        return p = t, g = r, j(function(e, t) {
                            for (var r, i, s = [], n = 0; n < e.length && !((t -= 2) < 0); ++n) i = (r = e.charCodeAt(n)) >> 8, s.push(r % 256), s.push(i);
                            return s
                        }(e, this.length - p), this, p, g);
                    default:
                        if (v) throw TypeError("Unknown encoding: " + i);
                        i = ("" + i).toLowerCase(), v = !0
                }
            }, l.prototype.toJSON = function() {
                return {
                    type: "Buffer",
                    data: Array.prototype.slice.call(this._arr || this, 0)
                }
            }, l.prototype.slice = function(e, t) {
                var r, i = this.length;
                if (e = ~~e, t = void 0 === t ? i : ~~t, e < 0 ? (e += i) < 0 && (e = 0) : e > i && (e = i), t < 0 ? (t += i) < 0 && (t = 0) : t > i && (t = i), t < e && (t = e), l.TYPED_ARRAY_SUPPORT)(r = this.subarray(e, t)).__proto__ = l.prototype;
                else {
                    var s = t - e;
                    r = new l(s, void 0);
                    for (var n = 0; n < s; ++n) r[n] = this[n + e]
                }
                return r
            }, l.prototype.readUIntLE = function(e, t, r) {
                e |= 0, t |= 0, r || w(e, t, this.length);
                for (var i = this[e], s = 1, n = 0; ++n < t && (s *= 256);) i += this[e + n] * s;
                return i
            }, l.prototype.readUIntBE = function(e, t, r) {
                e |= 0, t |= 0, r || w(e, t, this.length);
                for (var i = this[e + --t], s = 1; t > 0 && (s *= 256);) i += this[e + --t] * s;
                return i
            }, l.prototype.readUInt8 = function(e, t) {
                return t || w(e, 1, this.length), this[e]
            }, l.prototype.readUInt16LE = function(e, t) {
                return t || w(e, 2, this.length), this[e] | this[e + 1] << 8
            }, l.prototype.readUInt16BE = function(e, t) {
                return t || w(e, 2, this.length), this[e] << 8 | this[e + 1]
            }, l.prototype.readUInt32LE = function(e, t) {
                return t || w(e, 4, this.length), (this[e] | this[e + 1] << 8 | this[e + 2] << 16) + 16777216 * this[e + 3]
            }, l.prototype.readUInt32BE = function(e, t) {
                return t || w(e, 4, this.length), 16777216 * this[e] + (this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3])
            }, l.prototype.readIntLE = function(e, t, r) {
                e |= 0, t |= 0, r || w(e, t, this.length);
                for (var i = this[e], s = 1, n = 0; ++n < t && (s *= 256);) i += this[e + n] * s;
                return i >= (s *= 128) && (i -= Math.pow(2, 8 * t)), i
            }, l.prototype.readIntBE = function(e, t, r) {
                e |= 0, t |= 0, r || w(e, t, this.length);
                for (var i = t, s = 1, n = this[e + --i]; i > 0 && (s *= 256);) n += this[e + --i] * s;
                return n >= (s *= 128) && (n -= Math.pow(2, 8 * t)), n
            }, l.prototype.readInt8 = function(e, t) {
                return (t || w(e, 1, this.length), 128 & this[e]) ? -((255 - this[e] + 1) * 1) : this[e]
            }, l.prototype.readInt16LE = function(e, t) {
                t || w(e, 2, this.length);
                var r = this[e] | this[e + 1] << 8;
                return 32768 & r ? 4294901760 | r : r
            }, l.prototype.readInt16BE = function(e, t) {
                t || w(e, 2, this.length);
                var r = this[e + 1] | this[e] << 8;
                return 32768 & r ? 4294901760 | r : r
            }, l.prototype.readInt32LE = function(e, t) {
                return t || w(e, 4, this.length), this[e] | this[e + 1] << 8 | this[e + 2] << 16 | this[e + 3] << 24
            }, l.prototype.readInt32BE = function(e, t) {
                return t || w(e, 4, this.length), this[e] << 24 | this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3]
            }, l.prototype.readFloatLE = function(e, t) {
                return t || w(e, 4, this.length), s.read(this, e, !0, 23, 4)
            }, l.prototype.readFloatBE = function(e, t) {
                return t || w(e, 4, this.length), s.read(this, e, !1, 23, 4)
            }, l.prototype.readDoubleLE = function(e, t) {
                return t || w(e, 8, this.length), s.read(this, e, !0, 52, 8)
            }, l.prototype.readDoubleBE = function(e, t) {
                return t || w(e, 8, this.length), s.read(this, e, !1, 52, 8)
            }, l.prototype.writeUIntLE = function(e, t, r, i) {
                if (e = +e, t |= 0, r |= 0, !i) {
                    var s = Math.pow(2, 8 * r) - 1;
                    _(this, e, t, r, s, 0)
                }
                var n = 1,
                    o = 0;
                for (this[t] = 255 & e; ++o < r && (n *= 256);) this[t + o] = e / n & 255;
                return t + r
            }, l.prototype.writeUIntBE = function(e, t, r, i) {
                if (e = +e, t |= 0, r |= 0, !i) {
                    var s = Math.pow(2, 8 * r) - 1;
                    _(this, e, t, r, s, 0)
                }
                var n = r - 1,
                    o = 1;
                for (this[t + n] = 255 & e; --n >= 0 && (o *= 256);) this[t + n] = e / o & 255;
                return t + r
            }, l.prototype.writeUInt8 = function(e, t, r) {
                return e = +e, t |= 0, r || _(this, e, t, 1, 255, 0), l.TYPED_ARRAY_SUPPORT || (e = Math.floor(e)), this[t] = 255 & e, t + 1
            }, l.prototype.writeUInt16LE = function(e, t, r) {
                return e = +e, t |= 0, r || _(this, e, t, 2, 65535, 0), l.TYPED_ARRAY_SUPPORT ? (this[t] = 255 & e, this[t + 1] = e >>> 8) : k(this, e, t, !0), t + 2
            }, l.prototype.writeUInt16BE = function(e, t, r) {
                return e = +e, t |= 0, r || _(this, e, t, 2, 65535, 0), l.TYPED_ARRAY_SUPPORT ? (this[t] = e >>> 8, this[t + 1] = 255 & e) : k(this, e, t, !1), t + 2
            }, l.prototype.writeUInt32LE = function(e, t, r) {
                return e = +e, t |= 0, r || _(this, e, t, 4, 4294967295, 0), l.TYPED_ARRAY_SUPPORT ? (this[t + 3] = e >>> 24, this[t + 2] = e >>> 16, this[t + 1] = e >>> 8, this[t] = 255 & e) : E(this, e, t, !0), t + 4
            }, l.prototype.writeUInt32BE = function(e, t, r) {
                return e = +e, t |= 0, r || _(this, e, t, 4, 4294967295, 0), l.TYPED_ARRAY_SUPPORT ? (this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = 255 & e) : E(this, e, t, !1), t + 4
            }, l.prototype.writeIntLE = function(e, t, r, i) {
                if (e = +e, t |= 0, !i) {
                    var s = Math.pow(2, 8 * r - 1);
                    _(this, e, t, r, s - 1, -s)
                }
                var n = 0,
                    o = 1,
                    a = 0;
                for (this[t] = 255 & e; ++n < r && (o *= 256);) e < 0 && 0 === a && 0 !== this[t + n - 1] && (a = 1), this[t + n] = (e / o >> 0) - a & 255;
                return t + r
            }, l.prototype.writeIntBE = function(e, t, r, i) {
                if (e = +e, t |= 0, !i) {
                    var s = Math.pow(2, 8 * r - 1);
                    _(this, e, t, r, s - 1, -s)
                }
                var n = r - 1,
                    o = 1,
                    a = 0;
                for (this[t + n] = 255 & e; --n >= 0 && (o *= 256);) e < 0 && 0 === a && 0 !== this[t + n + 1] && (a = 1), this[t + n] = (e / o >> 0) - a & 255;
                return t + r
            }, l.prototype.writeInt8 = function(e, t, r) {
                return e = +e, t |= 0, r || _(this, e, t, 1, 127, -128), l.TYPED_ARRAY_SUPPORT || (e = Math.floor(e)), e < 0 && (e = 255 + e + 1), this[t] = 255 & e, t + 1
            }, l.prototype.writeInt16LE = function(e, t, r) {
                return e = +e, t |= 0, r || _(this, e, t, 2, 32767, -32768), l.TYPED_ARRAY_SUPPORT ? (this[t] = 255 & e, this[t + 1] = e >>> 8) : k(this, e, t, !0), t + 2
            }, l.prototype.writeInt16BE = function(e, t, r) {
                return e = +e, t |= 0, r || _(this, e, t, 2, 32767, -32768), l.TYPED_ARRAY_SUPPORT ? (this[t] = e >>> 8, this[t + 1] = 255 & e) : k(this, e, t, !1), t + 2
            }, l.prototype.writeInt32LE = function(e, t, r) {
                return e = +e, t |= 0, r || _(this, e, t, 4, 2147483647, -2147483648), l.TYPED_ARRAY_SUPPORT ? (this[t] = 255 & e, this[t + 1] = e >>> 8, this[t + 2] = e >>> 16, this[t + 3] = e >>> 24) : E(this, e, t, !0), t + 4
            }, l.prototype.writeInt32BE = function(e, t, r) {
                return e = +e, t |= 0, r || _(this, e, t, 4, 2147483647, -2147483648), e < 0 && (e = 4294967295 + e + 1), l.TYPED_ARRAY_SUPPORT ? (this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = 255 & e) : E(this, e, t, !1), t + 4
            }, l.prototype.writeFloatLE = function(e, t, r) {
                return x(this, e, t, !0, r)
            }, l.prototype.writeFloatBE = function(e, t, r) {
                return x(this, e, t, !1, r)
            }, l.prototype.writeDoubleLE = function(e, t, r) {
                return T(this, e, t, !0, r)
            }, l.prototype.writeDoubleBE = function(e, t, r) {
                return T(this, e, t, !1, r)
            }, l.prototype.copy = function(e, t, r, i) {
                if (r || (r = 0), i || 0 === i || (i = this.length), t >= e.length && (t = e.length), t || (t = 0), i > 0 && i < r && (i = r), i === r || 0 === e.length || 0 === this.length) return 0;
                if (t < 0) throw RangeError("targetStart out of bounds");
                if (r < 0 || r >= this.length) throw RangeError("sourceStart out of bounds");
                if (i < 0) throw RangeError("sourceEnd out of bounds");
                i > this.length && (i = this.length), e.length - t < i - r && (i = e.length - t + r);
                var s, n = i - r;
                if (this === e && r < t && t < i)
                    for (s = n - 1; s >= 0; --s) e[s + t] = this[s + r];
                else if (n < 1e3 || !l.TYPED_ARRAY_SUPPORT)
                    for (s = 0; s < n; ++s) e[s + t] = this[s + r];
                else Uint8Array.prototype.set.call(e, this.subarray(r, r + n), t);
                return n
            }, l.prototype.fill = function(e, t, r, i) {
                if ("string" == typeof e) {
                    if ("string" == typeof t ? (i = t, t = 0, r = this.length) : "string" == typeof r && (i = r, r = this.length), 1 === e.length) {
                        var s, n = e.charCodeAt(0);
                        n < 256 && (e = n)
                    }
                    if (void 0 !== i && "string" != typeof i) throw TypeError("encoding must be a string");
                    if ("string" == typeof i && !l.isEncoding(i)) throw TypeError("Unknown encoding: " + i)
                } else "number" == typeof e && (e &= 255);
                if (t < 0 || this.length < t || this.length < r) throw RangeError("Out of range index");
                if (r <= t) return this;
                if (t >>>= 0, r = void 0 === r ? this.length : r >>> 0, e || (e = 0), "number" == typeof e)
                    for (s = t; s < r; ++s) this[s] = e;
                else {
                    var o = l.isBuffer(e) ? e : A(new l(e, i).toString()),
                        a = o.length;
                    for (s = 0; s < r - t; ++s) this[s + t] = o[s % a]
                }
                return this
            };
            var O = /[^+\/0-9A-Za-z-_]/g;

            function A(e, t) {
                t = t || 1 / 0;
                for (var r, i = e.length, s = null, n = [], o = 0; o < i; ++o) {
                    if ((r = e.charCodeAt(o)) > 55295 && r < 57344) {
                        if (!s) {
                            if (r > 56319 || o + 1 === i) {
                                (t -= 3) > -1 && n.push(239, 191, 189);
                                continue
                            }
                            s = r;
                            continue
                        }
                        if (r < 56320) {
                            (t -= 3) > -1 && n.push(239, 191, 189), s = r;
                            continue
                        }
                        r = (s - 55296 << 10 | r - 56320) + 65536
                    } else s && (t -= 3) > -1 && n.push(239, 191, 189);
                    if (s = null, r < 128) {
                        if ((t -= 1) < 0) break;
                        n.push(r)
                    } else if (r < 2048) {
                        if ((t -= 2) < 0) break;
                        n.push(r >> 6 | 192, 63 & r | 128)
                    } else if (r < 65536) {
                        if ((t -= 3) < 0) break;
                        n.push(r >> 12 | 224, r >> 6 & 63 | 128, 63 & r | 128)
                    } else if (r < 1114112) {
                        if ((t -= 4) < 0) break;
                        n.push(r >> 18 | 240, r >> 12 & 63 | 128, r >> 6 & 63 | 128, 63 & r | 128)
                    } else throw Error("Invalid code point")
                }
                return n
            }

            function P(e) {
                for (var t = [], r = 0; r < e.length; ++r) t.push(255 & e.charCodeAt(r));
                return t
            }

            function C(e) {
                return i.toByteArray(function(e) {
                    var t;
                    if ((e = ((t = e).trim ? t.trim() : t.replace(/^\s+|\s+$/g, "")).replace(O, "")).length < 2) return "";
                    for (; e.length % 4 != 0;) e += "=";
                    return e
                }(e))
            }

            function j(e, t, r, i) {
                for (var s = 0; s < i && !(s + r >= t.length) && !(s >= e.length); ++s) t[s + r] = e[s];
                return s
            }
        },
        76489: function(e, t) {
            "use strict";
            /*!
             * cookie
             * Copyright(c) 2012-2014 Roman Shtylman
             * Copyright(c) 2015 Douglas Christopher Wilson
             * MIT Licensed
             */
            t.parse = function(e, t) {
                if ("string" != typeof e) throw TypeError("argument str must be a string");
                for (var i = {}, s = e.split(";"), n = (t || {}).decode || r, o = 0; o < s.length; o++) {
                    var a = s[o],
                        l = a.indexOf("=");
                    if (!(l < 0)) {
                        var u = a.substring(0, l).trim();
                        if (void 0 == i[u]) {
                            var h = a.substring(l + 1, a.length).trim();
                            '"' === h[0] && (h = h.slice(1, -1)), i[u] = function(e, t) {
                                try {
                                    return t(e)
                                } catch (r) {
                                    return e
                                }
                            }(h, n)
                        }
                    }
                }
                return i
            }, t.serialize = function(e, t, r) {
                var n = r || {},
                    o = n.encode || i;
                if ("function" != typeof o) throw TypeError("option encode is invalid");
                if (!s.test(e)) throw TypeError("argument name is invalid");
                var a = o(t);
                if (a && !s.test(a)) throw TypeError("argument val is invalid");
                var l = e + "=" + a;
                if (null != n.maxAge) {
                    var u = n.maxAge - 0;
                    if (isNaN(u) || !isFinite(u)) throw TypeError("option maxAge is invalid");
                    l += "; Max-Age=" + Math.floor(u)
                }
                if (n.domain) {
                    if (!s.test(n.domain)) throw TypeError("option domain is invalid");
                    l += "; Domain=" + n.domain
                }
                if (n.path) {
                    if (!s.test(n.path)) throw TypeError("option path is invalid");
                    l += "; Path=" + n.path
                }
                if (n.expires) {
                    if ("function" != typeof n.expires.toUTCString) throw TypeError("option expires is invalid");
                    l += "; Expires=" + n.expires.toUTCString()
                }
                if (n.httpOnly && (l += "; HttpOnly"), n.secure && (l += "; Secure"), n.sameSite) {
                    var h = "string" == typeof n.sameSite ? n.sameSite.toLowerCase() : n.sameSite;
                    switch (h) {
                        case !0:
                        case "strict":
                            l += "; SameSite=Strict";
                            break;
                        case "lax":
                            l += "; SameSite=Lax";
                            break;
                        case "none":
                            l += "; SameSite=None";
                            break;
                        default:
                            throw TypeError("option sameSite is invalid")
                    }
                }
                return l
            };
            var r = decodeURIComponent,
                i = encodeURIComponent,
                s = /^[\u0009\u0020-\u007e\u0080-\u00ff]+$/
        },
        47041: function(e, t, r) {
            "use strict";
            var i = this && this.__assign || function() {
                    return (i = Object.assign || function(e) {
                        for (var t, r = 1, i = arguments.length; r < i; r++)
                            for (var s in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, s) && (e[s] = t[s]);
                        return e
                    }).apply(this, arguments)
                },
                s = this && this.__rest || function(e, t) {
                    var r = {};
                    for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && 0 > t.indexOf(i) && (r[i] = e[i]);
                    if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                        for (var s = 0, i = Object.getOwnPropertySymbols(e); s < i.length; s++) 0 > t.indexOf(i[s]) && Object.prototype.propertyIsEnumerable.call(e, i[s]) && (r[i[s]] = e[i[s]]);
                    return r
                };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.checkCookies = t.hasCookie = t.removeCookies = t.deleteCookie = t.setCookies = t.setCookie = t.getCookie = t.getCookies = void 0;
            var n = r(76489),
                o = function() {
                    return "undefined" != typeof window
                },
                a = function(e) {
                    void 0 === e && (e = "");
                    try {
                        var t = JSON.stringify(e);
                        return /^[\{\[]/.test(t) ? t : e
                    } catch (r) {
                        return e
                    }
                },
                l = function(e) {
                    if (e && (t = e.req), !o()) return t && t.cookies ? t.cookies : t && t.headers && t.headers.cookie ? (0, n.parse)(t.headers.cookie) : {};
                    for (var t, r = {}, i = document.cookie ? document.cookie.split("; ") : [], s = 0, a = i.length; s < a; s++) {
                        var l = i[s].split("="),
                            u = l.slice(1).join("=");
                        r[l[0]] = u
                    }
                    return r
                };
            t.getCookies = l;
            var u = function(e, r) {
                var i, s = (0, t.getCookies)(r)[e];
                if (void 0 !== s) return "true" === (i = s ? s.replace(/(%[0-9A-Z]{2})+/g, decodeURIComponent) : s) || "false" !== i && ("undefined" !== i ? "null" === i ? null : i : void 0)
            };
            t.getCookie = u;
            var h = function(e, t, r) {
                if (r) {
                    var l, u, h, c = r.req,
                        d = r.res,
                        f = s(r, ["req", "res"]);
                    u = c, h = d, l = f
                }
                var p = (0, n.serialize)(e, a(t), i({
                    path: "/"
                }, l));
                if (o()) document.cookie = p;
                else if (h && u) {
                    var g = h.getHeader("Set-Cookie");
                    if (Array.isArray(g) || (g = g ? [String(g)] : []), h.setHeader("Set-Cookie", g.concat(p)), u && u.cookies) {
                        var m = u.cookies;
                        "" === t ? delete m[e] : m[e] = a(t)
                    }
                    if (u && u.headers && u.headers.cookie) {
                        var m = (0, n.parse)(u.headers.cookie);
                        "" === t ? delete m[e] : m[e] = a(t), u.headers.cookie = Object.entries(m).reduce(function(e, t) {
                            return e.concat("".concat(t[0], "=").concat(t[1], ";"))
                        }, "")
                    }
                }
            };
            t.setCookie = h;
            var c = function(e, r, i) {
                return console.warn("[WARN]: setCookies was deprecated. It will be deleted in the new version. Use setCookie instead."), (0, t.setCookie)(e, r, i)
            };
            t.setCookies = c;
            var d = function(e, r) {
                return (0, t.setCookie)(e, "", i(i({}, r), {
                    maxAge: -1
                }))
            };
            t.deleteCookie = d;
            var f = function(e, r) {
                return console.warn("[WARN]: removeCookies was deprecated. It will be deleted in the new version. Use deleteCookie instead."), (0, t.deleteCookie)(e, r)
            };
            t.removeCookies = f;
            var p = function(e, r) {
                return !!e && (0, t.getCookies)(r).hasOwnProperty(e)
            };
            t.hasCookie = p;
            var g = function(e, r) {
                return console.warn("[WARN]: checkCookies was deprecated. It will be deleted in the new version. Use hasCookie instead."), (0, t.hasCookie)(e, r)
            };
            t.checkCookies = g
        },
        54098: function(e, t) {
            var r, i = "undefined" != typeof self ? self : this,
                s = function() {
                    function e() {
                        this.fetch = !1, this.DOMException = i.DOMException
                    }
                    return e.prototype = i, new e
                }();
            r = s,
                function(e) {
                    var t = {
                        searchParams: "URLSearchParams" in r,
                        iterable: "Symbol" in r && "iterator" in Symbol,
                        blob: "FileReader" in r && "Blob" in r && function() {
                            try {
                                return new Blob, !0
                            } catch (e) {
                                return !1
                            }
                        }(),
                        formData: "FormData" in r,
                        arrayBuffer: "ArrayBuffer" in r
                    };
                    if (t.arrayBuffer) var i = ["[object Int8Array]", "[object Uint8Array]", "[object Uint8ClampedArray]", "[object Int16Array]", "[object Uint16Array]", "[object Int32Array]", "[object Uint32Array]", "[object Float32Array]", "[object Float64Array]"],
                        s = ArrayBuffer.isView || function(e) {
                            return e && i.indexOf(Object.prototype.toString.call(e)) > -1
                        };

                    function n(e) {
                        if ("string" != typeof e && (e = String(e)), /[^a-z0-9\-#$%&'*+.^_`|~]/i.test(e)) throw TypeError("Invalid character in header field name");
                        return e.toLowerCase()
                    }

                    function o(e) {
                        return "string" != typeof e && (e = String(e)), e
                    }

                    function a(e) {
                        var r = {
                            next: function() {
                                var t = e.shift();
                                return {
                                    done: void 0 === t,
                                    value: t
                                }
                            }
                        };
                        return t.iterable && (r[Symbol.iterator] = function() {
                            return r
                        }), r
                    }

                    function l(e) {
                        this.map = {}, e instanceof l ? e.forEach(function(e, t) {
                            this.append(t, e)
                        }, this) : Array.isArray(e) ? e.forEach(function(e) {
                            this.append(e[0], e[1])
                        }, this) : e && Object.getOwnPropertyNames(e).forEach(function(t) {
                            this.append(t, e[t])
                        }, this)
                    }

                    function u(e) {
                        if (e.bodyUsed) return Promise.reject(TypeError("Already read"));
                        e.bodyUsed = !0
                    }

                    function h(e) {
                        return new Promise(function(t, r) {
                            e.onload = function() {
                                t(e.result)
                            }, e.onerror = function() {
                                r(e.error)
                            }
                        })
                    }

                    function c(e) {
                        var t = new FileReader,
                            r = h(t);
                        return t.readAsArrayBuffer(e), r
                    }

                    function d(e) {
                        if (e.slice) return e.slice(0);
                        var t = new Uint8Array(e.byteLength);
                        return t.set(new Uint8Array(e)), t.buffer
                    }

                    function f() {
                        return this.bodyUsed = !1, this._initBody = function(e) {
                            if (this._bodyInit = e, e) {
                                if ("string" == typeof e) this._bodyText = e;
                                else if (t.blob && Blob.prototype.isPrototypeOf(e)) this._bodyBlob = e;
                                else if (t.formData && FormData.prototype.isPrototypeOf(e)) this._bodyFormData = e;
                                else if (t.searchParams && URLSearchParams.prototype.isPrototypeOf(e)) this._bodyText = e.toString();
                                else {
                                    var r;
                                    t.arrayBuffer && t.blob && (r = e) && DataView.prototype.isPrototypeOf(r) ? (this._bodyArrayBuffer = d(e.buffer), this._bodyInit = new Blob([this._bodyArrayBuffer])) : t.arrayBuffer && (ArrayBuffer.prototype.isPrototypeOf(e) || s(e)) ? this._bodyArrayBuffer = d(e) : this._bodyText = e = Object.prototype.toString.call(e)
                                }
                            } else this._bodyText = "";
                            !this.headers.get("content-type") && ("string" == typeof e ? this.headers.set("content-type", "text/plain;charset=UTF-8") : this._bodyBlob && this._bodyBlob.type ? this.headers.set("content-type", this._bodyBlob.type) : t.searchParams && URLSearchParams.prototype.isPrototypeOf(e) && this.headers.set("content-type", "application/x-www-form-urlencoded;charset=UTF-8"))
                        }, t.blob && (this.blob = function() {
                            var e = u(this);
                            if (e) return e;
                            if (this._bodyBlob) return Promise.resolve(this._bodyBlob);
                            if (this._bodyArrayBuffer) return Promise.resolve(new Blob([this._bodyArrayBuffer]));
                            if (!this._bodyFormData) return Promise.resolve(new Blob([this._bodyText]));
                            throw Error("could not read FormData body as blob")
                        }, this.arrayBuffer = function() {
                            return this._bodyArrayBuffer ? u(this) || Promise.resolve(this._bodyArrayBuffer) : this.blob().then(c)
                        }), this.text = function() {
                            var e, t, r, i = u(this);
                            if (i) return i;
                            if (this._bodyBlob) return e = this._bodyBlob, r = h(t = new FileReader), t.readAsText(e), r;
                            if (this._bodyArrayBuffer) return Promise.resolve(function(e) {
                                for (var t = new Uint8Array(e), r = Array(t.length), i = 0; i < t.length; i++) r[i] = String.fromCharCode(t[i]);
                                return r.join("")
                            }(this._bodyArrayBuffer));
                            if (!this._bodyFormData) return Promise.resolve(this._bodyText);
                            throw Error("could not read FormData body as text")
                        }, t.formData && (this.formData = function() {
                            return this.text().then(m)
                        }), this.json = function() {
                            return this.text().then(JSON.parse)
                        }, this
                    }
                    l.prototype.append = function(e, t) {
                        e = n(e), t = o(t);
                        var r = this.map[e];
                        this.map[e] = r ? r + ", " + t : t
                    }, l.prototype.delete = function(e) {
                        delete this.map[n(e)]
                    }, l.prototype.get = function(e) {
                        return e = n(e), this.has(e) ? this.map[e] : null
                    }, l.prototype.has = function(e) {
                        return this.map.hasOwnProperty(n(e))
                    }, l.prototype.set = function(e, t) {
                        this.map[n(e)] = o(t)
                    }, l.prototype.forEach = function(e, t) {
                        for (var r in this.map) this.map.hasOwnProperty(r) && e.call(t, this.map[r], r, this)
                    }, l.prototype.keys = function() {
                        var e = [];
                        return this.forEach(function(t, r) {
                            e.push(r)
                        }), a(e)
                    }, l.prototype.values = function() {
                        var e = [];
                        return this.forEach(function(t) {
                            e.push(t)
                        }), a(e)
                    }, l.prototype.entries = function() {
                        var e = [];
                        return this.forEach(function(t, r) {
                            e.push([r, t])
                        }), a(e)
                    }, t.iterable && (l.prototype[Symbol.iterator] = l.prototype.entries);
                    var p = ["DELETE", "GET", "HEAD", "OPTIONS", "POST", "PUT"];

                    function g(e, t) {
                        var r, i, s = (t = t || {}).body;
                        if (e instanceof g) {
                            if (e.bodyUsed) throw TypeError("Already read");
                            this.url = e.url, this.credentials = e.credentials, t.headers || (this.headers = new l(e.headers)), this.method = e.method, this.mode = e.mode, this.signal = e.signal, s || null == e._bodyInit || (s = e._bodyInit, e.bodyUsed = !0)
                        } else this.url = String(e);
                        if (this.credentials = t.credentials || this.credentials || "same-origin", (t.headers || !this.headers) && (this.headers = new l(t.headers)), this.method = (i = (r = t.method || this.method || "GET").toUpperCase(), p.indexOf(i) > -1 ? i : r), this.mode = t.mode || this.mode || null, this.signal = t.signal || this.signal, this.referrer = null, ("GET" === this.method || "HEAD" === this.method) && s) throw TypeError("Body not allowed for GET or HEAD requests");
                        this._initBody(s)
                    }

                    function m(e) {
                        var t = new FormData;
                        return e.trim().split("&").forEach(function(e) {
                            if (e) {
                                var r = e.split("="),
                                    i = r.shift().replace(/\+/g, " "),
                                    s = r.join("=").replace(/\+/g, " ");
                                t.append(decodeURIComponent(i), decodeURIComponent(s))
                            }
                        }), t
                    }

                    function v(e, t) {
                        t || (t = {}), this.type = "default", this.status = void 0 === t.status ? 200 : t.status, this.ok = this.status >= 200 && this.status < 300, this.statusText = "statusText" in t ? t.statusText : "OK", this.headers = new l(t.headers), this.url = t.url || "", this._initBody(e)
                    }
                    g.prototype.clone = function() {
                        return new g(this, {
                            body: this._bodyInit
                        })
                    }, f.call(g.prototype), f.call(v.prototype), v.prototype.clone = function() {
                        return new v(this._bodyInit, {
                            status: this.status,
                            statusText: this.statusText,
                            headers: new l(this.headers),
                            url: this.url
                        })
                    }, v.error = function() {
                        var e = new v(null, {
                            status: 0,
                            statusText: ""
                        });
                        return e.type = "error", e
                    };
                    var y = [301, 302, 303, 307, 308];
                    v.redirect = function(e, t) {
                        if (-1 === y.indexOf(t)) throw RangeError("Invalid status code");
                        return new v(null, {
                            status: t,
                            headers: {
                                location: e
                            }
                        })
                    }, e.DOMException = r.DOMException;
                    try {
                        new e.DOMException
                    } catch (b) {
                        e.DOMException = function(e, t) {
                            this.message = e, this.name = t;
                            var r = Error(e);
                            this.stack = r.stack
                        }, e.DOMException.prototype = Object.create(Error.prototype), e.DOMException.prototype.constructor = e.DOMException
                    }

                    function w(r, i) {
                        return new Promise(function(s, n) {
                            var o = new g(r, i);
                            if (o.signal && o.signal.aborted) return n(new e.DOMException("Aborted", "AbortError"));
                            var a = new XMLHttpRequest;

                            function u() {
                                a.abort()
                            }
                            a.onload = function() {
                                var e, t, r = {
                                    status: a.status,
                                    statusText: a.statusText,
                                    headers: (e = a.getAllResponseHeaders() || "", t = new l, e.replace(/\r?\n[\t ]+/g, " ").split(/\r?\n/).forEach(function(e) {
                                        var r = e.split(":"),
                                            i = r.shift().trim();
                                        if (i) {
                                            var s = r.join(":").trim();
                                            t.append(i, s)
                                        }
                                    }), t)
                                };
                                r.url = "responseURL" in a ? a.responseURL : r.headers.get("X-Request-URL");
                                var i = "response" in a ? a.response : a.responseText;
                                s(new v(i, r))
                            }, a.onerror = function() {
                                n(TypeError("Network request failed"))
                            }, a.ontimeout = function() {
                                n(TypeError("Network request failed"))
                            }, a.onabort = function() {
                                n(new e.DOMException("Aborted", "AbortError"))
                            }, a.open(o.method, o.url, !0), "include" === o.credentials ? a.withCredentials = !0 : "omit" === o.credentials && (a.withCredentials = !1), "responseType" in a && t.blob && (a.responseType = "blob"), o.headers.forEach(function(e, t) {
                                a.setRequestHeader(t, e)
                            }), o.signal && (o.signal.addEventListener("abort", u), a.onreadystatechange = function() {
                                4 === a.readyState && o.signal.removeEventListener("abort", u)
                            }), a.send(void 0 === o._bodyInit ? null : o._bodyInit)
                        })
                    }
                    w.polyfill = !0, r.fetch || (r.fetch = w, r.Headers = l, r.Request = g, r.Response = v), e.Headers = l, e.Request = g, e.Response = v, e.fetch = w, Object.defineProperty(e, "__esModule", {
                        value: !0
                    })
                }({}), s.fetch.ponyfill = !0, delete s.fetch.polyfill, (t = s.fetch).default = s.fetch, t.fetch = s.fetch, t.Headers = s.Headers, t.Request = s.Request, t.Response = s.Response, e.exports = t
        },
        284: function(e) {
            var t = function() {
                if ("object" == typeof self && self) return self;
                if ("object" == typeof window && window) return window;
                throw Error("Unable to resolve global `this`")
            };
            e.exports = function() {
                if (this) return this;
                if ("object" == typeof globalThis && globalThis) return globalThis;
                try {
                    Object.defineProperty(Object.prototype, "__global__", {
                        get: function() {
                            return this
                        },
                        configurable: !0
                    })
                } catch (e) {
                    return t()
                }
                try {
                    if (!__global__) return t();
                    return __global__
                } finally {
                    delete Object.prototype.__global__
                }
            }()
        },
        80645: function(e, t) {
            t.read = function(e, t, r, i, s) {
                var n, o, a = 8 * s - i - 1,
                    l = (1 << a) - 1,
                    u = l >> 1,
                    h = -7,
                    c = r ? s - 1 : 0,
                    d = r ? -1 : 1,
                    f = e[t + c];
                for (c += d, n = f & (1 << -h) - 1, f >>= -h, h += a; h > 0; n = 256 * n + e[t + c], c += d, h -= 8);
                for (o = n & (1 << -h) - 1, n >>= -h, h += i; h > 0; o = 256 * o + e[t + c], c += d, h -= 8);
                if (0 === n) n = 1 - u;
                else {
                    if (n === l) return o ? NaN : (f ? -1 : 1) * (1 / 0);
                    o += Math.pow(2, i), n -= u
                }
                return (f ? -1 : 1) * o * Math.pow(2, n - i)
            }, t.write = function(e, t, r, i, s, n) {
                var o, a, l, u = 8 * n - s - 1,
                    h = (1 << u) - 1,
                    c = h >> 1,
                    d = 23 === s ? 5960464477539062e-23 : 0,
                    f = i ? 0 : n - 1,
                    p = i ? 1 : -1,
                    g = t < 0 || 0 === t && 1 / t < 0 ? 1 : 0;
                for (isNaN(t = Math.abs(t)) || t === 1 / 0 ? (a = isNaN(t) ? 1 : 0, o = h) : (o = Math.floor(Math.log(t) / Math.LN2), t * (l = Math.pow(2, -o)) < 1 && (o--, l *= 2), o + c >= 1 ? t += d / l : t += d * Math.pow(2, 1 - c), t * l >= 2 && (o++, l /= 2), o + c >= h ? (a = 0, o = h) : o + c >= 1 ? (a = (t * l - 1) * Math.pow(2, s), o += c) : (a = t * Math.pow(2, c - 1) * Math.pow(2, s), o = 0)); s >= 8; e[r + f] = 255 & a, f += p, a /= 256, s -= 8);
                for (o = o << s | a, u += s; u > 0; e[r + f] = 255 & o, f += p, o /= 256, u -= 8);
                e[r + f - p] |= 128 * g
            }
        },
        5826: function(e) {
            var t = {}.toString;
            e.exports = Array.isArray || function(e) {
                return "[object Array]" == t.call(e)
            }
        },
        6840: function(e, t, r) {
            (window.__NEXT_P = window.__NEXT_P || []).push(["/_app", function() {
                return r(13847)
            }])
        },
        49246: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.getHostname = function(e, t) {
                var r;
                return null == (r = !Array.isArray(null == t ? void 0 : t.host) && (null == t ? void 0 : t.host) || e.hostname) ? void 0 : r.split(":")[0].toLowerCase()
            }
        },
        72388: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.detectDomainLocale = function(e, t, r) {
                let i;
                if (e)
                    for (let s of (r && (r = r.toLowerCase()), e)) {
                        var n, o;
                        let a = null == (n = s.domain) ? void 0 : n.split(":")[0].toLowerCase();
                        if (t === a || r === s.defaultLocale.toLowerCase() || (null == (o = s.locales) ? void 0 : o.some(e => e.toLowerCase() === r))) {
                            i = s;
                            break
                        }
                    }
                return i
            }
        },
        13847: function(e, t, r) {
            "use strict";
            r.r(t), r.d(t, {
                default: function() {
                    return l
                }
            });
            var i = r(85893);
            r(80864);
            var s = r(57542),
                n = r(84053),
                o = r(67294),
                a = r(47041);

            function l(e) {
                let {
                    Component: t,
                    pageProps: r
                } = e, [l] = (0, o.useState)(() => (0, s.createBrowserSupabaseClient)());
                return (0, o.useEffect)(() => {
                    (0, a.hasCookie)("landingPage") || (0, a.setCookie)("landingPage", window.location.href)
                }, []), (0, i.jsx)(n.SessionContextProvider, {
                    supabaseClient: l,
                    initialSession: r.initialSession,
                    children: (0, i.jsx)(t, { ...r
                    })
                })
            }
        },
        80864: function() {},
        80725: function(e, t, r) {
            var i;
            (() => {
                var s = {
                        412: function(s, n) {
                            !
                            /*!@license
                             * UAParser.js v0.7.28
                             * Lightweight JavaScript-based User-Agent string parser
                             * https://github.com/faisalman/ua-parser-js
                             *
                             * Copyright © 2012-2021 Faisal Salman <f@faisalman.com>
                             * Licensed under MIT License
                             */
                            function(o, a) {
                                "use strict";
                                var l = "function",
                                    u = "undefined",
                                    h = "object",
                                    c = "string",
                                    d = "model",
                                    f = "name",
                                    p = "type",
                                    g = "vendor",
                                    m = "version",
                                    v = "architecture",
                                    y = "console",
                                    b = "mobile",
                                    w = "tablet",
                                    _ = "smarttv",
                                    k = "wearable",
                                    E = "embedded",
                                    S = {
                                        extend: function(e, t) {
                                            var r = {};
                                            for (var i in e) t[i] && t[i].length % 2 == 0 ? r[i] = t[i].concat(e[i]) : r[i] = e[i];
                                            return r
                                        },
                                        has: function(e, t) {
                                            return typeof e === c && -1 !== t.toLowerCase().indexOf(e.toLowerCase())
                                        },
                                        lowerize: function(e) {
                                            return e.toLowerCase()
                                        },
                                        major: function(e) {
                                            return typeof e === c ? e.replace(/[^\d\.]/g, "").split(".")[0] : a
                                        },
                                        trim: function(e, t) {
                                            return e = e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, ""), typeof t === u ? e : e.substring(0, 255)
                                        }
                                    },
                                    x = {
                                        rgx: function(e, t) {
                                            for (var r, i, s, n, o, u, c = 0; c < t.length && !o;) {
                                                var d = t[c],
                                                    f = t[c + 1];
                                                for (r = i = 0; r < d.length && !o;)
                                                    if (o = d[r++].exec(e))
                                                        for (s = 0; s < f.length; s++) u = o[++i], typeof(n = f[s]) === h && n.length > 0 ? 2 == n.length ? typeof n[1] == l ? this[n[0]] = n[1].call(this, u) : this[n[0]] = n[1] : 3 == n.length ? typeof n[1] !== l || n[1].exec && n[1].test ? this[n[0]] = u ? u.replace(n[1], n[2]) : a : this[n[0]] = u ? n[1].call(this, u, n[2]) : a : 4 == n.length && (this[n[0]] = u ? n[3].call(this, u.replace(n[1], n[2])) : a) : this[n] = u || a;
                                                c += 2
                                            }
                                        },
                                        str: function(e, t) {
                                            for (var r in t)
                                                if (typeof t[r] === h && t[r].length > 0) {
                                                    for (var i = 0; i < t[r].length; i++)
                                                        if (S.has(t[r][i], e)) return "?" === r ? a : r
                                                } else if (S.has(t[r], e)) return "?" === r ? a : r;
                                            return e
                                        }
                                    },
                                    T = {
                                        browser: {
                                            oldSafari: {
                                                version: {
                                                    "1.0": "/8",
                                                    1.2: "/1",
                                                    1.3: "/3",
                                                    "2.0": "/412",
                                                    "2.0.2": "/416",
                                                    "2.0.3": "/417",
                                                    "2.0.4": "/419",
                                                    "?": "/"
                                                }
                                            },
                                            oldEdge: {
                                                version: {
                                                    .1: "12.",
                                                    21: "13.",
                                                    31: "14.",
                                                    39: "15.",
                                                    41: "16.",
                                                    42: "17.",
                                                    44: "18."
                                                }
                                            }
                                        },
                                        os: {
                                            windows: {
                                                version: {
                                                    ME: "4.90",
                                                    "NT 3.11": "NT3.51",
                                                    "NT 4.0": "NT4.0",
                                                    2e3: "NT 5.0",
                                                    XP: ["NT 5.1", "NT 5.2"],
                                                    Vista: "NT 6.0",
                                                    7: "NT 6.1",
                                                    8: "NT 6.2",
                                                    8.1: "NT 6.3",
                                                    10: ["NT 6.4", "NT 10.0"],
                                                    RT: "ARM"
                                                }
                                            }
                                        }
                                    },
                                    O = {
                                        browser: [
                                            [/\b(?:crmo|crios)\/([\w\.]+)/i],
                                            [m, [f, "Chrome"]],
                                            [/edg(?:e|ios|a)?\/([\w\.]+)/i],
                                            [m, [f, "Edge"]],
                                            [/(opera\smini)\/([\w\.-]+)/i, /(opera\s[mobiletab]{3,6})\b.+version\/([\w\.-]+)/i, /(opera)(?:.+version\/|[\/\s]+)([\w\.]+)/i],
                                            [f, m],
                                            [/opios[\/\s]+([\w\.]+)/i],
                                            [m, [f, "Opera Mini"]],
                                            [/\sopr\/([\w\.]+)/i],
                                            [m, [f, "Opera"]],
                                            [/(kindle)\/([\w\.]+)/i, /(lunascape|maxthon|netfront|jasmine|blazer)[\/\s]?([\w\.]*)/i, /(avant\s|iemobile|slim)(?:browser)?[\/\s]?([\w\.]*)/i, /(ba?idubrowser)[\/\s]?([\w\.]+)/i, /(?:ms|\()(ie)\s([\w\.]+)/i, /(flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi|iridium|phantomjs|bowser|quark|qupzilla|falkon)\/([\w\.-]+)/i, /(rekonq|puffin|brave|whale|qqbrowserlite|qq)\/([\w\.]+)/i, /(weibo)__([\d\.]+)/i],
                                            [f, m],
                                            [/(?:[\s\/]uc?\s?browser|(?:juc.+)ucweb)[\/\s]?([\w\.]+)/i],
                                            [m, [f, "UCBrowser"]],
                                            [/(?:windowswechat)?\sqbcore\/([\w\.]+)\b.*(?:windowswechat)?/i],
                                            [m, [f, "WeChat(Win) Desktop"]],
                                            [/micromessenger\/([\w\.]+)/i],
                                            [m, [f, "WeChat"]],
                                            [/konqueror\/([\w\.]+)/i],
                                            [m, [f, "Konqueror"]],
                                            [/trident.+rv[:\s]([\w\.]{1,9})\b.+like\sgecko/i],
                                            [m, [f, "IE"]],
                                            [/yabrowser\/([\w\.]+)/i],
                                            [m, [f, "Yandex"]],
                                            [/(avast|avg)\/([\w\.]+)/i],
                                            [
                                                [f, /(.+)/, "$1 Secure Browser"], m
                                            ],
                                            [/focus\/([\w\.]+)/i],
                                            [m, [f, "Firefox Focus"]],
                                            [/opt\/([\w\.]+)/i],
                                            [m, [f, "Opera Touch"]],
                                            [/coc_coc_browser\/([\w\.]+)/i],
                                            [m, [f, "Coc Coc"]],
                                            [/dolfin\/([\w\.]+)/i],
                                            [m, [f, "Dolphin"]],
                                            [/coast\/([\w\.]+)/i],
                                            [m, [f, "Opera Coast"]],
                                            [/xiaomi\/miuibrowser\/([\w\.]+)/i],
                                            [m, [f, "MIUI Browser"]],
                                            [/fxios\/([\w\.-]+)/i],
                                            [m, [f, "Firefox"]],
                                            [/(qihu|qhbrowser|qihoobrowser|360browser)/i],
                                            [
                                                [f, "360 Browser"]
                                            ],
                                            [/(oculus|samsung|sailfish)browser\/([\w\.]+)/i],
                                            [
                                                [f, /(.+)/, "$1 Browser"], m
                                            ],
                                            [/(comodo_dragon)\/([\w\.]+)/i],
                                            [
                                                [f, /_/g, " "], m
                                            ],
                                            [/\s(electron)\/([\w\.]+)\ssafari/i, /(tesla)(?:\sqtcarbrowser|\/(20[12]\d\.[\w\.-]+))/i, /m?(qqbrowser|baiduboxapp|2345Explorer)[\/\s]?([\w\.]+)/i],
                                            [f, m],
                                            [/(MetaSr)[\/\s]?([\w\.]+)/i, /(LBBROWSER)/i],
                                            [f],
                                            [/;fbav\/([\w\.]+);/i],
                                            [m, [f, "Facebook"]],
                                            [/FBAN\/FBIOS|FB_IAB\/FB4A/i],
                                            [
                                                [f, "Facebook"]
                                            ],
                                            [/safari\s(line)\/([\w\.]+)/i, /\b(line)\/([\w\.]+)\/iab/i, /(chromium|instagram)[\/\s]([\w\.-]+)/i],
                                            [f, m],
                                            [/\bgsa\/([\w\.]+)\s.*safari\//i],
                                            [m, [f, "GSA"]],
                                            [/headlesschrome(?:\/([\w\.]+)|\s)/i],
                                            [m, [f, "Chrome Headless"]],
                                            [/\swv\).+(chrome)\/([\w\.]+)/i],
                                            [
                                                [f, "Chrome WebView"], m
                                            ],
                                            [/droid.+\sversion\/([\w\.]+)\b.+(?:mobile\ssafari|safari)/i],
                                            [m, [f, "Android Browser"]],
                                            [/(chrome|omniweb|arora|[tizenoka]{5}\s?browser)\/v?([\w\.]+)/i],
                                            [f, m],
                                            [/version\/([\w\.]+)\s.*mobile\/\w+\s(safari)/i],
                                            [m, [f, "Mobile Safari"]],
                                            [/version\/([\w\.]+)\s.*(mobile\s?safari|safari)/i],
                                            [m, f],
                                            [/webkit.+?(mobile\s?safari|safari)(\/[\w\.]+)/i],
                                            [f, [m, x.str, T.browser.oldSafari.version]],
                                            [/(webkit|khtml)\/([\w\.]+)/i],
                                            [f, m],
                                            [/(navigator|netscape)\/([\w\.-]+)/i],
                                            [
                                                [f, "Netscape"], m
                                            ],
                                            [/ile\svr;\srv:([\w\.]+)\).+firefox/i],
                                            [m, [f, "Firefox Reality"]],
                                            [/ekiohf.+(flow)\/([\w\.]+)/i, /(swiftfox)/i, /(icedragon|iceweasel|camino|chimera|fennec|maemo\sbrowser|minimo|conkeror)[\/\s]?([\w\.\+]+)/i, /(firefox|seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([\w\.-]+)$/i, /(firefox)\/([\w\.]+)\s[\w\s\-]+\/[\w\.]+$/i, /(mozilla)\/([\w\.]+)\s.+rv\:.+gecko\/\d+/i, /(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|sleipnir)[\/\s]?([\w\.]+)/i, /(links)\s\(([\w\.]+)/i, /(gobrowser)\/?([\w\.]*)/i, /(ice\s?browser)\/v?([\w\._]+)/i, /(mosaic)[\/\s]([\w\.]+)/i],
                                            [f, m]
                                        ],
                                        cpu: [
                                            [/(?:(amd|x(?:(?:86|64)[_-])?|wow|win)64)[;\)]/i],
                                            [
                                                [v, "amd64"]
                                            ],
                                            [/(ia32(?=;))/i],
                                            [
                                                [v, S.lowerize]
                                            ],
                                            [/((?:i[346]|x)86)[;\)]/i],
                                            [
                                                [v, "ia32"]
                                            ],
                                            [/\b(aarch64|armv?8e?l?)\b/i],
                                            [
                                                [v, "arm64"]
                                            ],
                                            [/\b(arm(?:v[67])?ht?n?[fl]p?)\b/i],
                                            [
                                                [v, "armhf"]
                                            ],
                                            [/windows\s(ce|mobile);\sppc;/i],
                                            [
                                                [v, "arm"]
                                            ],
                                            [/((?:ppc|powerpc)(?:64)?)(?:\smac|;|\))/i],
                                            [
                                                [v, /ower/, "", S.lowerize]
                                            ],
                                            [/(sun4\w)[;\)]/i],
                                            [
                                                [v, "sparc"]
                                            ],
                                            [/((?:avr32|ia64(?=;))|68k(?=\))|\barm(?:64|(?=v(?:[1-7]|[5-7]1)l?|;|eabi))|(?=atmel\s)avr|(?:irix|mips|sparc)(?:64)?\b|pa-risc)/i],
                                            [
                                                [v, S.lowerize]
                                            ]
                                        ],
                                        device: [
                                            [/\b(sch-i[89]0\d|shw-m380s|sm-[pt]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus\s10)/i],
                                            [d, [g, "Samsung"],
                                                [p, w]
                                            ],
                                            [/\b((?:s[cgp]h|gt|sm)-\w+|galaxy\snexus)/i, /\ssamsung[\s-]([\w-]+)/i, /sec-(sgh\w+)/i],
                                            [d, [g, "Samsung"],
                                                [p, b]
                                            ],
                                            [/\((ip(?:hone|od)[\s\w]*);/i],
                                            [d, [g, "Apple"],
                                                [p, b]
                                            ],
                                            [/\((ipad);[\w\s\),;-]+apple/i, /applecoremedia\/[\w\.]+\s\((ipad)/i, /\b(ipad)\d\d?,\d\d?[;\]].+ios/i],
                                            [d, [g, "Apple"],
                                                [p, w]
                                            ],
                                            [/\b((?:agr|ags[23]|bah2?|sht?)-a?[lw]\d{2})/i],
                                            [d, [g, "Huawei"],
                                                [p, w]
                                            ],
                                            [/d\/huawei([\w\s-]+)[;\)]/i, /\b(nexus\s6p|vog-[at]?l\d\d|ane-[at]?l[x\d]\d|eml-a?l\d\da?|lya-[at]?l\d[\dc]|clt-a?l\d\di?|ele-l\d\d)/i, /\b(\w{2,4}-[atu][ln][01259][019])[;\)\s]/i],
                                            [d, [g, "Huawei"],
                                                [p, b]
                                            ],
                                            [/\b(poco[\s\w]+)(?:\sbuild|\))/i, /\b;\s(\w+)\sbuild\/hm\1/i, /\b(hm[\s\-_]?note?[\s_]?(?:\d\w)?)\sbuild/i, /\b(redmi[\s\-_]?(?:note|k)?[\w\s_]+)(?:\sbuild|\))/i, /\b(mi[\s\-_]?(?:a\d|one|one[\s_]plus|note lte)?[\s_]?(?:\d?\w?)[\s_]?(?:plus)?)\sbuild/i],
                                            [
                                                [d, /_/g, " "],
                                                [g, "Xiaomi"],
                                                [p, b]
                                            ],
                                            [/\b(mi[\s\-_]?(?:pad)(?:[\w\s_]+))(?:\sbuild|\))/i],
                                            [
                                                [d, /_/g, " "],
                                                [g, "Xiaomi"],
                                                [p, w]
                                            ],
                                            [/;\s(\w+)\sbuild.+\soppo/i, /\s(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007)\b/i],
                                            [d, [g, "OPPO"],
                                                [p, b]
                                            ],
                                            [/\svivo\s(\w+)(?:\sbuild|\))/i, /\s(v[12]\d{3}\w?[at])(?:\sbuild|;)/i],
                                            [d, [g, "Vivo"],
                                                [p, b]
                                            ],
                                            [/\s(rmx[12]\d{3})(?:\sbuild|;)/i],
                                            [d, [g, "Realme"],
                                                [p, b]
                                            ],
                                            [/\s(milestone|droid(?:[2-4x]|\s(?:bionic|x2|pro|razr))?:?(\s4g)?)\b[\w\s]+build\//i, /\smot(?:orola)?[\s-](\w*)/i, /((?:moto[\s\w\(\)]+|xt\d{3,4}|nexus\s6)(?=\sbuild|\)))/i],
                                            [d, [g, "Motorola"],
                                                [p, b]
                                            ],
                                            [/\s(mz60\d|xoom[\s2]{0,2})\sbuild\//i],
                                            [d, [g, "Motorola"],
                                                [p, w]
                                            ],
                                            [/((?=lg)?[vl]k\-?\d{3})\sbuild|\s3\.[\s\w;-]{10}lg?-([06cv9]{3,4})/i],
                                            [d, [g, "LG"],
                                                [p, w]
                                            ],
                                            [/(lm-?f100[nv]?|nexus\s[45])/i, /lg[e;\s\/-]+((?!browser|netcast)\w+)/i, /\blg(\-?[\d\w]+)\sbuild/i],
                                            [d, [g, "LG"],
                                                [p, b]
                                            ],
                                            [/(ideatab[\w\-\s]+)/i, /lenovo\s?(s(?:5000|6000)(?:[\w-]+)|tab(?:[\s\w]+)|yt[\d\w-]{6}|tb[\d\w-]{6})/i],
                                            [d, [g, "Lenovo"],
                                                [p, w]
                                            ],
                                            [/(?:maemo|nokia).*(n900|lumia\s\d+)/i, /nokia[\s_-]?([\w\.-]*)/i],
                                            [
                                                [d, /_/g, " "],
                                                [g, "Nokia"],
                                                [p, b]
                                            ],
                                            [/droid.+;\s(pixel\sc)[\s)]/i],
                                            [d, [g, "Google"],
                                                [p, w]
                                            ],
                                            [/droid.+;\s(pixel[\s\daxl]{0,6})(?:\sbuild|\))/i],
                                            [d, [g, "Google"],
                                                [p, b]
                                            ],
                                            [/droid.+\s([c-g]\d{4}|so[-l]\w+|xq-a\w[4-7][12])(?=\sbuild\/|\).+chrome\/(?![1-6]{0,1}\d\.))/i],
                                            [d, [g, "Sony"],
                                                [p, b]
                                            ],
                                            [/sony\stablet\s[ps]\sbuild\//i, /(?:sony)?sgp\w+(?:\sbuild\/|\))/i],
                                            [
                                                [d, "Xperia Tablet"],
                                                [g, "Sony"],
                                                [p, w]
                                            ],
                                            [/\s(kb2005|in20[12]5|be20[12][59])\b/i, /\ba000(1)\sbuild/i, /\boneplus\s(a\d{4})[\s)]/i],
                                            [d, [g, "OnePlus"],
                                                [p, b]
                                            ],
                                            [/(alexa)webm/i, /(kf[a-z]{2}wi)(\sbuild\/|\))/i, /(kf[a-z]+)(\sbuild\/|\)).+silk\//i],
                                            [d, [g, "Amazon"],
                                                [p, w]
                                            ],
                                            [/(sd|kf)[0349hijorstuw]+(\sbuild\/|\)).+silk\//i],
                                            [
                                                [d, "Fire Phone"],
                                                [g, "Amazon"],
                                                [p, b]
                                            ],
                                            [/\((playbook);[\w\s\),;-]+(rim)/i],
                                            [d, g, [p, w]],
                                            [/((?:bb[a-f]|st[hv])100-\d)/i, /\(bb10;\s(\w+)/i],
                                            [d, [g, "BlackBerry"],
                                                [p, b]
                                            ],
                                            [/(?:\b|asus_)(transfo[prime\s]{4,10}\s\w+|eeepc|slider\s\w+|nexus\s7|padfone|p00[cj])/i],
                                            [d, [g, "ASUS"],
                                                [p, w]
                                            ],
                                            [/\s(z[es]6[027][01][km][ls]|zenfone\s\d\w?)\b/i],
                                            [d, [g, "ASUS"],
                                                [p, b]
                                            ],
                                            [/(nexus\s9)/i],
                                            [d, [g, "HTC"],
                                                [p, w]
                                            ],
                                            [/(htc)[;_\s-]{1,2}([\w\s]+(?=\)|\sbuild)|\w+)/i, /(zte)-(\w*)/i, /(alcatel|geeksphone|nexian|panasonic|(?=;\s)sony)[_\s-]?([\w-]*)/i],
                                            [g, [d, /_/g, " "],
                                                [p, b]
                                            ],
                                            [/droid[x\d\.\s;]+\s([ab][1-7]\-?[0178a]\d\d?)/i],
                                            [d, [g, "Acer"],
                                                [p, w]
                                            ],
                                            [/droid.+;\s(m[1-5]\snote)\sbuild/i, /\bmz-([\w-]{2,})/i],
                                            [d, [g, "Meizu"],
                                                [p, b]
                                            ],
                                            [/(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron)[\s_-]?([\w-]*)/i, /(hp)\s([\w\s]+\w)/i, /(asus)-?(\w+)/i, /(microsoft);\s(lumia[\s\w]+)/i, /(lenovo)[_\s-]?([\w-]+)/i, /linux;.+(jolla);/i, /droid.+;\s(oppo)\s?([\w\s]+)\sbuild/i],
                                            [g, d, [p, b]],
                                            [/(archos)\s(gamepad2?)/i, /(hp).+(touchpad(?!.+tablet)|tablet)/i, /(kindle)\/([\w\.]+)/i, /\s(nook)[\w\s]+build\/(\w+)/i, /(dell)\s(strea[kpr\s\d]*[\dko])/i, /[;\/]\s?(le[\s\-]+pan)[\s\-]+(\w{1,9})\sbuild/i, /[;\/]\s?(trinity)[\-\s]*(t\d{3})\sbuild/i, /\b(gigaset)[\s\-]+(q\w{1,9})\sbuild/i, /\b(vodafone)\s([\w\s]+)(?:\)|\sbuild)/i],
                                            [g, d, [p, w]],
                                            [/\s(surface\sduo)\s/i],
                                            [d, [g, "Microsoft"],
                                                [p, w]
                                            ],
                                            [/droid\s[\d\.]+;\s(fp\du?)\sbuild/i],
                                            [d, [g, "Fairphone"],
                                                [p, b]
                                            ],
                                            [/\s(u304aa)\sbuild/i],
                                            [d, [g, "AT&T"],
                                                [p, b]
                                            ],
                                            [/sie-(\w*)/i],
                                            [d, [g, "Siemens"],
                                                [p, b]
                                            ],
                                            [/[;\/]\s?(rct\w+)\sbuild/i],
                                            [d, [g, "RCA"],
                                                [p, w]
                                            ],
                                            [/[;\/\s](venue[\d\s]{2,7})\sbuild/i],
                                            [d, [g, "Dell"],
                                                [p, w]
                                            ],
                                            [/[;\/]\s?(q(?:mv|ta)\w+)\sbuild/i],
                                            [d, [g, "Verizon"],
                                                [p, w]
                                            ],
                                            [/[;\/]\s(?:barnes[&\s]+noble\s|bn[rt])([\w\s\+]*)\sbuild/i],
                                            [d, [g, "Barnes & Noble"],
                                                [p, w]
                                            ],
                                            [/[;\/]\s(tm\d{3}\w+)\sbuild/i],
                                            [d, [g, "NuVision"],
                                                [p, w]
                                            ],
                                            [/;\s(k88)\sbuild/i],
                                            [d, [g, "ZTE"],
                                                [p, w]
                                            ],
                                            [/;\s(nx\d{3}j)\sbuild/i],
                                            [d, [g, "ZTE"],
                                                [p, b]
                                            ],
                                            [/[;\/]\s?(gen\d{3})\sbuild.*49h/i],
                                            [d, [g, "Swiss"],
                                                [p, b]
                                            ],
                                            [/[;\/]\s?(zur\d{3})\sbuild/i],
                                            [d, [g, "Swiss"],
                                                [p, w]
                                            ],
                                            [/[;\/]\s?((zeki)?tb.*\b)\sbuild/i],
                                            [d, [g, "Zeki"],
                                                [p, w]
                                            ],
                                            [/[;\/]\s([yr]\d{2})\sbuild/i, /[;\/]\s(dragon[\-\s]+touch\s|dt)(\w{5})\sbuild/i],
                                            [
                                                [g, "Dragon Touch"], d, [p, w]
                                            ],
                                            [/[;\/]\s?(ns-?\w{0,9})\sbuild/i],
                                            [d, [g, "Insignia"],
                                                [p, w]
                                            ],
                                            [/[;\/]\s?((nxa|Next)-?\w{0,9})\sbuild/i],
                                            [d, [g, "NextBook"],
                                                [p, w]
                                            ],
                                            [/[;\/]\s?(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05]))\sbuild/i],
                                            [
                                                [g, "Voice"], d, [p, b]
                                            ],
                                            [/[;\/]\s?(lvtel\-)?(v1[12])\sbuild/i],
                                            [
                                                [g, "LvTel"], d, [p, b]
                                            ],
                                            [/;\s(ph-1)\s/i],
                                            [d, [g, "Essential"],
                                                [p, b]
                                            ],
                                            [/[;\/]\s?(v(100md|700na|7011|917g).*\b)\sbuild/i],
                                            [d, [g, "Envizen"],
                                                [p, w]
                                            ],
                                            [/[;\/]\s?(trio[\s\w\-\.]+)\sbuild/i],
                                            [d, [g, "MachSpeed"],
                                                [p, w]
                                            ],
                                            [/[;\/]\s?tu_(1491)\sbuild/i],
                                            [d, [g, "Rotor"],
                                                [p, w]
                                            ],
                                            [/(shield[\w\s]+)\sbuild/i],
                                            [d, [g, "Nvidia"],
                                                [p, w]
                                            ],
                                            [/(sprint)\s(\w+)/i],
                                            [g, d, [p, b]],
                                            [/(kin\.[onetw]{3})/i],
                                            [
                                                [d, /\./g, " "],
                                                [g, "Microsoft"],
                                                [p, b]
                                            ],
                                            [/droid\s[\d\.]+;\s(cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i],
                                            [d, [g, "Zebra"],
                                                [p, w]
                                            ],
                                            [/droid\s[\d\.]+;\s(ec30|ps20|tc[2-8]\d[kx])\)/i],
                                            [d, [g, "Zebra"],
                                                [p, b]
                                            ],
                                            [/\s(ouya)\s/i, /(nintendo)\s([wids3utch]+)/i],
                                            [g, d, [p, y]],
                                            [/droid.+;\s(shield)\sbuild/i],
                                            [d, [g, "Nvidia"],
                                                [p, y]
                                            ],
                                            [/(playstation\s[345portablevi]+)/i],
                                            [d, [g, "Sony"],
                                                [p, y]
                                            ],
                                            [/[\s\(;](xbox(?:\sone)?(?!;\sxbox))[\s\);]/i],
                                            [d, [g, "Microsoft"],
                                                [p, y]
                                            ],
                                            [/smart-tv.+(samsung)/i],
                                            [g, [p, _]],
                                            [/hbbtv.+maple;(\d+)/i],
                                            [
                                                [d, /^/, "SmartTV"],
                                                [g, "Samsung"],
                                                [p, _]
                                            ],
                                            [/(?:linux;\snetcast.+smarttv|lg\snetcast\.tv-201\d)/i],
                                            [
                                                [g, "LG"],
                                                [p, _]
                                            ],
                                            [/(apple)\s?tv/i],
                                            [g, [d, "Apple TV"],
                                                [p, _]
                                            ],
                                            [/crkey/i],
                                            [
                                                [d, "Chromecast"],
                                                [g, "Google"],
                                                [p, _]
                                            ],
                                            [/droid.+aft([\w])(\sbuild\/|\))/i],
                                            [d, [g, "Amazon"],
                                                [p, _]
                                            ],
                                            [/\(dtv[\);].+(aquos)/i],
                                            [d, [g, "Sharp"],
                                                [p, _]
                                            ],
                                            [/hbbtv\/\d+\.\d+\.\d+\s+\([\w\s]*;\s*(\w[^;]*);([^;]*)/i],
                                            [
                                                [g, S.trim],
                                                [d, S.trim],
                                                [p, _]
                                            ],
                                            [/[\s\/\(](android\s|smart[-\s]?|opera\s)tv[;\)\s]/i],
                                            [
                                                [p, _]
                                            ],
                                            [/((pebble))app\/[\d\.]+\s/i],
                                            [g, d, [p, k]],
                                            [/droid.+;\s(glass)\s\d/i],
                                            [d, [g, "Google"],
                                                [p, k]
                                            ],
                                            [/droid\s[\d\.]+;\s(wt63?0{2,3})\)/i],
                                            [d, [g, "Zebra"],
                                                [p, k]
                                            ],
                                            [/(tesla)(?:\sqtcarbrowser|\/20[12]\d\.[\w\.-]+)/i],
                                            [g, [p, E]],
                                            [/droid .+?; ([^;]+?)(?: build|\) applewebkit).+? mobile safari/i],
                                            [d, [p, b]],
                                            [/droid .+?;\s([^;]+?)(?: build|\) applewebkit).+?(?! mobile) safari/i],
                                            [d, [p, w]],
                                            [/\s(tablet|tab)[;\/]/i, /\s(mobile)(?:[;\/]|\ssafari)/i],
                                            [
                                                [p, S.lowerize]
                                            ],
                                            [/(android[\w\.\s\-]{0,9});.+build/i],
                                            [d, [g, "Generic"]],
                                            [/(phone)/i],
                                            [
                                                [p, b]
                                            ]
                                        ],
                                        engine: [
                                            [/windows.+\sedge\/([\w\.]+)/i],
                                            [m, [f, "EdgeHTML"]],
                                            [/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i],
                                            [m, [f, "Blink"]],
                                            [/(presto)\/([\w\.]+)/i, /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna)\/([\w\.]+)/i, /ekioh(flow)\/([\w\.]+)/i, /(khtml|tasman|links)[\/\s]\(?([\w\.]+)/i, /(icab)[\/\s]([23]\.[\d\.]+)/i],
                                            [f, m],
                                            [/rv\:([\w\.]{1,9})\b.+(gecko)/i],
                                            [m, f]
                                        ],
                                        os: [
                                            [/microsoft\s(windows)\s(vista|xp)/i],
                                            [f, m],
                                            [/(windows)\snt\s6\.2;\s(arm)/i, /(windows\sphone(?:\sos)*)[\s\/]?([\d\.\s\w]*)/i, /(windows\smobile|windows)[\s\/]?([ntce\d\.\s]+\w)(?!.+xbox)/i],
                                            [f, [m, x.str, T.os.windows.version]],
                                            [/(win(?=3|9|n)|win\s9x\s)([nt\d\.]+)/i],
                                            [
                                                [f, "Windows"],
                                                [m, x.str, T.os.windows.version]
                                            ],
                                            [/ip[honead]{2,4}\b(?:.*os\s([\w]+)\slike\smac|;\sopera)/i, /cfnetwork\/.+darwin/i],
                                            [
                                                [m, /_/g, "."],
                                                [f, "iOS"]
                                            ],
                                            [/(mac\sos\sx)\s?([\w\s\.]*)/i, /(macintosh|mac(?=_powerpc)\s)(?!.+haiku)/i],
                                            [
                                                [f, "Mac OS"],
                                                [m, /_/g, "."]
                                            ],
                                            [/(android|webos|palm\sos|qnx|bada|rim\stablet\sos|meego|sailfish|contiki)[\/\s-]?([\w\.]*)/i, /(blackberry)\w*\/([\w\.]*)/i, /(tizen|kaios)[\/\s]([\w\.]+)/i, /\((series40);/i],
                                            [f, m],
                                            [/\(bb(10);/i],
                                            [m, [f, "BlackBerry"]],
                                            [/(?:symbian\s?os|symbos|s60(?=;)|series60)[\/\s-]?([\w\.]*)/i],
                                            [m, [f, "Symbian"]],
                                            [/mozilla.+\(mobile;.+gecko.+firefox/i],
                                            [
                                                [f, "Firefox OS"]
                                            ],
                                            [/web0s;.+rt(tv)/i, /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i],
                                            [m, [f, "webOS"]],
                                            [/crkey\/([\d\.]+)/i],
                                            [m, [f, "Chromecast"]],
                                            [/(cros)\s[\w]+\s([\w\.]+\w)/i],
                                            [
                                                [f, "Chromium OS"], m
                                            ],
                                            [/(nintendo|playstation)\s([wids345portablevuch]+)/i, /(xbox);\s+xbox\s([^\);]+)/i, /(mint)[\/\s\(\)]?(\w*)/i, /(mageia|vectorlinux)[;\s]/i, /(joli|[kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?=\slinux)|slackware|fedora|mandriva|centos|pclinuxos|redhat|zenwalk|linpus|raspbian)(?:\sgnu\/linux)?(?:\slinux)?[\/\s-]?(?!chrom|package)([\w\.-]*)/i, /(hurd|linux)\s?([\w\.]*)/i, /(gnu)\s?([\w\.]*)/i, /\s([frentopc-]{0,4}bsd|dragonfly)\s?(?!amd|[ix346]{1,2}86)([\w\.]*)/i, /(haiku)\s(\w+)/i],
                                            [f, m],
                                            [/(sunos)\s?([\w\.\d]*)/i],
                                            [
                                                [f, "Solaris"], m
                                            ],
                                            [/((?:open)?solaris)[\/\s-]?([\w\.]*)/i, /(aix)\s((\d)(?=\.|\)|\s)[\w\.])*/i, /(plan\s9|minix|beos|os\/2|amigaos|morphos|risc\sos|openvms|fuchsia)/i, /(unix)\s?([\w\.]*)/i],
                                            [f, m]
                                        ]
                                    },
                                    A = function(e, t) {
                                        if ("object" == typeof e && (t = e, e = a), !(this instanceof A)) return new A(e, t).getResult();
                                        var r = e || (void 0 !== o && o.navigator && o.navigator.userAgent ? o.navigator.userAgent : ""),
                                            i = t ? S.extend(O, t) : O;
                                        return this.getBrowser = function() {
                                            var e = {
                                                name: a,
                                                version: a
                                            };
                                            return x.rgx.call(e, r, i.browser), e.major = S.major(e.version), e
                                        }, this.getCPU = function() {
                                            var e = {
                                                architecture: a
                                            };
                                            return x.rgx.call(e, r, i.cpu), e
                                        }, this.getDevice = function() {
                                            var e = {
                                                vendor: a,
                                                model: a,
                                                type: a
                                            };
                                            return x.rgx.call(e, r, i.device), e
                                        }, this.getEngine = function() {
                                            var e = {
                                                name: a,
                                                version: a
                                            };
                                            return x.rgx.call(e, r, i.engine), e
                                        }, this.getOS = function() {
                                            var e = {
                                                name: a,
                                                version: a
                                            };
                                            return x.rgx.call(e, r, i.os), e
                                        }, this.getResult = function() {
                                            return {
                                                ua: this.getUA(),
                                                browser: this.getBrowser(),
                                                engine: this.getEngine(),
                                                os: this.getOS(),
                                                device: this.getDevice(),
                                                cpu: this.getCPU()
                                            }
                                        }, this.getUA = function() {
                                            return r
                                        }, this.setUA = function(e) {
                                            return r = typeof e === c && e.length > 255 ? S.trim(e, 255) : e, this
                                        }, this.setUA(r), this
                                    };
                                A.VERSION = "0.7.28", A.BROWSER = {
                                    NAME: f,
                                    MAJOR: "major",
                                    VERSION: m
                                }, A.CPU = {
                                    ARCHITECTURE: v
                                }, A.DEVICE = {
                                    MODEL: d,
                                    VENDOR: g,
                                    TYPE: p,
                                    CONSOLE: y,
                                    MOBILE: b,
                                    SMARTTV: _,
                                    TABLET: w,
                                    WEARABLE: k,
                                    EMBEDDED: E
                                }, A.ENGINE = {
                                    NAME: f,
                                    VERSION: m
                                }, A.OS = {
                                    NAME: f,
                                    VERSION: m
                                }, typeof n !== u ? (s.exports && (n = s.exports = A), n.UAParser = A) : void 0 !== (i = (function() {
                                    return A
                                }).call(t, r, t, e)) && (e.exports = i);
                                var P = void 0 !== o && (o.jQuery || o.Zepto);
                                if (P && !P.ua) {
                                    var C = new A;
                                    P.ua = C.getResult(), P.ua.get = function() {
                                        return C.getUA()
                                    }, P.ua.set = function(e) {
                                        C.setUA(e);
                                        var t = C.getResult();
                                        for (var r in t) P.ua[r] = t[r]
                                    }
                                }
                            }("object" == typeof window ? window : this)
                        }
                    },
                    n = {};

                function o(e) {
                    var t = n[e];
                    if (void 0 !== t) return t.exports;
                    var r = n[e] = {
                            exports: {}
                        },
                        i = !0;
                    try {
                        s[e].call(r.exports, r, r.exports, o), i = !1
                    } finally {
                        i && delete n[e]
                    }
                    return r.exports
                }
                o.ab = "//";
                var a = o(412);
                e.exports = a
            })()
        },
        39949: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.PageSignatureError = class extends Error {
                constructor({
                    page: e
                }) {
                    super(`The middleware "${e}" accepts an async API directly with the form:
  
  export function middleware(request, event) {
    return NextResponse.redirect('/new-location')
  }
  
  Read more: https://nextjs.org/docs/messages/middleware-new-signature
  `)
                }
            }, t.RemovedPageError = class extends Error {
                constructor() {
                    super(`The request.page has been deprecated in favour of \`URLPattern\`.
  Read more: https://nextjs.org/docs/messages/middleware-request-page
  `)
                }
            }, t.RemovedUAError = class extends Error {
                constructor() {
                    super(`The request.ua has been removed in favour of \`userAgent\` function.
  Read more: https://nextjs.org/docs/messages/middleware-parse-user-agent
  `)
                }
            }
        },
        1289: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var i = r(72388),
                s = r(57429),
                n = r(49246),
                o = r(18756);
            let a = /(?!^https?:\/\/)(127(?:\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)){3}|::1|localhost)/;

            function l(e, t) {
                return new URL(String(e).replace(a, "localhost"), t && String(t).replace(a, "localhost"))
            }
            let u = Symbol("NextURLInternal");
            class h {
                constructor(e, t, r) {
                    let i, s;
                    "object" == typeof t && "pathname" in t || "string" == typeof t ? (i = t, s = r || {}) : s = r || t || {}, this[u] = {
                        url: l(e, i ? ? s.base),
                        options: s,
                        basePath: ""
                    }, this.analyzeUrl()
                }
                analyzeUrl() {
                    var e, t, r, s, a;
                    let l = o.getNextPathnameInfo(this[u].url.pathname, {
                        nextConfig: this[u].options.nextConfig,
                        parseData: !0
                    });
                    this[u].domainLocale = i.detectDomainLocale(null == (e = this[u].options.nextConfig) ? void 0 : null == (t = e.i18n) ? void 0 : t.domains, n.getHostname(this[u].url, this[u].options.headers));
                    let h = (null == (r = this[u].domainLocale) ? void 0 : r.defaultLocale) || (null == (s = this[u].options.nextConfig) ? void 0 : null == (a = s.i18n) ? void 0 : a.defaultLocale);
                    this[u].url.pathname = l.pathname, this[u].defaultLocale = h, this[u].basePath = l.basePath ? ? "", this[u].buildId = l.buildId, this[u].locale = l.locale ? ? h, this[u].trailingSlash = l.trailingSlash
                }
                formatPathname() {
                    return s.formatNextPathnameInfo({
                        basePath: this[u].basePath,
                        buildId: this[u].buildId,
                        defaultLocale: this[u].options.forceLocale ? void 0 : this[u].defaultLocale,
                        locale: this[u].locale,
                        pathname: this[u].url.pathname,
                        trailingSlash: this[u].trailingSlash
                    })
                }
                formatSearch() {
                    return this[u].url.search
                }
                get buildId() {
                    return this[u].buildId
                }
                set buildId(e) {
                    this[u].buildId = e
                }
                get locale() {
                    return this[u].locale ? ? ""
                }
                set locale(e) {
                    var t, r;
                    if (!this[u].locale || !(null == (t = this[u].options.nextConfig) ? void 0 : null == (r = t.i18n) ? void 0 : r.locales.includes(e))) throw TypeError(`The NextURL configuration includes no locale "${e}"`);
                    this[u].locale = e
                }
                get defaultLocale() {
                    return this[u].defaultLocale
                }
                get domainLocale() {
                    return this[u].domainLocale
                }
                get searchParams() {
                    return this[u].url.searchParams
                }
                get host() {
                    return this[u].url.host
                }
                set host(e) {
                    this[u].url.host = e
                }
                get hostname() {
                    return this[u].url.hostname
                }
                set hostname(e) {
                    this[u].url.hostname = e
                }
                get port() {
                    return this[u].url.port
                }
                set port(e) {
                    this[u].url.port = e
                }
                get protocol() {
                    return this[u].url.protocol
                }
                set protocol(e) {
                    this[u].url.protocol = e
                }
                get href() {
                    let e = this.formatPathname(),
                        t = this.formatSearch();
                    return `${this.protocol}//${this.host}${e}${t}${this.hash}`
                }
                set href(e) {
                    this[u].url = l(e), this.analyzeUrl()
                }
                get origin() {
                    return this[u].url.origin
                }
                get pathname() {
                    return this[u].url.pathname
                }
                set pathname(e) {
                    this[u].url.pathname = e
                }
                get hash() {
                    return this[u].url.hash
                }
                set hash(e) {
                    this[u].url.hash = e
                }
                get search() {
                    return this[u].url.search
                }
                set search(e) {
                    this[u].url.search = e
                }
                get password() {
                    return this[u].url.password
                }
                set password(e) {
                    this[u].url.password = e
                }
                get username() {
                    return this[u].url.username
                }
                set username(e) {
                    this[u].url.username = e
                }
                get basePath() {
                    return this[u].basePath
                }
                set basePath(e) {
                    this[u].basePath = e.startsWith("/") ? e : `/${e}`
                }
                toString() {
                    return this.href
                }
                toJSON() {
                    return this.href
                }[Symbol.for("edge-runtime.inspect.custom")]() {
                    return {
                        href: this.href,
                        origin: this.origin,
                        protocol: this.protocol,
                        username: this.username,
                        password: this.password,
                        host: this.host,
                        hostname: this.hostname,
                        port: this.port,
                        pathname: this.pathname,
                        search: this.search,
                        searchParams: this.searchParams,
                        hash: this.hash
                    }
                }
                clone() {
                    return new h(String(this), this[u].options)
                }
            }
            t.NextURL = h
        },
        75668: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "RequestCookies", {
                enumerable: !0,
                get: function() {
                    return i.RequestCookies
                }
            }), Object.defineProperty(t, "ResponseCookies", {
                enumerable: !0,
                get: function() {
                    return s.ResponseCookies
                }
            });
            var i = r(21142),
                s = r(64045)
        },
        21142: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var i = r(16884);
            class s {
                _parsed = new Map;
                constructor(e) {
                    this._headers = e;
                    let t = e.get("cookie");
                    if (t) {
                        let r = i.parseCookieString(t);
                        for (let [s, n] of r) this._parsed.set(s, {
                            name: s,
                            value: n
                        })
                    }
                }[Symbol.iterator]() {
                    return this._parsed[Symbol.iterator]()
                }
                get size() {
                    return this._parsed.size
                }
                get(...e) {
                    let t = "string" == typeof e[0] ? e[0] : e[0].name;
                    return this._parsed.get(t)
                }
                getAll(...e) {
                    var t;
                    let r = Array.from(this._parsed);
                    if (!e.length) return r.map(([e, t]) => t);
                    let i = "string" == typeof e[0] ? e[0] : null == (t = e[0]) ? void 0 : t.name;
                    return r.filter(([e]) => e === i).map(([e, t]) => t)
                }
                has(e) {
                    return this._parsed.has(e)
                }
                set(...e) {
                    let [t, r] = 1 === e.length ? [e[0].name, e[0].value] : e, s = this._parsed;
                    return s.set(t, {
                        name: t,
                        value: r
                    }), this._headers.set("cookie", Array.from(s).map(([e, t]) => i.serialize(t)).join("; ")), this
                }
                delete(e) {
                    let t = this._parsed,
                        r = Array.isArray(e) ? e.map(e => t.delete(e)) : t.delete(e);
                    return this._headers.set("cookie", Array.from(t).map(([e, t]) => i.serialize(t)).join("; ")), r
                }
                clear() {
                    return this.delete(Array.from(this._parsed.keys())), this
                }[Symbol.for("edge-runtime.inspect.custom")]() {
                    return `RequestCookies ${JSON.stringify(Object.fromEntries(this._parsed))}`
                }
            }
            t.RequestCookies = s
        },
        64045: function(e, t, r) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var i = r(16884);
            class s {
                _parsed = new Map;
                constructor(e) {
                    this._headers = e;
                    let t = this._headers.getAll("set-cookie");
                    for (let r of t) {
                        let s = i.parseSetCookieString(r);
                        s && this._parsed.set(s.name, s)
                    }
                }
                get(...e) {
                    let t = "string" == typeof e[0] ? e[0] : e[0].name;
                    return this._parsed.get(t)
                }
                getAll(...e) {
                    var t;
                    let r = Array.from(this._parsed.values());
                    if (!e.length) return r;
                    let i = "string" == typeof e[0] ? e[0] : null == (t = e[0]) ? void 0 : t.name;
                    return r.filter(e => e.name === i)
                }
                set(...e) {
                    let [t, r, s] = 1 === e.length ? [e[0].name, e[0].value, e[0]] : e, n = this._parsed;
                    return n.set(t, function(e = {
                        name: "",
                        value: ""
                    }) {
                        return e.maxAge && (e.expires = new Date(Date.now() + 1e3 * e.maxAge)), (null === e.path || void 0 === e.path) && (e.path = "/"), e
                    }({
                        name: t,
                        value: r,
                        ...s
                    })), ! function(e, t) {
                        for (let [, r] of (t.delete("set-cookie"), e)) {
                            let s = i.serialize(r);
                            t.append("set-cookie", s)
                        }
                    }(n, this._headers), this
                }
                delete(...e) {
                    let t = "string" == typeof e[0] ? e[0] : e[0].name;
                    return this.set({
                        name: t,
                        value: "",
                        expires: new Date(0)
                    })
                }[Symbol.for("edge-runtime.inspect.custom")]() {
                    return `ResponseCookies ${JSON.stringify(Object.fromEntries(this._parsed))}`
                }
            }
            t.ResponseCookies = s
        },
        16884: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.serialize = function(e) {
                let t = ["path" in e && e.path && `Path=${e.path}`, "expires" in e && e.expires && `Expires=${e.expires.toUTCString()}`, "maxAge" in e && e.maxAge && `Max-Age=${e.maxAge}`, "domain" in e && e.domain && `Domain=${e.domain}`, "secure" in e && e.secure && "Secure", "httpOnly" in e && e.httpOnly && "HttpOnly", "sameSite" in e && e.sameSite && `SameSite=${e.sameSite}`].filter(Boolean);
                return `${e.name}=${encodeURIComponent(e.value??"")}; ${t.join("; ")}`
            }, t.parseCookieString = i, t.parseSetCookieString = function(e) {
                var t;
                if (!e) return;
                let [
                    [s, n], ...o
                ] = i(e), {
                    domain: a,
                    expires: l,
                    httponly: u,
                    maxage: h,
                    path: c,
                    samesite: d,
                    secure: f
                } = Object.fromEntries(o.map(([e, t]) => [e.toLowerCase(), t])), p = {
                    name: s,
                    value: decodeURIComponent(n),
                    domain: a,
                    ...l && {
                        expires: new Date(l)
                    },
                    ...u && {
                        httpOnly: !0
                    },
                    ..."string" == typeof h && {
                        maxAge: Number(h)
                    },
                    path: c,
                    ...d && {
                        sameSite: r.includes(t = (t = d).toLowerCase()) ? t : void 0
                    },
                    ...f && {
                        secure: !0
                    }
                };
                return function(e) {
                    let t = {};
                    for (let r in e) e[r] && (t[r] = e[r]);
                    return t
                }(p)
            };
            let r = ["strict", "lax", "none"];

            function i(e) {
                let t = new Map;
                for (let r of e.split(/; */)) {
                    if (!r) continue;
                    let [i, s] = r.split("=", 2);
                    t.set(i, decodeURIComponent(s ? ? "true"))
                }
                return t
            }
        },
        53399: function(e, t, r) {
            "use strict";
            var i = r(1289),
                s = r(9129),
                n = r(39949),
                o = r(75668);
            let a = Symbol("internal request");
            class l extends Request {
                constructor(e, t = {}) {
                    let r = "string" != typeof e && "url" in e ? e.url : String(e);
                    s.validateURL(r), super(r, t), this[a] = {
                        cookies: new o.RequestCookies(this.headers),
                        geo: t.geo || {},
                        ip: t.ip,
                        url: new i.NextURL(r, {
                            headers: s.toNodeHeaders(this.headers),
                            nextConfig: t.nextConfig
                        })
                    }
                }[Symbol.for("edge-runtime.inspect.custom")]() {
                    return {
                        cookies: this.cookies,
                        geo: this.geo,
                        ip: this.ip,
                        nextUrl: this.nextUrl,
                        url: this.url,
                        bodyUsed: this.bodyUsed,
                        cache: this.cache,
                        credentials: this.credentials,
                        destination: this.destination,
                        headers: Object.fromEntries(this.headers),
                        integrity: this.integrity,
                        keepalive: this.keepalive,
                        method: this.method,
                        mode: this.mode,
                        redirect: this.redirect,
                        referrer: this.referrer,
                        referrerPolicy: this.referrerPolicy,
                        signal: this.signal
                    }
                }
                get cookies() {
                    return this[a].cookies
                }
                get geo() {
                    return this[a].geo
                }
                get ip() {
                    return this[a].ip
                }
                get nextUrl() {
                    return this[a].url
                }
                get page() {
                    throw new n.RemovedPageError
                }
                get ua() {
                    throw new n.RemovedUAError
                }
                get url() {
                    return this[a].url.toString()
                }
            }
            t.Im = l
        },
        63013: function(e, t, r) {
            "use strict";
            var i = r(1289),
                s = r(9129),
                n = r(75668);
            let o = Symbol("internal response"),
                a = new Set([301, 302, 303, 307, 308]);

            function l(e, t) {
                var r;
                if (null == e ? void 0 : null == (r = e.request) ? void 0 : r.headers) {
                    if (!(e.request.headers instanceof Headers)) throw Error("request.headers must be an instance of Headers");
                    let i = [];
                    for (let [s, n] of e.request.headers) t.set("x-middleware-request-" + s, n), i.push(s);
                    t.set("x-middleware-override-headers", i.join(","))
                }
            }
            class u extends Response {
                constructor(e, t = {}) {
                    super(e, t), this[o] = {
                        cookies: new n.ResponseCookies(this.headers),
                        url: t.url ? new i.NextURL(t.url, {
                            headers: s.toNodeHeaders(this.headers),
                            nextConfig: t.nextConfig
                        }) : void 0
                    }
                }[Symbol.for("edge-runtime.inspect.custom")]() {
                    return {
                        cookies: this.cookies,
                        url: this.url,
                        body: this.body,
                        bodyUsed: this.bodyUsed,
                        headers: Object.fromEntries(this.headers),
                        ok: this.ok,
                        redirected: this.redirected,
                        status: this.status,
                        statusText: this.statusText,
                        type: this.type
                    }
                }
                get cookies() {
                    return this[o].cookies
                }
                static json(e, t) {
                    let r = Response.json(e, t);
                    return new u(r.body, r)
                }
                static redirect(e, t) {
                    let r = "number" == typeof t ? t : (null == t ? void 0 : t.status) ? ? 307;
                    if (!a.has(r)) throw RangeError('Failed to execute "redirect" on "response": Invalid status code');
                    let i = "object" == typeof t ? t : {},
                        n = new Headers(null == i ? void 0 : i.headers);
                    return n.set("Location", s.validateURL(e)), new u(null, { ...i,
                        headers: n,
                        status: r
                    })
                }
                static rewrite(e, t) {
                    let r = new Headers(null == t ? void 0 : t.headers);
                    return r.set("x-middleware-rewrite", s.validateURL(e)), l(t, r), new u(null, { ...t,
                        headers: r
                    })
                }
                static next(e) {
                    let t = new Headers(null == e ? void 0 : e.headers);
                    return t.set("x-middleware-next", "1"), l(e, t), new u(null, { ...e,
                        headers: t
                    })
                }
            }
            t.x = u
        },
        50733: function(e, t, r) {
            "use strict";
            t.Nf = n, t.WE = function({
                headers: e
            }) {
                return n(e.get("user-agent") || void 0)
            };
            var i, s = (i = r(80725)) && i.__esModule ? i : {
                default: i
            };

            function n(e) {
                return { ...s.default(e),
                    isBot: void 0 !== e && /Googlebot|Mediapartners-Google|AdsBot-Google|googleweblight|Storebot-Google|Google-PageRenderer|Bingbot|BingPreview|Slurp|DuckDuckBot|baiduspider|yandex|sogou|LinkedInBot|bitlybot|tumblr|vkShare|quora link preview|facebookexternalhit|facebookcatalog|Twitterbot|applebot|redditbot|Slackbot|Discordbot|WhatsApp|SkypeUriPreview|ia_archiver/i.test(e)
                }
            }
        },
        9129: function(e, t) {
            "use strict";

            function r(e) {
                var t, r, i, s, n, o = [],
                    a = 0;

                function l() {
                    for (; a < e.length && /\s/.test(e.charAt(a));) a += 1;
                    return a < e.length
                }
                for (; a < e.length;) {
                    for (t = a, n = !1; l();)
                        if ("," === (r = e.charAt(a))) {
                            for (i = a, a += 1, l(), s = a; a < e.length && "=" !== (r = e.charAt(a)) && ";" !== r && "," !== r;) a += 1;
                            a < e.length && "=" === e.charAt(a) ? (n = !0, a = s, o.push(e.substring(t, i)), t = a) : a = i + 1
                        } else a += 1;
                    (!n || a >= e.length) && o.push(e.substring(t, e.length))
                }
                return o
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.fromNodeHeaders = function(e) {
                let t = new Headers;
                for (let [r, i] of Object.entries(e)) {
                    let s = Array.isArray(i) ? i : [i];
                    for (let n of s) void 0 !== n && t.append(r, n)
                }
                return t
            }, t.splitCookiesString = r, t.toNodeHeaders = function(e) {
                let t = {};
                if (e)
                    for (let [i, s] of e.entries()) t[i] = s, "set-cookie" === i.toLowerCase() && (t[i] = r(s));
                return t
            }, t.validateURL = function(e) {
                try {
                    return String(new URL(String(e)))
                } catch (t) {
                    throw Error(`URL is malformed "${String(e)}". Please use only absolute URLs - https://nextjs.org/docs/messages/middleware-relative-urls`, {
                        cause: t
                    })
                }
            }
        },
        97385: function(e, t, r) {
            let i = {
                NextRequest: r(53399).Im,
                NextResponse: r(63013).x,
                userAgentFromString: r(50733).Nf,
                userAgent: r(50733).WE
            };
            "undefined" != typeof URLPattern && (i.URLPattern = URLPattern), e.exports = i, t.NextRequest = i.NextRequest, t.NextResponse = i.NextResponse, t.userAgentFromString = i.userAgentFromString, t.userAgent = i.userAgent, t.URLPattern = i.URLPattern
        },
        45840: function(e, t, r) {
            if ("object" == typeof globalThis) s = globalThis;
            else try {
                s = r(284)
            } catch (i) {} finally {
                if (s || "undefined" == typeof window || (s = window), !s) throw Error("Could not determine global this")
            }
            var s, n = s.WebSocket || s.MozWebSocket,
                o = r(79387);

            function a(e, t) {
                return t ? new n(e, t) : new n(e)
            }
            n && ["CONNECTING", "OPEN", "CLOSING", "CLOSED"].forEach(function(e) {
                Object.defineProperty(a, e, {
                    get: function() {
                        return n[e]
                    }
                })
            }), e.exports = {
                w3cwebsocket: n ? a : null,
                version: o
            }
        },
        79387: function(e, t, r) {
            e.exports = r(19794).version
        },
        96961: function(e, t, r) {
            "use strict";
            r.r(t), r.d(t, {
                AccessTokenNotFound: function() {
                    return I
                },
                AuthHelperError: function() {
                    return C
                },
                CallbackUrlFailed: function() {
                    return L
                },
                CookieNotFound: function() {
                    return j
                },
                CookieNotParsed: function() {
                    return $
                },
                CookieNotSaved: function() {
                    return R
                },
                JWTInvalid: function() {
                    return M
                },
                JWTPayloadFailed: function() {
                    return B
                },
                ProviderTokenNotFound: function() {
                    return U
                },
                RefreshTokenNotFound: function() {
                    return N
                },
                createBrowserSupabaseClient: function() {
                    return A
                },
                createServerSupabaseClient: function() {
                    return P
                },
                ensureArray: function() {
                    return T
                },
                filterCookies: function() {
                    return _
                },
                isBrowser: function() {
                    return O
                },
                parseCookies: function() {
                    return D
                },
                serializeCookie: function() {
                    return F
                }
            });
            var i, s, n, o, a = r(49802),
                l = r(48764).Buffer,
                u = Object.create,
                h = Object.defineProperty,
                c = Object.getOwnPropertyDescriptor,
                d = Object.getOwnPropertyNames,
                f = Object.getPrototypeOf,
                p = Object.prototype.hasOwnProperty,
                g = (e, t, r, i) => {
                    if (t && "object" == typeof t || "function" == typeof t)
                        for (let s of d(t)) p.call(e, s) || s === r || h(e, s, {
                            get: () => t[s],
                            enumerable: !(i = c(t, s)) || i.enumerable
                        });
                    return e
                },
                m = (e, t, r) => (r = null != e ? u(f(e)) : {}, g(!t && e && e.__esModule ? r : h(r, "default", {
                    value: e,
                    enumerable: !0
                }), e)),
                v = (i = {
                    "../../node_modules/.pnpm/tsup@5.12.9/node_modules/tsup/assets/esm_shims.js" () {}
                }, function() {
                    return i && (s = (0, i[d(i)[0]])(i = 0)), s
                }),
                y = (n = {
                    "../../node_modules/.pnpm/cookie@0.5.0/node_modules/cookie/index.js" (e) {
                        v(), e.parse = function(e, t) {
                            if ("string" != typeof e) throw TypeError("argument str must be a string");
                            for (var r = {}, s = (t || {}).decode || i, n = 0; n < e.length;) {
                                var o = e.indexOf("=", n);
                                if (-1 === o) break;
                                var a = e.indexOf(";", n);
                                if (-1 === a) a = e.length;
                                else if (a < o) {
                                    n = e.lastIndexOf(";", o - 1) + 1;
                                    continue
                                }
                                var l = e.slice(n, o).trim();
                                if (void 0 === r[l]) {
                                    var u = e.slice(o + 1, a).trim();
                                    34 === u.charCodeAt(0) && (u = u.slice(1, -1)), r[l] = function(e, t) {
                                        try {
                                            return t(e)
                                        } catch (r) {
                                            return e
                                        }
                                    }(u, s)
                                }
                                n = a + 1
                            }
                            return r
                        }, e.serialize = function(e, i, n) {
                            var o = n || {},
                                a = o.encode || s;
                            if ("function" != typeof a) throw TypeError("option encode is invalid");
                            if (!r.test(e)) throw TypeError("argument name is invalid");
                            var l = a(i);
                            if (l && !r.test(l)) throw TypeError("argument val is invalid");
                            var u = e + "=" + l;
                            if (null != o.maxAge) {
                                var h = o.maxAge - 0;
                                if (isNaN(h) || !isFinite(h)) throw TypeError("option maxAge is invalid");
                                u += "; Max-Age=" + Math.floor(h)
                            }
                            if (o.domain) {
                                if (!r.test(o.domain)) throw TypeError("option domain is invalid");
                                u += "; Domain=" + o.domain
                            }
                            if (o.path) {
                                if (!r.test(o.path)) throw TypeError("option path is invalid");
                                u += "; Path=" + o.path
                            }
                            if (o.expires) {
                                var c = o.expires;
                                if ("[object Date]" !== t.call(c) && !(c instanceof Date) || isNaN(c.valueOf())) throw TypeError("option expires is invalid");
                                u += "; Expires=" + c.toUTCString()
                            }
                            if (o.httpOnly && (u += "; HttpOnly"), o.secure && (u += "; Secure"), o.priority) {
                                var d = "string" == typeof o.priority ? o.priority.toLowerCase() : o.priority;
                                switch (d) {
                                    case "low":
                                        u += "; Priority=Low";
                                        break;
                                    case "medium":
                                        u += "; Priority=Medium";
                                        break;
                                    case "high":
                                        u += "; Priority=High";
                                        break;
                                    default:
                                        throw TypeError("option priority is invalid")
                                }
                            }
                            if (o.sameSite) {
                                var f = "string" == typeof o.sameSite ? o.sameSite.toLowerCase() : o.sameSite;
                                switch (f) {
                                    case !0:
                                    case "strict":
                                        u += "; SameSite=Strict";
                                        break;
                                    case "lax":
                                        u += "; SameSite=Lax";
                                        break;
                                    case "none":
                                        u += "; SameSite=None";
                                        break;
                                    default:
                                        throw TypeError("option sameSite is invalid")
                                }
                            }
                            return u
                        };
                        var t = Object.prototype.toString,
                            r = /^[\u0009\u0020-\u007e\u0080-\u00ff]+$/;

                        function i(e) {
                            return -1 !== e.indexOf("%") ? decodeURIComponent(e) : e
                        }

                        function s(e) {
                            return encodeURIComponent(e)
                        }
                    }
                }, function() {
                    return o || (0, n[d(n)[0]])((o = {
                        exports: {}
                    }).exports, o), o.exports
                });
            v(), v();
            var b = m(y());
            v();
            var w = m(y());

            function _(e, t) {
                let r = new Set(e.map(e => (0, w.parse)(e)).reduce((e, r, i) => (t in r && e.push(i), e), []));
                return e.filter((e, t) => !r.has(t))
            }

            function k(e) {
                if (!e) throw Error('The "host" request header is not available');
                let t = Array.isArray(e) ? e[0] : e,
                    r = t.indexOf(":") > -1 && t.split(":")[0] || t;
                return !(["localhost", "127.0.0.1"].indexOf(r) > -1 || r.endsWith(".local"))
            }
            var E = e => {
                try {
                    return decodeURIComponent(atob(e.replace(/[-]/g, "+").replace(/[_]/g, "/")).split("").map(e => "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2)).join(""))
                } catch (t) {
                    if (t instanceof ReferenceError) return l.from(e, "base64").toString("utf-8");
                    throw t
                }
            };

            function S(e) {
                if (!e) return null;
                try {
                    let t = JSON.parse(e);
                    if (!t) return null;
                    if ("Object" === t.constructor.name) return t;
                    if ("Array" !== t.constructor.name) throw Error(`Unexpected format: ${t.constructor.name}`);
                    let [r, i, s] = t[0].split("."), n = E(i), {
                        exp: o,
                        sub: a,
                        ...l
                    } = JSON.parse(n);
                    return {
                        expires_at: o,
                        expires_in: o - Math.round(Date.now() / 1e3),
                        token_type: "bearer",
                        access_token: t[0],
                        refresh_token: t[1],
                        provider_token: t[2],
                        provider_refresh_token: t[3],
                        user: {
                            id: a,
                            ...l
                        }
                    }
                } catch (u) {
                    return console.warn("Failed to parse cookie string:", u), null
                }
            }

            function x(e) {
                return JSON.stringify([e.access_token, e.refresh_token, e.provider_token, e.provider_refresh_token])
            }

            function T(e) {
                return Array.isArray(e) ? e : [e]
            }

            function O() {
                return "undefined" != typeof window
            }

            function A({
                supabaseUrl: e,
                supabaseKey: t,
                options: r,
                cookieOptions: {
                    name: i = "supabase-auth-token",
                    domain: s,
                    path: n = "/",
                    sameSite: o = "lax",
                    secure: l,
                    maxAge: u = 31536e6
                } = {}
            }) {
                return (0, a.createClient)(e, t, { ...r,
                    auth: {
                        storageKey: i,
                        storage: {
                            getItem(e) {
                                if (!O()) return null;
                                let t = (0, b.parse)(document.cookie),
                                    r = S(t[e]);
                                return r ? JSON.stringify(r) : null
                            },
                            setItem(e, t) {
                                var r;
                                if (!O()) return;
                                let i = JSON.parse(t),
                                    a = x(i);
                                document.cookie = (0, b.serialize)(e, a, {
                                    domain: s,
                                    path: n,
                                    maxAge: u,
                                    httpOnly: !1,
                                    sameSite: o,
                                    secure: null != l ? l : (null == (r = document.location) ? void 0 : r.protocol) === "https:"
                                })
                            },
                            removeItem(e) {
                                O() && (document.cookie = (0, b.serialize)(e, "", {
                                    domain: s,
                                    path: n,
                                    expires: new Date(0),
                                    httpOnly: !1,
                                    sameSite: o,
                                    secure: l
                                }))
                            }
                        }
                    }
                })
            }

            function P({
                supabaseUrl: e,
                supabaseKey: t,
                getCookie: r,
                setCookie: i,
                getRequestHeader: s,
                options: n,
                cookieOptions: {
                    name: o = "supabase-auth-token",
                    domain: l,
                    path: u = "/",
                    sameSite: h = "lax",
                    secure: c,
                    maxAge: d = 31536e6
                } = {}
            }) {
                var f;
                let p = null != (f = S(r(o))) ? f : null;
                return (0, a.createClient)(e, t, { ...n,
                    auth: {
                        detectSessionInUrl: !1,
                        autoRefreshToken: !1,
                        storageKey: o,
                        storage: {
                            getItem: e => JSON.stringify(p),
                            setItem(e, t) {
                                let r = JSON.parse(t),
                                    n = x(r);
                                p = r, i(e, n, {
                                    domain: l,
                                    path: u,
                                    maxAge: d,
                                    httpOnly: !1,
                                    sameSite: h,
                                    secure: null != c ? c : k(s("host"))
                                })
                            },
                            removeItem(e) {
                                p && i(e, "", {
                                    domain: l,
                                    path: u,
                                    expires: new Date(0),
                                    httpOnly: !1,
                                    sameSite: h,
                                    secure: null != c ? c : k(s("host"))
                                })
                            }
                        }
                    }
                })
            }
            v(), v(), v(), v(), v();
            var C = class extends Error {
                    constructor(e, t) {
                        super(e), this.errorType = t, this.source = "sb_auth_helpers"
                    }
                    toObj() {
                        return {
                            type: this.errorType,
                            message: this.message,
                            source: this.source
                        }
                    }
                    toString() {
                        return JSON.stringify(this.toObj())
                    }
                },
                j = class extends C {
                    constructor() {
                        super("No cookie was found!", "cookie_not_found")
                    }
                },
                R = class extends C {
                    constructor() {
                        super("Cookies cannot be saved!", "cookie_not_saved")
                    }
                },
                I = class extends C {
                    constructor() {
                        super("No access token was found!", "cookie_not_found")
                    }
                },
                N = class extends C {
                    constructor() {
                        super("No refresh token was found!", "cookie_not_found")
                    }
                },
                U = class extends C {
                    constructor() {
                        super("No provider token was found!", "cookie_not_found")
                    }
                },
                $ = class extends C {
                    constructor() {
                        super("Not able to parse cookies!", "cookie_not_parsed")
                    }
                },
                L = class extends C {
                    constructor(e) {
                        super(`The request to ${e} failed!`, "callback_url_failed")
                    }
                },
                B = class extends C {
                    constructor() {
                        super("Not able to parse JWT payload!", "jwt_payload_failed")
                    }
                },
                M = class extends C {
                    constructor() {
                        super("Invalid jwt!", "jwt_invalid")
                    }
                },
                D = w.parse,
                F = w.serialize;
            /*!
             * cookie
             * Copyright(c) 2012-2014 Roman Shtylman
             * Copyright(c) 2015 Douglas Christopher Wilson
             * MIT Licensed
             */
        },
        19794: function(e) {
            "use strict";
            e.exports = {
                version: "1.0.34"
            }
        }
    },
    function(e) {
        var t = function(t) {
            return e(e.s = t)
        };
        e.O(0, [9774, 179], function() {
            return t(6840), t(80880)
        }), _N_E = e.O()
    }
]);