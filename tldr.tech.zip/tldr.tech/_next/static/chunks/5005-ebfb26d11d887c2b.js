"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5005], {
        27315: function(e, t, n) {
            var s = n(85893),
                a = n(9008),
                i = n.n(a),
                l = n(41664),
                r = n.n(l),
                o = n(98706),
                c = n(73038),
                d = n(65631),
                u = n.n(d),
                m = n(38597);
            let p = e => {
                let {
                    description: t,
                    newsletter: n,
                    campaigns: a,
                    emailSignupFormParams: l,
                    footerLinks: d
                } = e, p = "".concat((0, m.KA)(n), " Archives");
                return (0, s.jsxs)("div", {
                    children: [(0, s.jsxs)(i(), {
                        children: [(0, s.jsx)(c.Z, {}), (0, s.jsx)("title", {
                            children: p
                        }), (0, s.jsx)("meta", {
                            property: "og:title",
                            content: p
                        }), (0, s.jsx)("meta", {
                            name: "description",
                            content: t
                        }), (0, s.jsx)("meta", {
                            property: "og:description",
                            content: t
                        })]
                    }), (0, s.jsx)(u(), {}), (0, s.jsx)("div", {
                        className: "flex justify-center h-screen",
                        children: (0, s.jsxs)("div", {
                            className: "content-center px-4 md:p-0 max-w-xl mt-5",
                            children: [(0, s.jsx)("div", {
                                className: "text-center text-xl font-bold",
                                children: p
                            }), (0, s.jsx)(o.Z, {
                                description: l.description,
                                newsletter: l.newsletter,
                                readers: l.readers,
                                focus: !0
                            }), a.map(e => (0, s.jsx)(r(), {
                                href: "/".concat(n, "/").concat(e.date),
                                children: (0, s.jsx)("div", {
                                    children: e.subject
                                })
                            }, e.date))]
                        })
                    })]
                })
            };
            t.Z = p
        },
        53447: function(e, t, n) {
            var s = n(85893),
                a = n(41664),
                i = n.n(a);
            let l = e => {
                let {
                    links: t
                } = e;
                return (0, s.jsx)("div", {
                    className: "mt-4 text-center w-100",
                    children: (0, s.jsx)("div", {
                        className: "text-center",
                        children: t.map((e, n) => (0, s.jsx)(i(), {
                            className: n < t.length - 1 ? "mr-3" : "",
                            href: e.href,
                            children: e.text
                        }, e.href))
                    })
                })
            };
            t.Z = l
        },
        5005: function(e, t, n) {
            n.d(t, {
                Bt: function() {
                    return $
                },
                zx: function() {
                    return s.default
                },
                w7: function() {
                    return a.Z
                },
                v5: function() {
                    return i.Z
                },
                lb: function() {
                    return O
                },
                UP: function() {
                    return j
                },
                bZ: function() {
                    return T
                },
                pe: function() {
                    return H
                },
                U8: function() {
                    return J
                },
                W_: function() {
                    return w()
                },
                oL: function() {
                    return z.Z
                },
                Q1: function() {
                    return W
                },
                WM: function() {
                    return Q
                }
            });
            var s = n(96625);
            n(27315);
            var a = n(73038),
                i = n(98706),
                l = n(85893),
                r = n(67294),
                o = n(30862),
                c = n(37038);
            let {
                Country: d,
                State: u,
                City: m
            } = n(98090);
            d.getAllCountries();
            let p = e => {
                let {
                    id: t,
                    location: n = {},
                    setLocation: s,
                    optional: a,
                    showOptional: i,
                    ...o
                } = e, [p, h] = (0, r.useState)([]), [x, g] = (0, r.useState)([]), f = (e, t) => {
                    let a = n;
                    "country" == e && (a.country = t.name, a.countryCode = t.isoCode, delete a.region, delete a.regionCode, delete a.city, g(u.getStatesOfCountry(t.isoCode)), h(m.getCitiesOfCountry(t.isoCode))), "region" == e && (a.region = t.name, a.regionCode = t.isoCode, delete a.city, h(m.getCitiesOfState(t.countryCode, t.isoCode))), "city" == e && (a.city = t.name), s({ ...a
                    })
                };
                return (0, r.useEffect)(() => {
                    g(u.getStatesOfCountry(n.countryCode)), n.region ? h(m.getCitiesOfState(n.countryCode, n.regionCode)) : h(m.getCitiesOfCountry(n.countryCode))
                }, []), (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsxs)("div", {
                        className: "mt-3",
                        children: [(0, l.jsxs)("label", {
                            htmlFor: "country",
                            children: ["Country", i && (a ? " (Optional)" : "*")]
                        }), (0, l.jsx)(c.ZP, {
                            id: "country",
                            className: "text-gray-900",
                            onChange: e => f("country", e),
                            value: n && n.country ? {
                                label: n.country,
                                value: n.country
                            } : {
                                label: "",
                                value: ""
                            },
                            options: d.getAllCountries().map(e => ({
                                label: e.name,
                                ...e
                            }))
                        })]
                    }), n && n.country && (0, l.jsxs)("div", {
                        className: "mt-3",
                        children: [(0, l.jsx)("label", {
                            htmlFor: "region",
                            children: n && "US" == n.countryCode ? "State" : "Region"
                        }), (0, l.jsx)(c.ZP, {
                            id: "region",
                            className: "text-gray-900",
                            onChange: e => f("region", e),
                            value: n && n.region ? {
                                label: n.region,
                                value: n.region
                            } : {
                                label: "",
                                value: ""
                            },
                            options: x.map(e => ({
                                label: e.name,
                                ...e
                            }))
                        })]
                    }), n && n.countryCode && ("US" !== n.countryCode || n.region) && (0, l.jsxs)("div", {
                        className: "mt-3",
                        children: [(0, l.jsx)("label", {
                            htmlFor: "city",
                            children: "City"
                        }), (0, l.jsx)(c.ZP, {
                            id: "city",
                            className: "text-gray-900",
                            onChange: e => f("city", e),
                            value: n && n.city ? {
                                label: n.city,
                                value: n.city
                            } : {
                                label: "",
                                value: ""
                            },
                            options: p.map(e => ({
                                label: e.name,
                                ...e
                            }))
                        })]
                    })]
                })
            };
            var h = n(6235);

            function x(e) {
                let {
                    value: t,
                    onChange: n
                } = e, s = (0, r.useRef)(null);
                return (0, l.jsx)(l.Fragment, {
                    children: (0, l.jsx)(h.M, {
                        apiKey: "f1qri9c5ze4v8f4cez98nonfsks5zgqj7dr4ax5uqmyzccxg",
                        onInit: (e, t) => s.current = t,
                        value: t,
                        onEditorChange: n,
                        init: {
                            statusbar: !1,
                            height: 250,
                            menubar: !1,
                            plugins: "link lists",
                            toolbar: "undo redo | styleselect | bold italic | bullist numlist | outdent indent | link",
                            content_style: "body { font-family:Helvetica,Arial,sans-serif; font-size:14px }"
                        }
                    })
                })
            }
            let g = e => {
                    let {
                        id: t,
                        options: n,
                        value: s,
                        onChange: a,
                        isMulti: i,
                        placeholder: r,
                        ...o
                    } = e;
                    return (0, l.jsx)(l.Fragment, {
                        children: (0, l.jsx)(c.ZP, {
                            isMulti: i,
                            id: t,
                            className: "text-gray-900",
                            onChange: a,
                            placeholder: r || "Select...",
                            value: s ? Array.isArray(s) ? s.map(e => ({
                                value: e,
                                label: e
                            })) : {
                                value: s,
                                label: s
                            } : n[0],
                            options: n.map(e => ({
                                value: e,
                                label: e
                            }))
                        })
                    })
                },
                f = e => {
                    let {
                        property: t,
                        value: n,
                        setProperty: s,
                        optional: a,
                        showOptional: i = !1,
                        ...r
                    } = e;
                    return (0, l.jsxs)("div", {
                        className: "mt-3 max-w-lg",
                        children: ["location" !== t.name && (0, l.jsxs)("label", {
                            htmlFor: t.name,
                            children: [t.label ? t.label : (0, o.Q)(t.name.split("_").join(" ").replace("hq", "HQ").replace(" url", " URL")), i ? a ? " (Optional)" : "*" : ""]
                        }), "number" == t.type && (0, l.jsx)("input", {
                            autoComplete: "off",
                            className: "block appearance-none min-w-[80%] w-full md:min-w-0 h-8 bg-gray-50 text-gray-800 border rounded py-1 px-1 leading-tight focus:outline-none focus:bg-white",
                            id: t.name,
                            type: "number",
                            value: n,
                            onChange: e => s(t.name, e.target.value)
                        }), ["multiselect", "select"].includes(t.type) && (0, l.jsx)(g, {
                            id: t.name,
                            placeholder: t.placeholder || "Select...",
                            isMulti: "multiselect" == t.type,
                            className: "text-gray-900",
                            value: n,
                            onChange: e => "multiselect" == t.type ? s(t.name, e.map(e => e.value)) : s(t.name, e.value),
                            options: t.options
                        }), "textarea" == t.type && (0, l.jsx)(x, {
                            value: n,
                            onChange: e => s(t.name, e)
                        }), "text" == t.type && (0, l.jsx)("input", {
                            autoComplete: "off",
                            className: "block appearance-none min-w-[80%] w-full md:min-w-0 h-8 bg-gray-50 text-gray-800 border rounded py-1 px-1 leading-tight focus:outline-none focus:bg-white",
                            id: t.name,
                            type: "text",
                            value: n,
                            onChange: e => s(t.name, e.target.value)
                        }), "location" == t.name && (0, l.jsx)(p, {
                            id: "location",
                            className: "text-gray-900",
                            location: n,
                            optional: a,
                            showOptional: i,
                            setLocation: e => s("location", e)
                        })]
                    }, t.name)
                };
            var j = f,
                y = n(84053),
                b = n(65631),
                w = n.n(b),
                v = n(9008),
                N = n.n(v);

            function _(e) {
                let {
                    previewSrc: t,
                    label: n,
                    upload: s
                } = e;
                return (0, l.jsxs)("div", {
                    className: "mt-3",
                    children: [(0, l.jsx)("div", {
                        className: "flex justify-center",
                        children: t ? (0, l.jsx)("img", {
                            className: "h-20 w-20 rounded-full",
                            src: t
                        }) : (0, l.jsx)("div", {
                            className: "h-20 w-20 rounded-full bg-gray-400"
                        })
                    }), (0, l.jsxs)("label", {
                        htmlFor: "upload",
                        children: [n, "*"]
                    }), (0, l.jsx)("input", {
                        id: "upload",
                        type: "file",
                        accept: "image/*",
                        className: "block w-auto text-gray-900 bg-gray-50 rounded-lg border border-gray-300 cursor-pointer dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400",
                        async onChange(e) {
                            let t = e.target.files[0];
                            s(t)
                        }
                    })]
                })
            }
            var C = n(38597),
                S = n(2568),
                k = n.n(S),
                D = n(41664),
                P = n.n(D);
            let E = () => (0, l.jsx)("div", {
                className: "w-48 h-full shadow-md mt-4 px-1 absolute",
                children: (0, l.jsxs)("ul", {
                    className: "relative",
                    children: [(0, l.jsx)("li", {
                        className: "relative",
                        children: (0, l.jsx)(P(), {
                            href: "/employer/jobs",
                            className: "flex items-center mt-3 px-6 overflow-hidden text-white text-ellipsis whitespace-nowrap no-underline",
                            children: "My Jobs"
                        })
                    }), (0, l.jsx)("li", {
                        className: "relative",
                        children: (0, l.jsx)(P(), {
                            href: "/employer/info",
                            className: "flex items-center mt-3 px-6 overflow-hidden text-white text-ellipsis whitespace-nowrap no-underline",
                            children: "Employer Info"
                        })
                    }), (0, l.jsx)("li", {
                        className: "relative",
                        children: (0, l.jsx)(P(), {
                            href: "/employer/post-job",
                            className: "flex items-center mt-3 px-6 overflow-hidden text-white text-ellipsis whitespace-nowrap no-underline",
                            children: "Post New Job"
                        })
                    }), (0, l.jsx)("li", {
                        className: "relative",
                        children: (0, l.jsx)(P(), {
                            href: "/employer/sign-out",
                            className: "flex items-center mt-3 px-6 overflow-hidden text-white text-ellipsis whitespace-nowrap no-underline",
                            children: "Sign Out"
                        })
                    })]
                })
            });

            function O(e) {
                let {
                    session: t
                } = e, n = (0, y.useSupabaseClient)(), i = (0, y.useUser)(), [o, c] = (0, r.useState)(""), [d, u] = (0, r.useState)(!0), [m, p] = (0, r.useState)({}), [h, x] = (0, r.useState)({}), [g, f] = (0, r.useState)("");
                (0, r.useEffect)(() => {
                    D()
                }, [t]);
                let b = async e => {
                        let t = e.name.split("?")[0].split("/").slice(-1)[0],
                            {
                                data: s,
                                error: a
                            } = await n.storage.from("public").upload("".concat(k()(m.id), "__").concat(t), e, {
                                upsert: !0
                            });
                        f("https://jwwrbzsvyukwfpbuimxf.supabase.co/storage/v1/object/public/public/".concat(k()(m.id), "__").concat(t))
                    },
                    v = (e, t) => {
                        c("");
                        let n = m;
                        n[e] = t, p({ ...n
                        })
                    },
                    S = (e, t) => {
                        c("");
                        let n = h;
                        n[e] = t, x({ ...n
                        })
                    };
                async function D() {
                    u(!0);
                    try {
                        let {
                            data: e,
                            error: t,
                            status: s
                        } = await n.from("employers").select().eq("id", i.id).single();
                        if (t && 406 !== s) throw t;
                        e && p(e);
                        let {
                            data: a,
                            error: l,
                            status: r
                        } = await n.from("companies").select().contains("employer_ids", [i.id]).maybeSingle();
                        if (l && 406 !== r) throw console.log("company error"), l;
                        a && (a.allow_resume = a.allow_resume ? "Yes" : "No", f(a.company_logo_url), x(a))
                    } catch (o) {
                        console.log(o)
                    }
                    u(!1)
                }
                async function P() {
                    try {
                        u(!0);
                        let e = { ...h
                        };
                        e.company_logo_url = g, e.employer_ids = [i.id], e.allow_resume = "Yes" == e.allow_resume;
                        let t = [...C.PE.employer.properties.filter(e => !e.optional).map(e => e.name)],
                            s = [...C.r7.company.properties.filter(e => !e.optional).map(e => e.name)];
                        for (let a = 0; a < t.length; a++) {
                            let l = t[a];
                            if (!m[l]) throw Error("Missing field: ".concat(l))
                        }
                        for (let r = 0; r < s.length; r++) {
                            let o = s[r];
                            if (!e[o]) throw Error("Missing field: ".concat(o))
                        }
                        if (!e.company_logo_url) throw Error("Missing field: Company Logo");
                        let {
                            employerError: d
                        } = await n.from("employers").upsert(m), {
                            companyError: p
                        } = await n.from("companies").upsert(e);
                        if (d || p) throw error;
                        c("Profile Updated!")
                    } catch (x) {
                        c(x.toString())
                    } finally {
                        u(!1)
                    }
                }
                return (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsxs)(N(), {
                        children: [(0, l.jsx)(a.Z, {}), (0, l.jsx)("title", {
                            children: "Employer Information"
                        })]
                    }), (0, l.jsx)(w(), {}), (0, l.jsx)(E, {}), (0, l.jsx)("div", {
                        className: "flex flex-row min-h-screen justify-center px-4 md:px-16 lg:px-24 w-full",
                        children: (0, l.jsx)("div", {
                            className: "content-center w-full max-w-4xl mt-5",
                            children: (0, l.jsx)("div", {
                                className: "flex justify-center",
                                children: (0, l.jsxs)("div", {
                                    className: "w-96",
                                    children: [(0, l.jsx)("div", {
                                        className: "text-center text-xl",
                                        children: "Employer Information"
                                    }), (0, l.jsx)("div", {
                                        className: "mt-2",
                                        children: "Employer info must be filled out before posting jobs."
                                    }), (0, l.jsx)("div", {
                                        className: "mt-2",
                                        children: "* indicates a required field"
                                    }), (0, l.jsx)(_, {
                                        previewSrc: g,
                                        label: "Upload Company Logo",
                                        upload: b
                                    }), C.PE.employer.properties.map(e => (0, l.jsx)(j, {
                                        optional: e.optional,
                                        showOptional: !0,
                                        value: m[e.name] || "",
                                        property: e,
                                        setProperty: v
                                    }, e.name)), C.r7.company.properties.map(e => (0, l.jsx)(j, {
                                        optional: e.optional,
                                        showOptional: !0,
                                        value: h[e.name] || "",
                                        property: e,
                                        setProperty: S
                                    }, e.name)), (0, l.jsx)("div", {
                                        className: "mt-3 flex justify-center",
                                        children: (0, l.jsx)(s.default, {
                                            className: "w-32 py-1 px-3",
                                            onClick: P,
                                            disabled: d,
                                            children: "Update Profile"
                                        })
                                    }), (0, l.jsx)("div", {
                                        className: "pt-3 text-center",
                                        style: {
                                            height: "40px"
                                        },
                                        children: o
                                    })]
                                })
                            })
                        })
                    })]
                })
            }
            var L = n(53447),
                F = n(25675),
                A = n.n(F);
            let Z = e => {
                let {
                    job: t,
                    editMode: n,
                    closeJob: a
                } = e, i = "/jobs/".concat(t.job_title.toLowerCase().replaceAll(" ", "-"), "/").concat(t.id);
                return (0, l.jsx)(P(), {
                    className: "no-underline",
                    href: n ? "#" : i,
                    children: (0, l.jsxs)("div", {
                        className: "mt-2 p-2 cursor-pointer border-2 border-white rounded flex flex-row relative h-32 ".concat(n ? "" : "hover:bg-gray-600"),
                        children: [n ? (0, l.jsxs)("div", {
                            className: "absolute top-2 right-2",
                            children: [(0, l.jsx)("div", {
                                className: "mt-2",
                                children: (0, l.jsx)(P(), {
                                    href: i,
                                    children: (0, l.jsx)(s.default, {
                                        onClick() {},
                                        className: "w-24",
                                        children: "View"
                                    })
                                })
                            }), (0, l.jsx)("div", {
                                className: "mt-2",
                                children: (0, l.jsx)(P(), {
                                    href: "/employer/edit-job/".concat(t.id),
                                    children: (0, l.jsx)(s.default, {
                                        onClick() {},
                                        className: "w-24",
                                        children: "Edit"
                                    })
                                })
                            }), (0, l.jsx)("div", {
                                className: "mt-2",
                                children: (0, l.jsx)(s.default, {
                                    onClick: () => a(t.id),
                                    className: "w-24",
                                    children: "Close"
                                })
                            })]
                        }) : (0, l.jsxs)("div", {
                            children: [(0, l.jsxs)("div", {
                                className: "absolute top-2 right-2",
                                children: [(0, l.jsxs)("div", {
                                    className: "text-right",
                                    children: [t.location && t.location.city && t.location.city + ", ", t.location && t.location.country]
                                }), (0, l.jsx)("div", {
                                    className: "text-right",
                                    children: t.remote_policy
                                }), (0, l.jsx)("div", {
                                    className: "text-right",
                                    children: t.employment_type
                                })]
                            }), (0, l.jsx)("div", {
                                className: "absolute bottom-2 right-2",
                                children: t.created_at.slice(0, 10)
                            })]
                        }), (0, l.jsx)("div", {
                            className: "justify-center items-center flex pl-1 pr-2",
                            children: (0, l.jsx)(A(), {
                                height: 120,
                                width: 120,
                                className: "rounded-full",
                                alt: t.companies.company_name,
                                src: t.companies.company_logo_url
                            })
                        }), (0, l.jsxs)("div", {
                            className: "inline",
                            children: [(0, l.jsx)("div", {
                                className: "text-lg underline",
                                children: t.job_title
                            }), (0, l.jsx)("div", {
                                children: t.companies && t.companies.company_name
                            }), (t.annual_compensation_range_min || t.annual_compensation_range_max) && (0, l.jsxs)("div", {
                                children: [t.annual_compensation_range_min ? "$".concat(t.annual_compensation_range_min) : "Up to ", t.annual_compensation_range_min && t.annual_compensation_range_max && " - ", t.annual_compensation_range_max ? "$".concat(t.annual_compensation_range_max) : "+"]
                            }), (t.hourly_compensation_range_min || t.hourly_compensation_range_max) && (0, l.jsxs)("div", {
                                children: [t.hourly_compensation_range_min ? "$".concat(t.hourly_compensation_range_min) : "Up to ", t.hourly_compensation_range_min && t.hourly_compensation_range_max && " - ", t.hourly_compensation_range_max ? "$".concat(t.hourly_compensation_range_max) : "+", "/hr"]
                            }), (0, l.jsx)("div", {
                                style: {
                                    height: "35px"
                                },
                                children: t.technologies && t.technologies.length > 0 && t.technologies.map(e => (0, l.jsx)("span", {
                                    className: "gradient px-1 rounded m-1",
                                    children: e
                                }, e))
                            })]
                        })]
                    })
                }, t.id)
            };
            var T = Z;
            let U = e => {
                let {
                    children: t,
                    footerLinks: n,
                    title: s,
                    description: i
                } = e;
                return (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsxs)(N(), {
                        children: [(0, l.jsx)(a.Z, {}), (0, l.jsx)("title", {
                            children: s
                        }), (0, l.jsx)("meta", {
                            property: "og:title",
                            content: s
                        }), (0, l.jsx)("meta", {
                            name: "description",
                            content: i
                        }), (0, l.jsx)("meta", {
                            property: "og:description",
                            content: i
                        }), (0, l.jsx)("script", {
                            defer: !0,
                            src: "https://www.googleoptimize.com/optimize.js?id=OPT-KKW2K5F"
                        })]
                    }), (0, l.jsxs)("div", {
                        className: "flex flex-col h-screen justify-between",
                        children: [(0, l.jsx)("div", {
                            className: "flex items-center justify-center mb-auto h-screen",
                            children: (0, l.jsx)("main", {
                                className: "content-center max-w-xl",
                                children: (0, l.jsx)("div", {
                                    className: "text-center",
                                    children: t
                                })
                            })
                        }), (0, l.jsx)(L.Z, {
                            links: n
                        })]
                    })]
                })
            };
            var J = U,
                M = n(11163),
                q = n.n(M),
                R = n(16782),
                I = n(47041);

            function B(e) {
                let {
                    newsletter: t
                } = e, n = (0, M.useRouter)(), a = n.query.email || "", [i, o] = (0, r.useState)("tech" == t), [c, d] = (0, r.useState)("crypto" == t), [u, m] = (0, r.useState)("ai" == t), [p, h] = (0, r.useState)("cybersecurity" == t), [x, g] = (0, r.useState)("product" == t), [f, j] = (0, r.useState)("design" == t), [y, b] = (0, r.useState)("marketing" == t), [w, v] = (0, r.useState)("founders" == t), [N, _] = (0, r.useState)("engineering" == t), [C, S] = (0, r.useState)(!1), [k, D] = (0, r.useState)(null), [P, E] = (0, r.useState)(""), [O, L] = (0, r.useState)([]), [F, A] = (0, r.useState)([]), Z = e => {
                    E(""), "tech" == e ? o(!i) : "engineering" == e ? _(!N) : "ai" == e ? m(!u) : "cybersecurity" == e ? h(!p) : "crypto" == e ? d(!c) : "product" == e ? g(!x) : "design" == e ? j(!f) : "marketing" == e ? b(!y) : "founders" == e && v(!w)
                };
                (0, r.useEffect)(() => {
                    let e = [],
                        t = [];
                    i ? k && !k.tech_subscribed && e.push("tech") : k && k.tech_subscribed && t.push("tech"), c ? k && !k.crypto_subscribed && e.push("crypto") : k && k.crypto_subscribed && t.push("crypto"), u ? k && !k.ai_subscribed && e.push("ai") : k && k.ai_subscribed && t.push("ai"), N ? k && !k.engineering_subscribed && e.push("engineering") : k && k.engineering_subscribed && t.push("engineering"), p ? k && !k.cybersecurity_subscribed && e.push("cybersecurity") : k && k.cybersecurity_subscribed && t.push("cybersecurity"), x ? k && !k.product_subscribed && e.push("product") : k && k.product_subscribed && t.push("product"), y ? k && !k.marketing_subscribed && e.push("marketing") : k && k.marketing_subscribed && t.push("marketing"), f ? k && !k.design_subscribed && e.push("design") : k && k.design_subscribed && t.push("design"), w ? k && !k.founders_subscribed && e.push("founders") : k && k.founders_subscribed && t.push("founders"), L(e), A(t)
                }, [i, u, c, p, N, x, y, f, w]), (0, r.useEffect)(() => {
                    let e = async () => {
                        if (a) {
                            let e = await fetch("".concat("https://tldr-tech.vercel.app", "/api/reader?email=").concat(a)),
                                {
                                    reader: t
                                } = await e.json();
                            D(t), t && t.tech_subscribed && o(!0), t && t.ai_subscribed && m(!0), t && t.cybersecurity_subscribed && h(!0), t && t.engineering_subscribed && _(!0), t && t.crypto_subscribed && d(!0), t && t.design_subscribed && j(!0), t && t.product_subscribed && g(!0), t && t.marketing_subscribed && b(!0), t && t.founders_subscribed && v(!0)
                        }
                    };
                    e()
                }, [a]);
                let T = async e => {
                    e.preventDefault(), C || (S(!0), console.log(O), console.log(F), await Promise.allSettled([fetch("/api/subscribe", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            email: a,
                            newsletters: O,
                            landingPage: (0, I.getCookie)("landingPage")
                        })
                    }), fetch("/api/unsubscribe", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            email: a,
                            newsletters: F,
                            landingPage: (0, I.getCookie)("landingPage")
                        })
                    })]), E("Subscriptions Updated!"), S(!1))
                };
                return (0, l.jsxs)("div", {
                    className: "content-center max-w-xl mt-5",
                    children: ["tech" !== t && (0, l.jsxs)("div", {
                        children: [(0, l.jsx)(R.r, {
                            checked: i,
                            onChange: () => Z("tech"),
                            className: "".concat(i ? "bg-green-600" : "bg-gray-200", " relative inline-flex h-4 w-10 items-center rounded-full"),
                            children: (0, l.jsx)("span", {
                                className: "".concat(i ? "translate-x-6" : "translate-x-1", " inline-block h-3 w-3 transform rounded-full bg-white transition")
                            })
                        }), (0, l.jsx)("span", {
                            className: "pl-2 inline",
                            children: "TLDR Tech Daily"
                        })]
                    }), "engineering" !== t && (0, l.jsxs)("div", {
                        children: [(0, l.jsx)(R.r, {
                            checked: N,
                            onChange: () => Z("engineering"),
                            className: "".concat(N ? "bg-green-600" : "bg-gray-200", " relative inline-flex h-4 w-10 items-center rounded-full"),
                            children: (0, l.jsx)("span", {
                                className: "".concat(N ? "translate-x-6" : "translate-x-1", " inline-block h-3 w-3 transform rounded-full bg-white transition")
                            })
                        }), (0, l.jsx)("span", {
                            className: "pl-2 inline",
                            children: "TLDR Web Development (Frontend, Backend, and Full Stack)"
                        })]
                    }), "crypto" !== t && (0, l.jsxs)("div", {
                        children: [(0, l.jsx)(R.r, {
                            checked: c,
                            onChange: () => Z("crypto"),
                            className: "".concat(c ? "bg-green-600" : "bg-gray-200", " relative inline-flex h-4 w-10 items-center rounded-full"),
                            children: (0, l.jsx)("span", {
                                className: "".concat(c ? "translate-x-6" : "translate-x-1", " inline-block h-3 w-3 transform rounded-full bg-white transition")
                            })
                        }), (0, l.jsx)("span", {
                            className: "pl-2 inline",
                            children: "TLDR Crypto & Web3"
                        })]
                    }), "ai" !== t && (0, l.jsxs)("div", {
                        children: [(0, l.jsx)(R.r, {
                            checked: u,
                            onChange: () => Z("ai"),
                            className: "".concat(u ? "bg-green-600" : "bg-gray-200", " relative inline-flex h-4 w-10 items-center rounded-full"),
                            children: (0, l.jsx)("span", {
                                className: "".concat(u ? "translate-x-6" : "translate-x-1", " inline-block h-3 w-3 transform rounded-full bg-white transition")
                            })
                        }), (0, l.jsx)("span", {
                            className: "pl-2 inline",
                            children: "TLDR AI, Machine Learning & Data Science"
                        })]
                    }), "cybersecurity" !== t && (0, l.jsxs)("div", {
                        children: [(0, l.jsx)(R.r, {
                            checked: p,
                            onChange: () => Z("cybersecurity"),
                            className: "".concat(p ? "bg-green-600" : "bg-gray-200", " relative inline-flex h-4 w-10 items-center rounded-full"),
                            children: (0, l.jsx)("span", {
                                className: "".concat(p ? "translate-x-6" : "translate-x-1", " inline-block h-3 w-3 transform rounded-full bg-white transition")
                            })
                        }), (0, l.jsx)("span", {
                            className: "pl-2 inline",
                            children: "TLDR Cybersecurity"
                        })]
                    }), "product" !== t && (0, l.jsxs)("div", {
                        children: [(0, l.jsx)(R.r, {
                            checked: x,
                            onChange: () => Z("product"),
                            className: "".concat(x ? "bg-green-600" : "bg-gray-200", " relative inline-flex h-4 w-10 items-center rounded-full"),
                            children: (0, l.jsx)("span", {
                                className: "".concat(x ? "translate-x-6" : "translate-x-1", " inline-block h-3 w-3 transform rounded-full bg-white transition")
                            })
                        }), (0, l.jsx)("span", {
                            className: "pl-2 inline",
                            children: "TLDR Product Management"
                        })]
                    }), "design" !== t && (0, l.jsxs)("div", {
                        children: [(0, l.jsx)(R.r, {
                            checked: f,
                            onChange: () => Z("design"),
                            className: "".concat(f ? "bg-green-600" : "bg-gray-200", " relative inline-flex h-4 w-10 items-center rounded-full"),
                            children: (0, l.jsx)("span", {
                                className: "".concat(f ? "translate-x-6" : "translate-x-1", " inline-block h-3 w-3 transform rounded-full bg-white transition")
                            })
                        }), (0, l.jsx)("span", {
                            className: "pl-2 inline",
                            children: "TLDR Design"
                        })]
                    }), "founders" !== t && (0, l.jsxs)("div", {
                        children: [(0, l.jsx)(R.r, {
                            checked: w,
                            onChange: () => Z("founders"),
                            className: "".concat(w ? "bg-green-600" : "bg-gray-200", " relative inline-flex h-4 w-10 items-center rounded-full"),
                            children: (0, l.jsx)("span", {
                                className: "".concat(w ? "translate-x-6" : "translate-x-1", " inline-block h-3 w-3 transform rounded-full bg-white transition")
                            })
                        }), (0, l.jsx)("span", {
                            className: "pl-2 inline",
                            children: "TLDR Founders & Entrepreneurs"
                        })]
                    }), "marketing" !== t && (0, l.jsxs)("div", {
                        children: [(0, l.jsx)(R.r, {
                            checked: y,
                            onChange: () => Z("marketing"),
                            className: "".concat(y ? "bg-green-600" : "bg-gray-200", " relative inline-flex h-4 w-10 items-center rounded-full"),
                            children: (0, l.jsx)("span", {
                                className: "".concat(y ? "translate-x-6" : "translate-x-1", " inline-block h-3 w-3 transform rounded-full bg-white transition")
                            })
                        }), (0, l.jsx)("span", {
                            className: "pl-2 inline",
                            children: "TLDR Marketing"
                        })]
                    }), (0, l.jsx)("div", {
                        className: "mt-3 flex justify-center",
                        children: (0, l.jsx)(s.default, {
                            background: 0 == F.length && 0 == O.length ? "gray" : "linear-gradient(-225deg, #AC32E4 0%, #7918F2 48%, #5a19ff 100%)",
                            onClick: T,
                            className: "py-1",
                            children: C ? "Updating..." : "Update Subscriptions"
                        })
                    }), (0, l.jsx)("div", {
                        className: "pt-3 text-center",
                        style: {
                            height: "40px"
                        },
                        children: P
                    })]
                })
            }
            var z = n(11104);

            function W(e) {
                let {
                    session: t,
                    jobId: n
                } = e, i = (0, y.useSupabaseClient)(), o = (0, y.useUser)(), [c, d] = (0, r.useState)(!0), [u, m] = (0, r.useState)(""), [p, h] = (0, r.useState)({}), [x, g] = (0, r.useState)({}), [f, b] = (0, r.useState)({});
                (0, r.useEffect)(() => {
                    _()
                }, [t]);
                let v = (e, t) => {
                    m("");
                    let s = f;
                    s[e] = t, b({ ...s
                    }), n || (0, I.setCookie)("jobAutosave", JSON.stringify(s))
                };
                async function _() {
                    d(!0);
                    try {
                        if (n) {
                            let {
                                data: e,
                                error: t,
                                status: s
                            } = await i.from("jobs").select().eq("id", n).single();
                            if (t && 406 !== s) throw Error(JSON.stringify(t));
                            e && b(e)
                        }
                        let {
                            data: a,
                            error: l,
                            status: r
                        } = await i.from("employers").select().eq("id", o.id).single();
                        if (l && 406 !== r) throw l;
                        a && h(a);
                        let {
                            data: c,
                            error: u,
                            status: m
                        } = await i.from("companies").select().contains("employer_ids", [o.id]).maybeSingle();
                        if (u && 406 !== m) throw Error(JSON.stringify(u));
                        c && (c.allow_resume = c.allow_resume ? "Yes" : "No", g(c)), !n && (0, I.hasCookie)("jobAutosave") && b({ ...JSON.parse((0, I.getCookie)("jobAutosave"))
                        })
                    } catch (p) {
                        alert("Please fill out employer information before posting a job"), q().push("/employer/info"), console.log(p)
                    }
                    d(!1)
                }
                async function S() {
                    try {
                        d(!0);
                        let e = { ...f
                        };
                        e.company_id = x.id;
                        let t = [],
                            n = Object.keys(C.BL);
                        for (let s = 0; s < n.length; s++) {
                            let a = C.BL[n[s]];
                            for (let l = 0; l < a.properties.length; l++) {
                                let r = a.properties[l];
                                r.optional || t.push(r.name)
                            }
                        }
                        if (!e.company_id) throw Error("Your job info has been saved. Please complete your Employer Info before posting this job.");
                        for (let o = 0; o < t.length; o++) {
                            let c = t[o];
                            if (!e[c]) throw console.log(c), Error("Missing field: ".concat(c))
                        }
                        let {
                            data: u,
                            error: p
                        } = await i.from("jobs").upsert(e, {
                            onConflict: "id"
                        }).select().single();
                        if (p) throw Error(JSON.stringify(p));
                        (0, I.setCookie)("jobAutosave", JSON.stringify({})), q().push("/jobs/".concat(u.job_title.toLowerCase().replaceAll(" ", "-"), "/").concat(u.id)), m("Posting Job...")
                    } catch (h) {
                        m(h.toString())
                    } finally {
                        d(!1)
                    }
                }
                return (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsxs)(N(), {
                        children: [(0, l.jsx)(a.Z, {}), (0, l.jsx)("title", {
                            children: "Employer Information"
                        })]
                    }), (0, l.jsx)(w(), {}), (0, l.jsx)(E, {}), (0, l.jsx)("div", {
                        className: "flex flex-row min-h-screen justify-center px-4 md:px-16 lg:px-24 w-full h-full mb-5",
                        children: (0, l.jsx)("div", {
                            className: "content-center w-full max-w-4xl mt-5 mb-5",
                            children: (0, l.jsx)("div", {
                                className: "flex justify-center",
                                children: (0, l.jsxs)("div", {
                                    className: "w-96",
                                    children: [(0, l.jsx)("div", {
                                        className: "text-center text-xl",
                                        children: "Job Information"
                                    }), (0, l.jsx)("div", {
                                        className: "mt-2",
                                        children: "Posting jobs is completely free, please fill out employer info before posting jobs"
                                    }), (0, l.jsx)("div", {
                                        className: "mt-2",
                                        children: "* indicates a required field"
                                    }), C.BL.job_title.properties.map(e => (0, l.jsx)(j, {
                                        value: f[e.name],
                                        property: e,
                                        optional: e.optional,
                                        showOptional: !0,
                                        setProperty: v
                                    }, e.name)), "Salary" == f.compensation_type && C.BL.compensation.properties.filter(e => e.name.includes("annual_compensation")).map(e => (0, l.jsx)(j, {
                                        value: f[e.name],
                                        property: e,
                                        optional: e.optional,
                                        showOptional: !0,
                                        setProperty: v
                                    }, e.name)), "Hourly" == f.compensation_type && C.BL.compensation.properties.filter(e => e.name.includes("hourly_compensation")).map(e => (0, l.jsx)(j, {
                                        value: f[e.name],
                                        property: e,
                                        optional: e.optional,
                                        showOptional: !0,
                                        setProperty: v
                                    }, e.name)), C.BL.location.properties.map(e => (0, l.jsx)(j, {
                                        value: f[e.name],
                                        property: e,
                                        optional: e.optional,
                                        showOptional: !0,
                                        setProperty: v
                                    }, e.name)), C.BL.technology.properties.map(e => (0, l.jsx)(j, {
                                        value: f[e.name],
                                        property: e,
                                        optional: e.optional,
                                        showOptional: !0,
                                        setProperty: v
                                    }, e.name)), (0, l.jsx)("div", {
                                        className: "mt-3 flex justify-center",
                                        children: (0, l.jsx)(s.default, {
                                            onClick: S,
                                            className: "w-32 py-1 px-3",
                                            children: "Post Job"
                                        })
                                    }), (0, l.jsx)("div", {
                                        className: "pt-3 text-center",
                                        style: {
                                            height: "40px"
                                        },
                                        children: u
                                    })]
                                })
                            })
                        })
                    })]
                })
            }
            n(76120), n(43726);
            let K = e => {
                let {
                    newsletter: t
                } = e, n = "Almost done, you're so close! \uD83E\uDD0F", s = "Please check your email for a confirmation email.";
                return (0, l.jsxs)("div", {
                    children: [(0, l.jsxs)(N(), {
                        children: [(0, l.jsx)(a.Z, {}), (0, l.jsx)("script", {
                            defer: !0,
                            src: "/track.js"
                        }), (0, l.jsx)("title", {
                            children: n
                        }), (0, l.jsx)("meta", {
                            property: "og:title",
                            content: n
                        }), (0, l.jsx)("meta", {
                            name: "description",
                            content: s
                        }), (0, l.jsx)("meta", {
                            property: "og:description",
                            content: s
                        })]
                    }), (0, l.jsx)("div", {
                        className: "flex flex-row min-h-screen justify-center px-4 md:px-16 lg:px-24 max-width-xl",
                        children: (0, l.jsxs)("div", {
                            className: "content-center max-w-xl mt-5",
                            children: [(0, l.jsx)("h1", {
                                className: "text-center text-lg font-bold text-center",
                                children: n
                            }), (0, l.jsx)("div", {
                                className: "text-center",
                                children: s
                            }), (0, l.jsx)("h3", {
                                className: "mt-5",
                                children: "Want more TLDR? \uD83E\uDDE0"
                            }), (0, l.jsxs)("div", {
                                children: ["In addition to ", (0, C.KA)(t), ", we also write newsletters for specific jobs and industries within tech."]
                            }), (0, l.jsx)(B, {
                                newsletter: t
                            })]
                        })
                    })]
                })
            };
            var Q = K;

            function H(e) {
                let {
                    session: t
                } = e, n = (0, y.useSupabaseClient)(), s = (0, y.useUser)(), [i, o] = (0, r.useState)(!0), [c, d] = (0, r.useState)(null);
                (0, r.useEffect)(() => {
                    m()
                }, [t]);
                let u = async e => {
                    let {
                        data: t,
                        error: s
                    } = await n.from("jobs").update({
                        closed: !0
                    }).eq("id", e);
                    s ? alert(s) : m()
                };
                async function m() {
                    o(!0);
                    try {
                        let {
                            data: e,
                            error: t,
                            status: a
                        } = await n.from("companies").select().contains("employer_ids", [s.id]).maybeSingle();
                        if (t && 406 !== a) throw console.log("company error"), t;
                        if (e) {
                            let i = await fetch("".concat("https://tldr-tech.vercel.app", "/api/companies?company_name=").concat(e.company_name.toLowerCase().replaceAll(" ", "-"))),
                                l = await i.json();
                            d(l)
                        }
                    } catch (r) {
                        q().push("/employer/info"), console.log(r)
                    }
                    o(!1)
                }
                return (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsxs)(N(), {
                        children: [(0, l.jsx)(a.Z, {}), (0, l.jsx)("title", {
                            children: "View Jobs"
                        })]
                    }), (0, l.jsx)(w(), {}), (0, l.jsx)(E, {}), (0, l.jsx)("div", {
                        className: "flex flex-row min-h-screen justify-center px-4 md:px-16 lg:px-24 w-full",
                        children: (0, l.jsx)("div", {
                            className: "w-full mt-5 flex justify-center",
                            children: (0, l.jsxs)("div", {
                                className: "max-w-3xl w-9/12",
                                children: [(0, l.jsx)("div", {
                                    className: "text-center text-xl mb-3",
                                    children: "Open Jobs"
                                }), c && c.jobs ? c.jobs.map(e => (0, l.jsx)(T, {
                                    job: e,
                                    editMode: !0,
                                    closeJob: u
                                }, e.id)) : !i && (0, l.jsx)("div", {
                                    className: "text-center",
                                    children: "No Current Jobs."
                                })]
                            })
                        })
                    })]
                })
            }
            n(43726);
            let Y = e => {
                let {
                    isSignUp: t
                } = e, [n, a] = (0, r.useState)(""), [i, o] = (0, r.useState)(""), [c, d] = (0, r.useState)(""), u = (0, y.useUser)();
                (0, y.useSession)();
                let m = (0, y.useSupabaseClient)();
                (0, r.useEffect)(() => {
                    u && q().push("/employer/jobs")
                }, [u]);
                let p = async () => {
                    if (c.length < 6) o("Password must be at least 6 characters long.");
                    else if (n && c) {
                        if (t) {
                            let {
                                data: e,
                                error: s
                            } = await m.auth.signUp({
                                email: n,
                                password: c
                            }, {
                                redirectTo: "https://tldr-tech.vercel.app/employer/info"
                            });
                            s ? o(JSON.stringify(s)) : o("Signing Up...")
                        } else {
                            let {
                                data: a,
                                error: i
                            } = await m.auth.signInWithPassword({
                                email: n,
                                password: c
                            }, {
                                redirectTo: "https://tldr-tech.vercel.app/employer/jobs"
                            });
                            i ? o(JSON.stringify(i)) : o("Signing In...")
                        }
                    } else o("Please enter both an email and a password")
                };
                return (0, l.jsxs)(l.Fragment, {
                    children: [(0, l.jsx)("label", {
                        className: "block mt-3",
                        htmlFor: "email",
                        children: "Email Address"
                    }), (0, l.jsx)("input", {
                        className: "block w-full appearance-none h-8 bg-gray-50 text-gray-800 border rounded py-1 px-1 leading-tight focus:outline-none focus:bg-white",
                        id: "email",
                        name: "email",
                        type: "email",
                        autoCapitalize: "none",
                        placeholder: "Email Address...",
                        value: n,
                        onChange(e) {
                            a(e.target.value), o("")
                        },
                        required: !0
                    }), (0, l.jsx)("label", {
                        className: "block mt-3",
                        htmlFor: "password",
                        children: "Password"
                    }), (0, l.jsx)("input", {
                        className: "block w-full appearance-none h-8 bg-gray-50 text-gray-800 border rounded py-1 px-1 leading-tight focus:outline-none focus:bg-white",
                        id: "password",
                        name: "password",
                        type: "password",
                        autoCapitalize: "none",
                        placeholder: "Password...",
                        value: c,
                        onChange(e) {
                            d(e.target.value), o("")
                        },
                        required: !0
                    }), (0, l.jsx)(s.default, {
                        onClick: p,
                        className: "py-1 w-full mt-3",
                        children: t ? "Sign Up" : "Sign In"
                    }), (0, l.jsx)("div", {
                        className: "mt-2 h-8",
                        children: i
                    }), t ? (0, l.jsxs)("div", {
                        className: "mt-3",
                        children: ["Already have an account? ", (0, l.jsx)(P(), {
                            href: "/employer/sign-in",
                            children: "Sign in here"
                        }), "."]
                    }) : (0, l.jsxs)("div", {
                        className: "mt-3",
                        children: ["Don't have an account? ", (0, l.jsx)(P(), {
                            href: "/employer/sign-up",
                            children: "Sign up here"
                        }), "."]
                    }), (0, l.jsxs)("div", {
                        className: "mt-3",
                        children: ["Forgot your password? ", (0, l.jsx)(P(), {
                            href: "/employer/request-password-reset",
                            children: "Reset it here"
                        }), "."]
                    })]
                })
            };
            var $ = Y
        },
        11104: function(e, t, n) {
            var s = n(85893),
                a = n(9008),
                i = n.n(a),
                l = n(41664),
                r = n.n(l),
                o = n(98706),
                c = n(73038),
                d = n(65631),
                u = n.n(d),
                m = n(53447);
            let p = e => {
                let {
                    newsletterName: t,
                    subject: n,
                    date: a,
                    stories: l,
                    emailSignupFormParams: d,
                    footerLinks: p
                } = e, h = "".concat(t, " ").concat(a), x = {
                    sponsor: {
                        emoji: "",
                        title: ""
                    },
                    big: {
                        emoji: "\uD83D\uDCF1",
                        title: "Big Tech & Startups"
                    },
                    future: {
                        emoji: "\uD83D\uDE80",
                        title: "Science & Futuristic Technology"
                    },
                    programming: {
                        emoji: "\uD83D\uDCBB",
                        title: "Programming, Design & Data Science"
                    },
                    miscellaneous: {
                        emoji: "\uD83C\uDF81",
                        title: "Miscellaneous"
                    },
                    quick: {
                        emoji: "⚡",
                        title: "Quick Links"
                    },
                    cryptosponsor: {
                        emoji: "",
                        title: ""
                    },
                    markets: {
                        emoji: "\uD83D\uDCC8",
                        title: "Markets & Business"
                    },
                    innovation: {
                        emoji: "\uD83D\uDE80",
                        title: "Innovation & Launches"
                    },
                    guides: {
                        emoji: "\uD83D\uDCA1",
                        title: "Guides & Resources"
                    },
                    crypto: {
                        emoji: "\uD83E\uDD84",
                        title: "Miscellaneous"
                    },
                    cryptoquick: {
                        emoji: "⚡",
                        title: "Quick Links"
                    }
                }, g = Object.keys(x);
                return (0, s.jsxs)("div", {
                    children: [(0, s.jsxs)(i(), {
                        children: [(0, s.jsx)(c.Z, {}), (0, s.jsx)("title", {
                            children: n
                        }), (0, s.jsx)("meta", {
                            property: "og:title",
                            content: n
                        }), (0, s.jsx)("meta", {
                            name: "description",
                            content: l[1].tldr.slice(0, 150).split(" ").slice(0, -1).join(" ") + "..."
                        }), (0, s.jsx)("meta", {
                            property: "og:description",
                            content: l[1].tldr.slice(0, 150).split(" ").slice(0, -1).join(" ") + "..."
                        })]
                    }), (0, s.jsx)(u(), {}), (0, s.jsx)("div", {
                        className: "flex flex-row min-h-screen justify-center px-4 md:px-16 lg:px-24 max-width-xl",
                        children: (0, s.jsxs)("div", {
                            className: "content-center max-w-xl mt-5",
                            children: [(0, s.jsx)("h1", {
                                className: "text-center text-xl font-bold text-center",
                                children: h
                            }), (0, s.jsx)("h2", {
                                children: n
                            }), g.map(e => (0, s.jsxs)("div", {
                                children: [!e.includes("sponsor") && l.filter(t => t.category == e).length > 0 && (0, s.jsxs)("div", {
                                    children: [(0, s.jsx)("div", {
                                        className: "text-center text-3xl mt-3",
                                        children: x[e].emoji
                                    }), (0, s.jsx)("h6", {
                                        className: "text-center font-bold",
                                        children: x[e].title
                                    })]
                                }, e), l.filter(t => t.category == e).map(e => (0, s.jsxs)("div", {
                                    className: "mt-3",
                                    children: [(0, s.jsx)(r(), {
                                        className: "font-bold",
                                        href: e.url,
                                        children: (0, s.jsx)("h3", {
                                            children: e.title
                                        })
                                    }), (0, s.jsx)("div", {
                                        dangerouslySetInnerHTML: {
                                            __html: e.tldr
                                        }
                                    })]
                                }, e.url))]
                            }, e)), (0, s.jsx)("div", {
                                className: "mt-5",
                                children: (0, s.jsx)(o.Z, {
                                    description: d.description,
                                    newsletter: d.newsletter,
                                    readers: d.readers,
                                    focus: !1
                                })
                            }), (0, s.jsx)(m.Z, {
                                links: p
                            })]
                        })
                    })]
                })
            };
            t.Z = p
        }
    }
]);