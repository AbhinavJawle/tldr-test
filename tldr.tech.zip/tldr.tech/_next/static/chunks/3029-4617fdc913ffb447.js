(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3029], {
        6235: function(e, t, n) {
            "use strict";
            n.d(t, {
                M: function() {
                    return S
                }
            });
            var a, i, o, r = n(67294),
                s = n(45697),
                m = function() {
                    return (m = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                        return e
                    }).apply(this, arguments)
                },
                u = {
                    onActivate: s.func,
                    onAddUndo: s.func,
                    onBeforeAddUndo: s.func,
                    onBeforeExecCommand: s.func,
                    onBeforeGetContent: s.func,
                    onBeforeRenderUI: s.func,
                    onBeforeSetContent: s.func,
                    onBeforePaste: s.func,
                    onBlur: s.func,
                    onChange: s.func,
                    onClearUndos: s.func,
                    onClick: s.func,
                    onContextMenu: s.func,
                    onCommentChange: s.func,
                    onCopy: s.func,
                    onCut: s.func,
                    onDblclick: s.func,
                    onDeactivate: s.func,
                    onDirty: s.func,
                    onDrag: s.func,
                    onDragDrop: s.func,
                    onDragEnd: s.func,
                    onDragGesture: s.func,
                    onDragOver: s.func,
                    onDrop: s.func,
                    onExecCommand: s.func,
                    onFocus: s.func,
                    onFocusIn: s.func,
                    onFocusOut: s.func,
                    onGetContent: s.func,
                    onHide: s.func,
                    onInit: s.func,
                    onKeyDown: s.func,
                    onKeyPress: s.func,
                    onKeyUp: s.func,
                    onLoadContent: s.func,
                    onMouseDown: s.func,
                    onMouseEnter: s.func,
                    onMouseLeave: s.func,
                    onMouseMove: s.func,
                    onMouseOut: s.func,
                    onMouseOver: s.func,
                    onMouseUp: s.func,
                    onNodeChange: s.func,
                    onObjectResizeStart: s.func,
                    onObjectResized: s.func,
                    onObjectSelected: s.func,
                    onPaste: s.func,
                    onPostProcess: s.func,
                    onPostRender: s.func,
                    onPreProcess: s.func,
                    onProgressState: s.func,
                    onRedo: s.func,
                    onRemove: s.func,
                    onReset: s.func,
                    onSaveContent: s.func,
                    onSelectionChange: s.func,
                    onSetAttrib: s.func,
                    onSetContent: s.func,
                    onShow: s.func,
                    onSubmit: s.func,
                    onUndo: s.func,
                    onVisualAid: s.func,
                    onSkinLoadError: s.func,
                    onThemeLoadError: s.func,
                    onModelLoadError: s.func,
                    onPluginLoadError: s.func,
                    onIconsLoadError: s.func,
                    onLanguageLoadError: s.func
                },
                l = m({
                    apiKey: s.string,
                    id: s.string,
                    inline: s.bool,
                    init: s.object,
                    initialValue: s.string,
                    onEditorChange: s.func,
                    value: s.string,
                    tagName: s.string,
                    cloudChannel: s.string,
                    plugins: s.oneOfType([s.string, s.array]),
                    toolbar: s.oneOfType([s.string, s.array]),
                    disabled: s.bool,
                    textareaName: s.string,
                    tinymceScriptSrc: s.string,
                    rollback: s.oneOfType([s.number, s.oneOf([!1])]),
                    scriptLoading: s.shape({
                        async: s.bool,
                        defer: s.bool,
                        delay: s.number
                    })
                }, u),
                c = function(e) {
                    return "function" == typeof e
                },
                f = function(e) {
                    return e in u
                },
                d = function(e) {
                    return e.substr(2)
                },
                g = function(e, t, n, a, i, o, r) {
                    var s = Object.keys(i).filter(f),
                        m = Object.keys(o).filter(f),
                        u = s.filter(function(e) {
                            return void 0 === o[e]
                        }),
                        l = m.filter(function(e) {
                            return void 0 === i[e]
                        });
                    u.forEach(function(e) {
                        var t = d(e),
                            a = r[t];
                        n(t, a), delete r[t]
                    }), l.forEach(function(n) {
                        var i = a(e, n),
                            o = d(n);
                        r[o] = i, t(o, i)
                    })
                },
                p = 0,
                b = function(e) {
                    var t = Date.now();
                    return e + "_" + Math.floor(1e9 * Math.random()) + ++p + String(t)
                },
                h = function(e) {
                    return null !== e && ("textarea" === e.tagName.toLowerCase() || "input" === e.tagName.toLowerCase())
                },
                T = function(e) {
                    return void 0 === e || "" === e ? [] : Array.isArray(e) ? e : e.split(" ")
                },
                N = function(e) {
                    if (!("isConnected" in Node.prototype)) {
                        for (var t = e, n = e.parentNode; null != n;) n = (t = n).parentNode;
                        return t === e.ownerDocument
                    }
                    return e.isConnected
                },
                v = function(e, t) {
                    void 0 !== e && (null != e.mode && "object" == typeof e.mode && "function" == typeof e.mode.set ? e.mode.set(t) : e.setMode(t))
                },
                C = function() {
                    return {
                        listeners: [],
                        scriptId: b("tiny-script"),
                        scriptLoading: !1,
                        scriptLoaded: !1
                    }
                },
                O = (a = C(), i = function(e, t, n, a, i, o) {
                    var r = t.createElement("script");
                    r.referrerPolicy = "origin", r.type = "application/javascript", r.id = e, r.src = n, r.async = a, r.defer = i;
                    var s = function() {
                        r.removeEventListener("load", s), o()
                    };
                    r.addEventListener("load", s), t.head && t.head.appendChild(r)
                }, {
                    load: function(e, t, n, o, r, s) {
                        var m = function() {
                            return i(a.scriptId, e, t, n, o, function() {
                                a.listeners.forEach(function(e) {
                                    return e()
                                }), a.scriptLoaded = !0
                            })
                        };
                        a.scriptLoaded ? s() : (a.listeners.push(s), a.scriptLoading || (a.scriptLoading = !0, r > 0 ? setTimeout(m, r) : m()))
                    },
                    reinitialize: function() {
                        a = C()
                    }
                }),
                z = function(e) {
                    return e && e.tinymce ? e.tinymce : null
                },
                y = (o = function(e, t) {
                    return (o = Object.setPrototypeOf || ({
                        __proto__: []
                    }) instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n])
                    })(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function n() {
                        this.constructor = e
                    }
                    o(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, new n)
                }),
                A = function() {
                    return (A = Object.assign || function(e) {
                        for (var t, n = 1, a = arguments.length; n < a; n++)
                            for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                        return e
                    }).apply(this, arguments)
                },
                S = function(e) {
                    function t(t) {
                        var n, a, i, o = this;
                        return (o = e.call(this, t) || this).rollbackTimer = void 0, o.valueCursor = void 0, o.rollbackChange = function() {
                            var e = o.editor,
                                t = o.props.value;
                            e && t && t !== o.currentContent && e.undoManager.ignore(function() {
                                if (e.setContent(t), o.valueCursor && (!o.inline || e.hasFocus())) try {
                                    e.selection.moveToBookmark(o.valueCursor)
                                } catch (n) {}
                            }), o.rollbackTimer = void 0
                        }, o.handleBeforeInput = function(e) {
                            if (void 0 !== o.props.value && o.props.value === o.currentContent && o.editor && (!o.inline || o.editor.hasFocus())) try {
                                o.valueCursor = o.editor.selection.getBookmark(3)
                            } catch (t) {}
                        }, o.handleBeforeInputSpecial = function(e) {
                            ("Enter" === e.key || "Backspace" === e.key || "Delete" === e.key) && o.handleBeforeInput(e)
                        }, o.handleEditorChange = function(e) {
                            var t = o.editor;
                            if (t && t.initialized) {
                                var n = t.getContent();
                                void 0 === o.props.value || o.props.value === n || !1 === o.props.rollback || o.rollbackTimer || (o.rollbackTimer = window.setTimeout(o.rollbackChange, "number" == typeof o.props.rollback ? o.props.rollback : 200)), n !== o.currentContent && (o.currentContent = n, c(o.props.onEditorChange) && o.props.onEditorChange(n, t))
                            }
                        }, o.handleEditorChangeSpecial = function(e) {
                            ("Backspace" === e.key || "Delete" === e.key) && o.handleEditorChange(e)
                        }, o.initialise = function(e) {
                            void 0 === e && (e = 0);
                            var t, n, a, i, r, s = o.elementRef.current;
                            if (s) {
                                if (!N(s)) {
                                    if (0 === e) setTimeout(function() {
                                        return o.initialise(1)
                                    }, 1);
                                    else if (e < 100) setTimeout(function() {
                                        return o.initialise(e + 1)
                                    }, 100);
                                    else throw Error("tinymce can only be initialised when in a document");
                                    return
                                }
                                var m = z(o.view);
                                if (!m) throw Error("tinymce should have been loaded into global scope");
                                var u = A(A({}, o.props.init), {
                                    selector: void 0,
                                    target: s,
                                    readonly: o.props.disabled,
                                    inline: o.inline,
                                    plugins: (t = null === (a = o.props.init) || void 0 === a ? void 0 : a.plugins, n = o.props.plugins, T(t).concat(T(n))),
                                    toolbar: null !== (i = o.props.toolbar) && void 0 !== i ? i : null === (r = o.props.init) || void 0 === r ? void 0 : r.toolbar,
                                    setup: function(e) {
                                        o.editor = e, o.bindHandlers({}), o.inline && !h(s) && e.once("PostRender", function(t) {
                                            e.setContent(o.getInitialValue(), {
                                                no_events: !0
                                            })
                                        }), o.props.init && c(o.props.init.setup) && o.props.init.setup(e)
                                    },
                                    init_instance_callback: function(e) {
                                        var t, n, a = o.getInitialValue();
                                        o.currentContent = null !== (t = o.currentContent) && void 0 !== t ? t : e.getContent(), o.currentContent !== a && (o.currentContent = a, e.setContent(a), e.undoManager.clear(), e.undoManager.add(), e.setDirty(!1));
                                        var i = null !== (n = o.props.disabled) && void 0 !== n && n;
                                        v(o.editor, i ? "readonly" : "design"), o.props.init && c(o.props.init.init_instance_callback) && o.props.init.init_instance_callback(e)
                                    }
                                });
                                o.inline || (s.style.visibility = ""), h(s) && (s.value = o.getInitialValue()), m.init(u)
                            }
                        }, o.id = o.props.id || b("tiny-react"), o.elementRef = r.createRef(), o.inline = null !== (i = null !== (n = o.props.inline) && void 0 !== n ? n : null === (a = o.props.init) || void 0 === a ? void 0 : a.inline) && void 0 !== i && i, o.boundHandlers = {}, o
                    }
                    return y(t, e), Object.defineProperty(t.prototype, "view", {
                        get: function() {
                            var e, t;
                            return null !== (t = null === (e = this.elementRef.current) || void 0 === e ? void 0 : e.ownerDocument.defaultView) && void 0 !== t ? t : window
                        },
                        enumerable: !1,
                        configurable: !0
                    }), t.prototype.componentDidUpdate = function(e) {
                        var t, n, a = this;
                        if (this.rollbackTimer && (clearTimeout(this.rollbackTimer), this.rollbackTimer = void 0), this.editor && (this.bindHandlers(e), this.editor.initialized)) {
                            if (this.currentContent = null !== (t = this.currentContent) && void 0 !== t ? t : this.editor.getContent(), "string" == typeof this.props.initialValue && this.props.initialValue !== e.initialValue) this.editor.setContent(this.props.initialValue), this.editor.undoManager.clear(), this.editor.undoManager.add(), this.editor.setDirty(!1);
                            else if ("string" == typeof this.props.value && this.props.value !== this.currentContent) {
                                var i = this.editor;
                                i.undoManager.transact(function() {
                                    if (!a.inline || i.hasFocus()) try {
                                        t = i.selection.getBookmark(3)
                                    } catch (e) {}
                                    var t, n = a.valueCursor;
                                    if (i.setContent(a.props.value), !a.inline || i.hasFocus())
                                        for (var o = 0, r = [t, n]; o < r.length; o++) {
                                            var s = r[o];
                                            if (s) try {
                                                i.selection.moveToBookmark(s), a.valueCursor = s;
                                                break
                                            } catch (m) {}
                                        }
                                })
                            }
                            if (this.props.disabled !== e.disabled) {
                                var o = null !== (n = this.props.disabled) && void 0 !== n && n;
                                v(this.editor, o ? "readonly" : "design")
                            }
                        }
                    }, t.prototype.componentDidMount = function() {
                        var e, t, n, a, i, o;
                        null !== z(this.view) ? this.initialise() : this.elementRef.current && this.elementRef.current.ownerDocument && O.load(this.elementRef.current.ownerDocument, this.getScriptSrc(), null !== (t = null === (e = this.props.scriptLoading) || void 0 === e ? void 0 : e.async) && void 0 !== t && t, null !== (a = null === (n = this.props.scriptLoading) || void 0 === n ? void 0 : n.defer) && void 0 !== a && a, null !== (o = null === (i = this.props.scriptLoading) || void 0 === i ? void 0 : i.delay) && void 0 !== o ? o : 0, this.initialise)
                    }, t.prototype.componentWillUnmount = function() {
                        var e = this,
                            t = this.editor;
                        t && (t.off(this.changeEvents(), this.handleEditorChange), t.off(this.beforeInputEvent(), this.handleBeforeInput), t.off("keypress", this.handleEditorChangeSpecial), t.off("keydown", this.handleBeforeInputSpecial), t.off("NewBlock", this.handleEditorChange), Object.keys(this.boundHandlers).forEach(function(n) {
                            t.off(n, e.boundHandlers[n])
                        }), this.boundHandlers = {}, t.remove(), this.editor = void 0)
                    }, t.prototype.render = function() {
                        return this.inline ? this.renderInline() : this.renderIframe()
                    }, t.prototype.changeEvents = function() {
                        var e, t, n;
                        return (null === (n = null === (t = null === (e = z(this.view)) || void 0 === e ? void 0 : e.Env) || void 0 === t ? void 0 : t.browser) || void 0 === n ? void 0 : n.isIE()) ? "change keyup compositionend setcontent CommentChange" : "change input compositionend setcontent CommentChange"
                    }, t.prototype.beforeInputEvent = function() {
                        return window.InputEvent && "function" == typeof InputEvent.prototype.getTargetRanges ? "beforeinput SelectionChange" : "SelectionChange"
                    }, t.prototype.renderInline = function() {
                        var e = this.props.tagName;
                        return r.createElement(void 0 === e ? "div" : e, {
                            ref: this.elementRef,
                            id: this.id
                        })
                    }, t.prototype.renderIframe = function() {
                        return r.createElement("textarea", {
                            ref: this.elementRef,
                            style: {
                                visibility: "hidden"
                            },
                            name: this.props.textareaName,
                            id: this.id
                        })
                    }, t.prototype.getScriptSrc = function() {
                        if ("string" == typeof this.props.tinymceScriptSrc) return this.props.tinymceScriptSrc;
                        var e = this.props.cloudChannel,
                            t = this.props.apiKey ? this.props.apiKey : "no-api-key";
                        return "https://cdn.tiny.cloud/1/".concat(t, "/tinymce/").concat(e, "/tinymce.min.js")
                    }, t.prototype.getInitialValue = function() {
                        return "string" == typeof this.props.initialValue ? this.props.initialValue : "string" == typeof this.props.value ? this.props.value : ""
                    }, t.prototype.bindHandlers = function(e) {
                        var t = this;
                        if (void 0 !== this.editor) {
                            n = this.editor, a = this.props, i = this.boundHandlers, g(function(e) {
                                return t.props[e]
                            }, n.on.bind(n), n.off.bind(n), function(e, t) {
                                return function(a) {
                                    var i;
                                    return null === (i = e(t)) || void 0 === i ? void 0 : i(a, n)
                                }
                            }, e, a, i);
                            var n, a, i, o = function(e) {
                                    return void 0 !== e.onEditorChange || void 0 !== e.value
                                },
                                r = o(e),
                                s = o(this.props);
                            !r && s ? (this.editor.on(this.changeEvents(), this.handleEditorChange), this.editor.on(this.beforeInputEvent(), this.handleBeforeInput), this.editor.on("keydown", this.handleBeforeInputSpecial), this.editor.on("keyup", this.handleEditorChangeSpecial), this.editor.on("NewBlock", this.handleEditorChange)) : r && !s && (this.editor.off(this.changeEvents(), this.handleEditorChange), this.editor.off(this.beforeInputEvent(), this.handleBeforeInput), this.editor.off("keydown", this.handleBeforeInputSpecial), this.editor.off("keyup", this.handleEditorChangeSpecial), this.editor.off("NewBlock", this.handleEditorChange))
                        }
                    }, t.propTypes = l, t.defaultProps = {
                        cloudChannel: "6"
                    }, t
                }(r.Component)
        },
        98090: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, {
                City: function() {
                    return c
                },
                Country: function() {
                    return s
                },
                State: function() {
                    return u
                }
            });
            var a = JSON.parse('[{"name":"Afghanistan","isoCode":"AF","flag":"\uD83C\uDDE6\uD83C\uDDEB","phonecode":"93","currency":"AFN","latitude":"33.00000000","longitude":"65.00000000","timezones":[{"zoneName":"Asia/Kabul","gmtOffset":16200,"gmtOffsetName":"UTC+04:30","abbreviation":"AFT","tzName":"Afghanistan Time"}]},{"name":"Aland Islands","isoCode":"AX","flag":"\uD83C\uDDE6\uD83C\uDDFD","phonecode":"+358-18","currency":"EUR","latitude":"60.11666700","longitude":"19.90000000","timezones":[{"zoneName":"Europe/Mariehamn","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Albania","isoCode":"AL","flag":"\uD83C\uDDE6\uD83C\uDDF1","phonecode":"355","currency":"ALL","latitude":"41.00000000","longitude":"20.00000000","timezones":[{"zoneName":"Europe/Tirane","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Algeria","isoCode":"DZ","flag":"\uD83C\uDDE9\uD83C\uDDFF","phonecode":"213","currency":"DZD","latitude":"28.00000000","longitude":"3.00000000","timezones":[{"zoneName":"Africa/Algiers","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"American Samoa","isoCode":"AS","flag":"\uD83C\uDDE6\uD83C\uDDF8","phonecode":"+1-684","currency":"USD","latitude":"-14.33333333","longitude":"-170.00000000","timezones":[{"zoneName":"Pacific/Pago_Pago","gmtOffset":-39600,"gmtOffsetName":"UTC-11:00","abbreviation":"SST","tzName":"Samoa Standard Time"}]},{"name":"Andorra","isoCode":"AD","flag":"\uD83C\uDDE6\uD83C\uDDE9","phonecode":"376","currency":"EUR","latitude":"42.50000000","longitude":"1.50000000","timezones":[{"zoneName":"Europe/Andorra","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Angola","isoCode":"AO","flag":"\uD83C\uDDE6\uD83C\uDDF4","phonecode":"244","currency":"AOA","latitude":"-12.50000000","longitude":"18.50000000","timezones":[{"zoneName":"Africa/Luanda","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"WAT","tzName":"West Africa Time"}]},{"name":"Anguilla","isoCode":"AI","flag":"\uD83C\uDDE6\uD83C\uDDEE","phonecode":"+1-264","currency":"XCD","latitude":"18.25000000","longitude":"-63.16666666","timezones":[{"zoneName":"America/Anguilla","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Antarctica","isoCode":"AQ","flag":"\uD83C\uDDE6\uD83C\uDDF6","phonecode":"672","currency":"AAD","latitude":"-74.65000000","longitude":"4.48000000","timezones":[{"zoneName":"Antarctica/Casey","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"AWST","tzName":"Australian Western Standard Time"},{"zoneName":"Antarctica/Davis","gmtOffset":25200,"gmtOffsetName":"UTC+07:00","abbreviation":"DAVT","tzName":"Davis Time"},{"zoneName":"Antarctica/DumontDUrville","gmtOffset":36000,"gmtOffsetName":"UTC+10:00","abbreviation":"DDUT","tzName":"Dumont d\'Urville Time"},{"zoneName":"Antarctica/Mawson","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"MAWT","tzName":"Mawson Station Time"},{"zoneName":"Antarctica/McMurdo","gmtOffset":46800,"gmtOffsetName":"UTC+13:00","abbreviation":"NZDT","tzName":"New Zealand Daylight Time"},{"zoneName":"Antarctica/Palmer","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"CLST","tzName":"Chile Summer Time"},{"zoneName":"Antarctica/Rothera","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"ROTT","tzName":"Rothera Research Station Time"},{"zoneName":"Antarctica/Syowa","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"SYOT","tzName":"Showa Station Time"},{"zoneName":"Antarctica/Troll","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"},{"zoneName":"Antarctica/Vostok","gmtOffset":21600,"gmtOffsetName":"UTC+06:00","abbreviation":"VOST","tzName":"Vostok Station Time"}]},{"name":"Antigua And Barbuda","isoCode":"AG","flag":"\uD83C\uDDE6\uD83C\uDDEC","phonecode":"+1-268","currency":"XCD","latitude":"17.05000000","longitude":"-61.80000000","timezones":[{"zoneName":"America/Antigua","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Argentina","isoCode":"AR","flag":"\uD83C\uDDE6\uD83C\uDDF7","phonecode":"54","currency":"ARS","latitude":"-34.00000000","longitude":"-64.00000000","timezones":[{"zoneName":"America/Argentina/Buenos_Aires","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"ART","tzName":"Argentina Time"},{"zoneName":"America/Argentina/Catamarca","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"ART","tzName":"Argentina Time"},{"zoneName":"America/Argentina/Cordoba","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"ART","tzName":"Argentina Time"},{"zoneName":"America/Argentina/Jujuy","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"ART","tzName":"Argentina Time"},{"zoneName":"America/Argentina/La_Rioja","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"ART","tzName":"Argentina Time"},{"zoneName":"America/Argentina/Mendoza","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"ART","tzName":"Argentina Time"},{"zoneName":"America/Argentina/Rio_Gallegos","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"ART","tzName":"Argentina Time"},{"zoneName":"America/Argentina/Salta","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"ART","tzName":"Argentina Time"},{"zoneName":"America/Argentina/San_Juan","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"ART","tzName":"Argentina Time"},{"zoneName":"America/Argentina/San_Luis","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"ART","tzName":"Argentina Time"},{"zoneName":"America/Argentina/Tucuman","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"ART","tzName":"Argentina Time"},{"zoneName":"America/Argentina/Ushuaia","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"ART","tzName":"Argentina Time"}]},{"name":"Armenia","isoCode":"AM","flag":"\uD83C\uDDE6\uD83C\uDDF2","phonecode":"374","currency":"AMD","latitude":"40.00000000","longitude":"45.00000000","timezones":[{"zoneName":"Asia/Yerevan","gmtOffset":14400,"gmtOffsetName":"UTC+04:00","abbreviation":"AMT","tzName":"Armenia Time"}]},{"name":"Aruba","isoCode":"AW","flag":"\uD83C\uDDE6\uD83C\uDDFC","phonecode":"297","currency":"AWG","latitude":"12.50000000","longitude":"-69.96666666","timezones":[{"zoneName":"America/Aruba","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Australia","isoCode":"AU","flag":"\uD83C\uDDE6\uD83C\uDDFA","phonecode":"61","currency":"AUD","latitude":"-27.00000000","longitude":"133.00000000","timezones":[{"zoneName":"Antarctica/Macquarie","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"MIST","tzName":"Macquarie Island Station Time"},{"zoneName":"Australia/Adelaide","gmtOffset":37800,"gmtOffsetName":"UTC+10:30","abbreviation":"ACDT","tzName":"Australian Central Daylight Saving Time"},{"zoneName":"Australia/Brisbane","gmtOffset":36000,"gmtOffsetName":"UTC+10:00","abbreviation":"AEST","tzName":"Australian Eastern Standard Time"},{"zoneName":"Australia/Broken_Hill","gmtOffset":37800,"gmtOffsetName":"UTC+10:30","abbreviation":"ACDT","tzName":"Australian Central Daylight Saving Time"},{"zoneName":"Australia/Currie","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"AEDT","tzName":"Australian Eastern Daylight Saving Time"},{"zoneName":"Australia/Darwin","gmtOffset":34200,"gmtOffsetName":"UTC+09:30","abbreviation":"ACST","tzName":"Australian Central Standard Time"},{"zoneName":"Australia/Eucla","gmtOffset":31500,"gmtOffsetName":"UTC+08:45","abbreviation":"ACWST","tzName":"Australian Central Western Standard Time (Unofficial)"},{"zoneName":"Australia/Hobart","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"AEDT","tzName":"Australian Eastern Daylight Saving Time"},{"zoneName":"Australia/Lindeman","gmtOffset":36000,"gmtOffsetName":"UTC+10:00","abbreviation":"AEST","tzName":"Australian Eastern Standard Time"},{"zoneName":"Australia/Lord_Howe","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"LHST","tzName":"Lord Howe Summer Time"},{"zoneName":"Australia/Melbourne","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"AEDT","tzName":"Australian Eastern Daylight Saving Time"},{"zoneName":"Australia/Perth","gmtOffset":28800,"gmtOffsetName":"UTC+08:00","abbreviation":"AWST","tzName":"Australian Western Standard Time"},{"zoneName":"Australia/Sydney","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"AEDT","tzName":"Australian Eastern Daylight Saving Time"}]},{"name":"Austria","isoCode":"AT","flag":"\uD83C\uDDE6\uD83C\uDDF9","phonecode":"43","currency":"EUR","latitude":"47.33333333","longitude":"13.33333333","timezones":[{"zoneName":"Europe/Vienna","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Azerbaijan","isoCode":"AZ","flag":"\uD83C\uDDE6\uD83C\uDDFF","phonecode":"994","currency":"AZN","latitude":"40.50000000","longitude":"47.50000000","timezones":[{"zoneName":"Asia/Baku","gmtOffset":14400,"gmtOffsetName":"UTC+04:00","abbreviation":"AZT","tzName":"Azerbaijan Time"}]},{"name":"The Bahamas","isoCode":"BS","flag":"\uD83C\uDDE7\uD83C\uDDF8","phonecode":"+1-242","currency":"BSD","latitude":"24.25000000","longitude":"-76.00000000","timezones":[{"zoneName":"America/Nassau","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America)"}]},{"name":"Bahrain","isoCode":"BH","flag":"\uD83C\uDDE7\uD83C\uDDED","phonecode":"973","currency":"BHD","latitude":"26.00000000","longitude":"50.55000000","timezones":[{"zoneName":"Asia/Bahrain","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"AST","tzName":"Arabia Standard Time"}]},{"name":"Bangladesh","isoCode":"BD","flag":"\uD83C\uDDE7\uD83C\uDDE9","phonecode":"880","currency":"BDT","latitude":"24.00000000","longitude":"90.00000000","timezones":[{"zoneName":"Asia/Dhaka","gmtOffset":21600,"gmtOffsetName":"UTC+06:00","abbreviation":"BDT","tzName":"Bangladesh Standard Time"}]},{"name":"Barbados","isoCode":"BB","flag":"\uD83C\uDDE7\uD83C\uDDE7","phonecode":"+1-246","currency":"BBD","latitude":"13.16666666","longitude":"-59.53333333","timezones":[{"zoneName":"America/Barbados","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Belarus","isoCode":"BY","flag":"\uD83C\uDDE7\uD83C\uDDFE","phonecode":"375","currency":"BYN","latitude":"53.00000000","longitude":"28.00000000","timezones":[{"zoneName":"Europe/Minsk","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"MSK","tzName":"Moscow Time"}]},{"name":"Belgium","isoCode":"BE","flag":"\uD83C\uDDE7\uD83C\uDDEA","phonecode":"32","currency":"EUR","latitude":"50.83333333","longitude":"4.00000000","timezones":[{"zoneName":"Europe/Brussels","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Belize","isoCode":"BZ","flag":"\uD83C\uDDE7\uD83C\uDDFF","phonecode":"501","currency":"BZD","latitude":"17.25000000","longitude":"-88.75000000","timezones":[{"zoneName":"America/Belize","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America)"}]},{"name":"Benin","isoCode":"BJ","flag":"\uD83C\uDDE7\uD83C\uDDEF","phonecode":"229","currency":"XOF","latitude":"9.50000000","longitude":"2.25000000","timezones":[{"zoneName":"Africa/Porto-Novo","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"WAT","tzName":"West Africa Time"}]},{"name":"Bermuda","isoCode":"BM","flag":"\uD83C\uDDE7\uD83C\uDDF2","phonecode":"+1-441","currency":"BMD","latitude":"32.33333333","longitude":"-64.75000000","timezones":[{"zoneName":"Atlantic/Bermuda","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Bhutan","isoCode":"BT","flag":"\uD83C\uDDE7\uD83C\uDDF9","phonecode":"975","currency":"BTN","latitude":"27.50000000","longitude":"90.50000000","timezones":[{"zoneName":"Asia/Thimphu","gmtOffset":21600,"gmtOffsetName":"UTC+06:00","abbreviation":"BTT","tzName":"Bhutan Time"}]},{"name":"Bolivia","isoCode":"BO","flag":"\uD83C\uDDE7\uD83C\uDDF4","phonecode":"591","currency":"BOB","latitude":"-17.00000000","longitude":"-65.00000000","timezones":[{"zoneName":"America/La_Paz","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"BOT","tzName":"Bolivia Time"}]},{"name":"Bosnia and Herzegovina","isoCode":"BA","flag":"\uD83C\uDDE7\uD83C\uDDE6","phonecode":"387","currency":"BAM","latitude":"44.00000000","longitude":"18.00000000","timezones":[{"zoneName":"Europe/Sarajevo","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Botswana","isoCode":"BW","flag":"\uD83C\uDDE7\uD83C\uDDFC","phonecode":"267","currency":"BWP","latitude":"-22.00000000","longitude":"24.00000000","timezones":[{"zoneName":"Africa/Gaborone","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"CAT","tzName":"Central Africa Time"}]},{"name":"Bouvet Island","isoCode":"BV","flag":"\uD83C\uDDE7\uD83C\uDDFB","phonecode":"0055","currency":"NOK","latitude":"-54.43333333","longitude":"3.40000000","timezones":[{"zoneName":"Europe/Oslo","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Brazil","isoCode":"BR","flag":"\uD83C\uDDE7\uD83C\uDDF7","phonecode":"55","currency":"BRL","latitude":"-10.00000000","longitude":"-55.00000000","timezones":[{"zoneName":"America/Araguaina","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"BRT","tzName":"Bras\xedlia Time"},{"zoneName":"America/Bahia","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"BRT","tzName":"Bras\xedlia Time"},{"zoneName":"America/Belem","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"BRT","tzName":"Bras\xedlia Time"},{"zoneName":"America/Boa_Vista","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AMT","tzName":"Amazon Time (Brazil)[3"},{"zoneName":"America/Campo_Grande","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AMT","tzName":"Amazon Time (Brazil)[3"},{"zoneName":"America/Cuiaba","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"BRT","tzName":"Brasilia Time"},{"zoneName":"America/Eirunepe","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"ACT","tzName":"Acre Time"},{"zoneName":"America/Fortaleza","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"BRT","tzName":"Bras\xedlia Time"},{"zoneName":"America/Maceio","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"BRT","tzName":"Bras\xedlia Time"},{"zoneName":"America/Manaus","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AMT","tzName":"Amazon Time (Brazil)"},{"zoneName":"America/Noronha","gmtOffset":-7200,"gmtOffsetName":"UTC-02:00","abbreviation":"FNT","tzName":"Fernando de Noronha Time"},{"zoneName":"America/Porto_Velho","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AMT","tzName":"Amazon Time (Brazil)[3"},{"zoneName":"America/Recife","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"BRT","tzName":"Bras\xedlia Time"},{"zoneName":"America/Rio_Branco","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"ACT","tzName":"Acre Time"},{"zoneName":"America/Santarem","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"BRT","tzName":"Bras\xedlia Time"},{"zoneName":"America/Sao_Paulo","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"BRT","tzName":"Bras\xedlia Time"}]},{"name":"British Indian Ocean Territory","isoCode":"IO","flag":"\uD83C\uDDEE\uD83C\uDDF4","phonecode":"246","currency":"USD","latitude":"-6.00000000","longitude":"71.50000000","timezones":[{"zoneName":"Indian/Chagos","gmtOffset":21600,"gmtOffsetName":"UTC+06:00","abbreviation":"IOT","tzName":"Indian Ocean Time"}]},{"name":"Brunei","isoCode":"BN","flag":"\uD83C\uDDE7\uD83C\uDDF3","phonecode":"673","currency":"BND","latitude":"4.50000000","longitude":"114.66666666","timezones":[{"zoneName":"Asia/Brunei","gmtOffset":28800,"gmtOffsetName":"UTC+08:00","abbreviation":"BNT","tzName":"Brunei Darussalam Time"}]},{"name":"Bulgaria","isoCode":"BG","flag":"\uD83C\uDDE7\uD83C\uDDEC","phonecode":"359","currency":"BGN","latitude":"43.00000000","longitude":"25.00000000","timezones":[{"zoneName":"Europe/Sofia","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Burkina Faso","isoCode":"BF","flag":"\uD83C\uDDE7\uD83C\uDDEB","phonecode":"226","currency":"XOF","latitude":"13.00000000","longitude":"-2.00000000","timezones":[{"zoneName":"Africa/Ouagadougou","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Burundi","isoCode":"BI","flag":"\uD83C\uDDE7\uD83C\uDDEE","phonecode":"257","currency":"BIF","latitude":"-3.50000000","longitude":"30.00000000","timezones":[{"zoneName":"Africa/Bujumbura","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"CAT","tzName":"Central Africa Time"}]},{"name":"Cambodia","isoCode":"KH","flag":"\uD83C\uDDF0\uD83C\uDDED","phonecode":"855","currency":"KHR","latitude":"13.00000000","longitude":"105.00000000","timezones":[{"zoneName":"Asia/Phnom_Penh","gmtOffset":25200,"gmtOffsetName":"UTC+07:00","abbreviation":"ICT","tzName":"Indochina Time"}]},{"name":"Cameroon","isoCode":"CM","flag":"\uD83C\uDDE8\uD83C\uDDF2","phonecode":"237","currency":"XAF","latitude":"6.00000000","longitude":"12.00000000","timezones":[{"zoneName":"Africa/Douala","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"WAT","tzName":"West Africa Time"}]},{"name":"Canada","isoCode":"CA","flag":"\uD83C\uDDE8\uD83C\uDDE6","phonecode":"1","currency":"CAD","latitude":"60.00000000","longitude":"-95.00000000","timezones":[{"zoneName":"America/Atikokan","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America)"},{"zoneName":"America/Blanc-Sablon","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"},{"zoneName":"America/Cambridge_Bay","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America)"},{"zoneName":"America/Creston","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America)"},{"zoneName":"America/Dawson","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America)"},{"zoneName":"America/Dawson_Creek","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America)"},{"zoneName":"America/Edmonton","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America)"},{"zoneName":"America/Fort_Nelson","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America)"},{"zoneName":"America/Glace_Bay","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"},{"zoneName":"America/Goose_Bay","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"},{"zoneName":"America/Halifax","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"},{"zoneName":"America/Inuvik","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America"},{"zoneName":"America/Iqaluit","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Moncton","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"},{"zoneName":"America/Nipigon","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Pangnirtung","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Rainy_River","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Rankin_Inlet","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Regina","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Resolute","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/St_Johns","gmtOffset":-12600,"gmtOffsetName":"UTC-03:30","abbreviation":"NST","tzName":"Newfoundland Standard Time"},{"zoneName":"America/Swift_Current","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Thunder_Bay","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Toronto","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Vancouver","gmtOffset":-28800,"gmtOffsetName":"UTC-08:00","abbreviation":"PST","tzName":"Pacific Standard Time (North America"},{"zoneName":"America/Whitehorse","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America"},{"zoneName":"America/Winnipeg","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Yellowknife","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America"}]},{"name":"Cape Verde","isoCode":"CV","flag":"\uD83C\uDDE8\uD83C\uDDFB","phonecode":"238","currency":"CVE","latitude":"16.00000000","longitude":"-24.00000000","timezones":[{"zoneName":"Atlantic/Cape_Verde","gmtOffset":-3600,"gmtOffsetName":"UTC-01:00","abbreviation":"CVT","tzName":"Cape Verde Time"}]},{"name":"Cayman Islands","isoCode":"KY","flag":"\uD83C\uDDF0\uD83C\uDDFE","phonecode":"+1-345","currency":"KYD","latitude":"19.50000000","longitude":"-80.50000000","timezones":[{"zoneName":"America/Cayman","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"}]},{"name":"Central African Republic","isoCode":"CF","flag":"\uD83C\uDDE8\uD83C\uDDEB","phonecode":"236","currency":"XAF","latitude":"7.00000000","longitude":"21.00000000","timezones":[{"zoneName":"Africa/Bangui","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"WAT","tzName":"West Africa Time"}]},{"name":"Chad","isoCode":"TD","flag":"\uD83C\uDDF9\uD83C\uDDE9","phonecode":"235","currency":"XAF","latitude":"15.00000000","longitude":"19.00000000","timezones":[{"zoneName":"Africa/Ndjamena","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"WAT","tzName":"West Africa Time"}]},{"name":"Chile","isoCode":"CL","flag":"\uD83C\uDDE8\uD83C\uDDF1","phonecode":"56","currency":"CLP","latitude":"-30.00000000","longitude":"-71.00000000","timezones":[{"zoneName":"America/Punta_Arenas","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"CLST","tzName":"Chile Summer Time"},{"zoneName":"America/Santiago","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"CLST","tzName":"Chile Summer Time"},{"zoneName":"Pacific/Easter","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EASST","tzName":"Easter Island Summer Time"}]},{"name":"China","isoCode":"CN","flag":"\uD83C\uDDE8\uD83C\uDDF3","phonecode":"86","currency":"CNY","latitude":"35.00000000","longitude":"105.00000000","timezones":[{"zoneName":"Asia/Shanghai","gmtOffset":28800,"gmtOffsetName":"UTC+08:00","abbreviation":"CST","tzName":"China Standard Time"},{"zoneName":"Asia/Urumqi","gmtOffset":21600,"gmtOffsetName":"UTC+06:00","abbreviation":"XJT","tzName":"China Standard Time"}]},{"name":"Christmas Island","isoCode":"CX","flag":"\uD83C\uDDE8\uD83C\uDDFD","phonecode":"61","currency":"AUD","latitude":"-10.50000000","longitude":"105.66666666","timezones":[{"zoneName":"Indian/Christmas","gmtOffset":25200,"gmtOffsetName":"UTC+07:00","abbreviation":"CXT","tzName":"Christmas Island Time"}]},{"name":"Cocos (Keeling) Islands","isoCode":"CC","flag":"\uD83C\uDDE8\uD83C\uDDE8","phonecode":"61","currency":"AUD","latitude":"-12.50000000","longitude":"96.83333333","timezones":[{"zoneName":"Indian/Cocos","gmtOffset":23400,"gmtOffsetName":"UTC+06:30","abbreviation":"CCT","tzName":"Cocos Islands Time"}]},{"name":"Colombia","isoCode":"CO","flag":"\uD83C\uDDE8\uD83C\uDDF4","phonecode":"57","currency":"COP","latitude":"4.00000000","longitude":"-72.00000000","timezones":[{"zoneName":"America/Bogota","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"COT","tzName":"Colombia Time"}]},{"name":"Comoros","isoCode":"KM","flag":"\uD83C\uDDF0\uD83C\uDDF2","phonecode":"269","currency":"KMF","latitude":"-12.16666666","longitude":"44.25000000","timezones":[{"zoneName":"Indian/Comoro","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"EAT","tzName":"East Africa Time"}]},{"name":"Congo","isoCode":"CG","flag":"\uD83C\uDDE8\uD83C\uDDEC","phonecode":"242","currency":"XAF","latitude":"-1.00000000","longitude":"15.00000000","timezones":[{"zoneName":"Africa/Brazzaville","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"WAT","tzName":"West Africa Time"}]},{"name":"Democratic Republic of the Congo","isoCode":"CD","flag":"\uD83C\uDDE8\uD83C\uDDE9","phonecode":"243","currency":"CDF","latitude":"0.00000000","longitude":"25.00000000","timezones":[{"zoneName":"Africa/Kinshasa","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"WAT","tzName":"West Africa Time"},{"zoneName":"Africa/Lubumbashi","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"CAT","tzName":"Central Africa Time"}]},{"name":"Cook Islands","isoCode":"CK","flag":"\uD83C\uDDE8\uD83C\uDDF0","phonecode":"682","currency":"NZD","latitude":"-21.23333333","longitude":"-159.76666666","timezones":[{"zoneName":"Pacific/Rarotonga","gmtOffset":-36000,"gmtOffsetName":"UTC-10:00","abbreviation":"CKT","tzName":"Cook Island Time"}]},{"name":"Costa Rica","isoCode":"CR","flag":"\uD83C\uDDE8\uD83C\uDDF7","phonecode":"506","currency":"CRC","latitude":"10.00000000","longitude":"-84.00000000","timezones":[{"zoneName":"America/Costa_Rica","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"}]},{"name":"Cote D\'Ivoire (Ivory Coast)","isoCode":"CI","flag":"\uD83C\uDDE8\uD83C\uDDEE","phonecode":"225","currency":"XOF","latitude":"8.00000000","longitude":"-5.00000000","timezones":[{"zoneName":"Africa/Abidjan","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Croatia","isoCode":"HR","flag":"\uD83C\uDDED\uD83C\uDDF7","phonecode":"385","currency":"HRK","latitude":"45.16666666","longitude":"15.50000000","timezones":[{"zoneName":"Europe/Zagreb","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Cuba","isoCode":"CU","flag":"\uD83C\uDDE8\uD83C\uDDFA","phonecode":"53","currency":"CUP","latitude":"21.50000000","longitude":"-80.00000000","timezones":[{"zoneName":"America/Havana","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"CST","tzName":"Cuba Standard Time"}]},{"name":"Cyprus","isoCode":"CY","flag":"\uD83C\uDDE8\uD83C\uDDFE","phonecode":"357","currency":"EUR","latitude":"35.00000000","longitude":"33.00000000","timezones":[{"zoneName":"Asia/Famagusta","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"},{"zoneName":"Asia/Nicosia","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Czech Republic","isoCode":"CZ","flag":"\uD83C\uDDE8\uD83C\uDDFF","phonecode":"420","currency":"CZK","latitude":"49.75000000","longitude":"15.50000000","timezones":[{"zoneName":"Europe/Prague","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Denmark","isoCode":"DK","flag":"\uD83C\uDDE9\uD83C\uDDF0","phonecode":"45","currency":"DKK","latitude":"56.00000000","longitude":"10.00000000","timezones":[{"zoneName":"Europe/Copenhagen","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Djibouti","isoCode":"DJ","flag":"\uD83C\uDDE9\uD83C\uDDEF","phonecode":"253","currency":"DJF","latitude":"11.50000000","longitude":"43.00000000","timezones":[{"zoneName":"Africa/Djibouti","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"EAT","tzName":"East Africa Time"}]},{"name":"Dominica","isoCode":"DM","flag":"\uD83C\uDDE9\uD83C\uDDF2","phonecode":"+1-767","currency":"XCD","latitude":"15.41666666","longitude":"-61.33333333","timezones":[{"zoneName":"America/Dominica","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Dominican Republic","isoCode":"DO","flag":"\uD83C\uDDE9\uD83C\uDDF4","phonecode":"+1-809 and 1-829","currency":"DOP","latitude":"19.00000000","longitude":"-70.66666666","timezones":[{"zoneName":"America/Santo_Domingo","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"East Timor","isoCode":"TL","flag":"\uD83C\uDDF9\uD83C\uDDF1","phonecode":"670","currency":"USD","latitude":"-8.83333333","longitude":"125.91666666","timezones":[{"zoneName":"Asia/Dili","gmtOffset":32400,"gmtOffsetName":"UTC+09:00","abbreviation":"TLT","tzName":"Timor Leste Time"}]},{"name":"Ecuador","isoCode":"EC","flag":"\uD83C\uDDEA\uD83C\uDDE8","phonecode":"593","currency":"USD","latitude":"-2.00000000","longitude":"-77.50000000","timezones":[{"zoneName":"America/Guayaquil","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"ECT","tzName":"Ecuador Time"},{"zoneName":"Pacific/Galapagos","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"GALT","tzName":"Gal\xe1pagos Time"}]},{"name":"Egypt","isoCode":"EG","flag":"\uD83C\uDDEA\uD83C\uDDEC","phonecode":"20","currency":"EGP","latitude":"27.00000000","longitude":"30.00000000","timezones":[{"zoneName":"Africa/Cairo","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"El Salvador","isoCode":"SV","flag":"\uD83C\uDDF8\uD83C\uDDFB","phonecode":"503","currency":"USD","latitude":"13.83333333","longitude":"-88.91666666","timezones":[{"zoneName":"America/El_Salvador","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"}]},{"name":"Equatorial Guinea","isoCode":"GQ","flag":"\uD83C\uDDEC\uD83C\uDDF6","phonecode":"240","currency":"XAF","latitude":"2.00000000","longitude":"10.00000000","timezones":[{"zoneName":"Africa/Malabo","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"WAT","tzName":"West Africa Time"}]},{"name":"Eritrea","isoCode":"ER","flag":"\uD83C\uDDEA\uD83C\uDDF7","phonecode":"291","currency":"ERN","latitude":"15.00000000","longitude":"39.00000000","timezones":[{"zoneName":"Africa/Asmara","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"EAT","tzName":"East Africa Time"}]},{"name":"Estonia","isoCode":"EE","flag":"\uD83C\uDDEA\uD83C\uDDEA","phonecode":"372","currency":"EUR","latitude":"59.00000000","longitude":"26.00000000","timezones":[{"zoneName":"Europe/Tallinn","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Ethiopia","isoCode":"ET","flag":"\uD83C\uDDEA\uD83C\uDDF9","phonecode":"251","currency":"ETB","latitude":"8.00000000","longitude":"38.00000000","timezones":[{"zoneName":"Africa/Addis_Ababa","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"EAT","tzName":"East Africa Time"}]},{"name":"Falkland Islands","isoCode":"FK","flag":"\uD83C\uDDEB\uD83C\uDDF0","phonecode":"500","currency":"FKP","latitude":"-51.75000000","longitude":"-59.00000000","timezones":[{"zoneName":"Atlantic/Stanley","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"FKST","tzName":"Falkland Islands Summer Time"}]},{"name":"Faroe Islands","isoCode":"FO","flag":"\uD83C\uDDEB\uD83C\uDDF4","phonecode":"298","currency":"DKK","latitude":"62.00000000","longitude":"-7.00000000","timezones":[{"zoneName":"Atlantic/Faroe","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"WET","tzName":"Western European Time"}]},{"name":"Fiji Islands","isoCode":"FJ","flag":"\uD83C\uDDEB\uD83C\uDDEF","phonecode":"679","currency":"FJD","latitude":"-18.00000000","longitude":"175.00000000","timezones":[{"zoneName":"Pacific/Fiji","gmtOffset":43200,"gmtOffsetName":"UTC+12:00","abbreviation":"FJT","tzName":"Fiji Time"}]},{"name":"Finland","isoCode":"FI","flag":"\uD83C\uDDEB\uD83C\uDDEE","phonecode":"358","currency":"EUR","latitude":"64.00000000","longitude":"26.00000000","timezones":[{"zoneName":"Europe/Helsinki","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"France","isoCode":"FR","flag":"\uD83C\uDDEB\uD83C\uDDF7","phonecode":"33","currency":"EUR","latitude":"46.00000000","longitude":"2.00000000","timezones":[{"zoneName":"Europe/Paris","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"French Guiana","isoCode":"GF","flag":"\uD83C\uDDEC\uD83C\uDDEB","phonecode":"594","currency":"EUR","latitude":"4.00000000","longitude":"-53.00000000","timezones":[{"zoneName":"America/Cayenne","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"GFT","tzName":"French Guiana Time"}]},{"name":"French Polynesia","isoCode":"PF","flag":"\uD83C\uDDF5\uD83C\uDDEB","phonecode":"689","currency":"XPF","latitude":"-15.00000000","longitude":"-140.00000000","timezones":[{"zoneName":"Pacific/Gambier","gmtOffset":-32400,"gmtOffsetName":"UTC-09:00","abbreviation":"GAMT","tzName":"Gambier Islands Time"},{"zoneName":"Pacific/Marquesas","gmtOffset":-34200,"gmtOffsetName":"UTC-09:30","abbreviation":"MART","tzName":"Marquesas Islands Time"},{"zoneName":"Pacific/Tahiti","gmtOffset":-36000,"gmtOffsetName":"UTC-10:00","abbreviation":"TAHT","tzName":"Tahiti Time"}]},{"name":"French Southern Territories","isoCode":"TF","flag":"\uD83C\uDDF9\uD83C\uDDEB","phonecode":"262","currency":"EUR","latitude":"-49.25000000","longitude":"69.16700000","timezones":[{"zoneName":"Indian/Kerguelen","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"TFT","tzName":"French Southern and Antarctic Time"}]},{"name":"Gabon","isoCode":"GA","flag":"\uD83C\uDDEC\uD83C\uDDE6","phonecode":"241","currency":"XAF","latitude":"-1.00000000","longitude":"11.75000000","timezones":[{"zoneName":"Africa/Libreville","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"WAT","tzName":"West Africa Time"}]},{"name":"Gambia The","isoCode":"GM","flag":"\uD83C\uDDEC\uD83C\uDDF2","phonecode":"220","currency":"GMD","latitude":"13.46666666","longitude":"-16.56666666","timezones":[{"zoneName":"Africa/Banjul","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Georgia","isoCode":"GE","flag":"\uD83C\uDDEC\uD83C\uDDEA","phonecode":"995","currency":"GEL","latitude":"42.00000000","longitude":"43.50000000","timezones":[{"zoneName":"Asia/Tbilisi","gmtOffset":14400,"gmtOffsetName":"UTC+04:00","abbreviation":"GET","tzName":"Georgia Standard Time"}]},{"name":"Germany","isoCode":"DE","flag":"\uD83C\uDDE9\uD83C\uDDEA","phonecode":"49","currency":"EUR","latitude":"51.00000000","longitude":"9.00000000","timezones":[{"zoneName":"Europe/Berlin","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"},{"zoneName":"Europe/Busingen","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Ghana","isoCode":"GH","flag":"\uD83C\uDDEC\uD83C\uDDED","phonecode":"233","currency":"GHS","latitude":"8.00000000","longitude":"-2.00000000","timezones":[{"zoneName":"Africa/Accra","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Gibraltar","isoCode":"GI","flag":"\uD83C\uDDEC\uD83C\uDDEE","phonecode":"350","currency":"GIP","latitude":"36.13333333","longitude":"-5.35000000","timezones":[{"zoneName":"Europe/Gibraltar","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Greece","isoCode":"GR","flag":"\uD83C\uDDEC\uD83C\uDDF7","phonecode":"30","currency":"EUR","latitude":"39.00000000","longitude":"22.00000000","timezones":[{"zoneName":"Europe/Athens","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Greenland","isoCode":"GL","flag":"\uD83C\uDDEC\uD83C\uDDF1","phonecode":"299","currency":"DKK","latitude":"72.00000000","longitude":"-40.00000000","timezones":[{"zoneName":"America/Danmarkshavn","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"},{"zoneName":"America/Nuuk","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"WGT","tzName":"West Greenland Time"},{"zoneName":"America/Scoresbysund","gmtOffset":-3600,"gmtOffsetName":"UTC-01:00","abbreviation":"EGT","tzName":"Eastern Greenland Time"},{"zoneName":"America/Thule","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Grenada","isoCode":"GD","flag":"\uD83C\uDDEC\uD83C\uDDE9","phonecode":"+1-473","currency":"XCD","latitude":"12.11666666","longitude":"-61.66666666","timezones":[{"zoneName":"America/Grenada","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Guadeloupe","isoCode":"GP","flag":"\uD83C\uDDEC\uD83C\uDDF5","phonecode":"590","currency":"EUR","latitude":"16.25000000","longitude":"-61.58333300","timezones":[{"zoneName":"America/Guadeloupe","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Guam","isoCode":"GU","flag":"\uD83C\uDDEC\uD83C\uDDFA","phonecode":"+1-671","currency":"USD","latitude":"13.46666666","longitude":"144.78333333","timezones":[{"zoneName":"Pacific/Guam","gmtOffset":36000,"gmtOffsetName":"UTC+10:00","abbreviation":"CHST","tzName":"Chamorro Standard Time"}]},{"name":"Guatemala","isoCode":"GT","flag":"\uD83C\uDDEC\uD83C\uDDF9","phonecode":"502","currency":"GTQ","latitude":"15.50000000","longitude":"-90.25000000","timezones":[{"zoneName":"America/Guatemala","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"}]},{"name":"Guernsey and Alderney","isoCode":"GG","flag":"\uD83C\uDDEC\uD83C\uDDEC","phonecode":"+44-1481","currency":"GBP","latitude":"49.46666666","longitude":"-2.58333333","timezones":[{"zoneName":"Europe/Guernsey","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Guinea","isoCode":"GN","flag":"\uD83C\uDDEC\uD83C\uDDF3","phonecode":"224","currency":"GNF","latitude":"11.00000000","longitude":"-10.00000000","timezones":[{"zoneName":"Africa/Conakry","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Guinea-Bissau","isoCode":"GW","flag":"\uD83C\uDDEC\uD83C\uDDFC","phonecode":"245","currency":"XOF","latitude":"12.00000000","longitude":"-15.00000000","timezones":[{"zoneName":"Africa/Bissau","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Guyana","isoCode":"GY","flag":"\uD83C\uDDEC\uD83C\uDDFE","phonecode":"592","currency":"GYD","latitude":"5.00000000","longitude":"-59.00000000","timezones":[{"zoneName":"America/Guyana","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"GYT","tzName":"Guyana Time"}]},{"name":"Haiti","isoCode":"HT","flag":"\uD83C\uDDED\uD83C\uDDF9","phonecode":"509","currency":"HTG","latitude":"19.00000000","longitude":"-72.41666666","timezones":[{"zoneName":"America/Port-au-Prince","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"}]},{"name":"Heard Island and McDonald Islands","isoCode":"HM","flag":"\uD83C\uDDED\uD83C\uDDF2","phonecode":"672","currency":"AUD","latitude":"-53.10000000","longitude":"72.51666666","timezones":[{"zoneName":"Indian/Kerguelen","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"TFT","tzName":"French Southern and Antarctic Time"}]},{"name":"Honduras","isoCode":"HN","flag":"\uD83C\uDDED\uD83C\uDDF3","phonecode":"504","currency":"HNL","latitude":"15.00000000","longitude":"-86.50000000","timezones":[{"zoneName":"America/Tegucigalpa","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"}]},{"name":"Hong Kong S.A.R.","isoCode":"HK","flag":"\uD83C\uDDED\uD83C\uDDF0","phonecode":"852","currency":"HKD","latitude":"22.25000000","longitude":"114.16666666","timezones":[{"zoneName":"Asia/Hong_Kong","gmtOffset":28800,"gmtOffsetName":"UTC+08:00","abbreviation":"HKT","tzName":"Hong Kong Time"}]},{"name":"Hungary","isoCode":"HU","flag":"\uD83C\uDDED\uD83C\uDDFA","phonecode":"36","currency":"HUF","latitude":"47.00000000","longitude":"20.00000000","timezones":[{"zoneName":"Europe/Budapest","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Iceland","isoCode":"IS","flag":"\uD83C\uDDEE\uD83C\uDDF8","phonecode":"354","currency":"ISK","latitude":"65.00000000","longitude":"-18.00000000","timezones":[{"zoneName":"Atlantic/Reykjavik","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"India","isoCode":"IN","flag":"\uD83C\uDDEE\uD83C\uDDF3","phonecode":"91","currency":"INR","latitude":"20.00000000","longitude":"77.00000000","timezones":[{"zoneName":"Asia/Kolkata","gmtOffset":19800,"gmtOffsetName":"UTC+05:30","abbreviation":"IST","tzName":"Indian Standard Time"}]},{"name":"Indonesia","isoCode":"ID","flag":"\uD83C\uDDEE\uD83C\uDDE9","phonecode":"62","currency":"IDR","latitude":"-5.00000000","longitude":"120.00000000","timezones":[{"zoneName":"Asia/Jakarta","gmtOffset":25200,"gmtOffsetName":"UTC+07:00","abbreviation":"WIB","tzName":"Western Indonesian Time"},{"zoneName":"Asia/Jayapura","gmtOffset":32400,"gmtOffsetName":"UTC+09:00","abbreviation":"WIT","tzName":"Eastern Indonesian Time"},{"zoneName":"Asia/Makassar","gmtOffset":28800,"gmtOffsetName":"UTC+08:00","abbreviation":"WITA","tzName":"Central Indonesia Time"},{"zoneName":"Asia/Pontianak","gmtOffset":25200,"gmtOffsetName":"UTC+07:00","abbreviation":"WIB","tzName":"Western Indonesian Time"}]},{"name":"Iran","isoCode":"IR","flag":"\uD83C\uDDEE\uD83C\uDDF7","phonecode":"98","currency":"IRR","latitude":"32.00000000","longitude":"53.00000000","timezones":[{"zoneName":"Asia/Tehran","gmtOffset":12600,"gmtOffsetName":"UTC+03:30","abbreviation":"IRDT","tzName":"Iran Daylight Time"}]},{"name":"Iraq","isoCode":"IQ","flag":"\uD83C\uDDEE\uD83C\uDDF6","phonecode":"964","currency":"IQD","latitude":"33.00000000","longitude":"44.00000000","timezones":[{"zoneName":"Asia/Baghdad","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"AST","tzName":"Arabia Standard Time"}]},{"name":"Ireland","isoCode":"IE","flag":"\uD83C\uDDEE\uD83C\uDDEA","phonecode":"353","currency":"EUR","latitude":"53.00000000","longitude":"-8.00000000","timezones":[{"zoneName":"Europe/Dublin","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Israel","isoCode":"IL","flag":"\uD83C\uDDEE\uD83C\uDDF1","phonecode":"972","currency":"ILS","latitude":"31.50000000","longitude":"34.75000000","timezones":[{"zoneName":"Asia/Jerusalem","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"IST","tzName":"Israel Standard Time"}]},{"name":"Italy","isoCode":"IT","flag":"\uD83C\uDDEE\uD83C\uDDF9","phonecode":"39","currency":"EUR","latitude":"42.83333333","longitude":"12.83333333","timezones":[{"zoneName":"Europe/Rome","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Jamaica","isoCode":"JM","flag":"\uD83C\uDDEF\uD83C\uDDF2","phonecode":"+1-876","currency":"JMD","latitude":"18.25000000","longitude":"-77.50000000","timezones":[{"zoneName":"America/Jamaica","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"}]},{"name":"Japan","isoCode":"JP","flag":"\uD83C\uDDEF\uD83C\uDDF5","phonecode":"81","currency":"JPY","latitude":"36.00000000","longitude":"138.00000000","timezones":[{"zoneName":"Asia/Tokyo","gmtOffset":32400,"gmtOffsetName":"UTC+09:00","abbreviation":"JST","tzName":"Japan Standard Time"}]},{"name":"Jersey","isoCode":"JE","flag":"\uD83C\uDDEF\uD83C\uDDEA","phonecode":"+44-1534","currency":"GBP","latitude":"49.25000000","longitude":"-2.16666666","timezones":[{"zoneName":"Europe/Jersey","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Jordan","isoCode":"JO","flag":"\uD83C\uDDEF\uD83C\uDDF4","phonecode":"962","currency":"JOD","latitude":"31.00000000","longitude":"36.00000000","timezones":[{"zoneName":"Asia/Amman","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Kazakhstan","isoCode":"KZ","flag":"\uD83C\uDDF0\uD83C\uDDFF","phonecode":"7","currency":"KZT","latitude":"48.00000000","longitude":"68.00000000","timezones":[{"zoneName":"Asia/Almaty","gmtOffset":21600,"gmtOffsetName":"UTC+06:00","abbreviation":"ALMT","tzName":"Alma-Ata Time[1"},{"zoneName":"Asia/Aqtau","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"AQTT","tzName":"Aqtobe Time"},{"zoneName":"Asia/Aqtobe","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"AQTT","tzName":"Aqtobe Time"},{"zoneName":"Asia/Atyrau","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"MSD+1","tzName":"Moscow Daylight Time+1"},{"zoneName":"Asia/Oral","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"ORAT","tzName":"Oral Time"},{"zoneName":"Asia/Qostanay","gmtOffset":21600,"gmtOffsetName":"UTC+06:00","abbreviation":"QYZST","tzName":"Qyzylorda Summer Time"},{"zoneName":"Asia/Qyzylorda","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"QYZT","tzName":"Qyzylorda Summer Time"}]},{"name":"Kenya","isoCode":"KE","flag":"\uD83C\uDDF0\uD83C\uDDEA","phonecode":"254","currency":"KES","latitude":"1.00000000","longitude":"38.00000000","timezones":[{"zoneName":"Africa/Nairobi","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"EAT","tzName":"East Africa Time"}]},{"name":"Kiribati","isoCode":"KI","flag":"\uD83C\uDDF0\uD83C\uDDEE","phonecode":"686","currency":"AUD","latitude":"1.41666666","longitude":"173.00000000","timezones":[{"zoneName":"Pacific/Enderbury","gmtOffset":46800,"gmtOffsetName":"UTC+13:00","abbreviation":"PHOT","tzName":"Phoenix Island Time"},{"zoneName":"Pacific/Kiritimati","gmtOffset":50400,"gmtOffsetName":"UTC+14:00","abbreviation":"LINT","tzName":"Line Islands Time"},{"zoneName":"Pacific/Tarawa","gmtOffset":43200,"gmtOffsetName":"UTC+12:00","abbreviation":"GILT","tzName":"Gilbert Island Time"}]},{"name":"North Korea","isoCode":"KP","flag":"\uD83C\uDDF0\uD83C\uDDF5","phonecode":"850","currency":"KPW","latitude":"40.00000000","longitude":"127.00000000","timezones":[{"zoneName":"Asia/Pyongyang","gmtOffset":32400,"gmtOffsetName":"UTC+09:00","abbreviation":"KST","tzName":"Korea Standard Time"}]},{"name":"South Korea","isoCode":"KR","flag":"\uD83C\uDDF0\uD83C\uDDF7","phonecode":"82","currency":"KRW","latitude":"37.00000000","longitude":"127.50000000","timezones":[{"zoneName":"Asia/Seoul","gmtOffset":32400,"gmtOffsetName":"UTC+09:00","abbreviation":"KST","tzName":"Korea Standard Time"}]},{"name":"Kuwait","isoCode":"KW","flag":"\uD83C\uDDF0\uD83C\uDDFC","phonecode":"965","currency":"KWD","latitude":"29.50000000","longitude":"45.75000000","timezones":[{"zoneName":"Asia/Kuwait","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"AST","tzName":"Arabia Standard Time"}]},{"name":"Kyrgyzstan","isoCode":"KG","flag":"\uD83C\uDDF0\uD83C\uDDEC","phonecode":"996","currency":"KGS","latitude":"41.00000000","longitude":"75.00000000","timezones":[{"zoneName":"Asia/Bishkek","gmtOffset":21600,"gmtOffsetName":"UTC+06:00","abbreviation":"KGT","tzName":"Kyrgyzstan Time"}]},{"name":"Laos","isoCode":"LA","flag":"\uD83C\uDDF1\uD83C\uDDE6","phonecode":"856","currency":"LAK","latitude":"18.00000000","longitude":"105.00000000","timezones":[{"zoneName":"Asia/Vientiane","gmtOffset":25200,"gmtOffsetName":"UTC+07:00","abbreviation":"ICT","tzName":"Indochina Time"}]},{"name":"Latvia","isoCode":"LV","flag":"\uD83C\uDDF1\uD83C\uDDFB","phonecode":"371","currency":"EUR","latitude":"57.00000000","longitude":"25.00000000","timezones":[{"zoneName":"Europe/Riga","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Lebanon","isoCode":"LB","flag":"\uD83C\uDDF1\uD83C\uDDE7","phonecode":"961","currency":"LBP","latitude":"33.83333333","longitude":"35.83333333","timezones":[{"zoneName":"Asia/Beirut","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Lesotho","isoCode":"LS","flag":"\uD83C\uDDF1\uD83C\uDDF8","phonecode":"266","currency":"LSL","latitude":"-29.50000000","longitude":"28.50000000","timezones":[{"zoneName":"Africa/Maseru","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"SAST","tzName":"South African Standard Time"}]},{"name":"Liberia","isoCode":"LR","flag":"\uD83C\uDDF1\uD83C\uDDF7","phonecode":"231","currency":"LRD","latitude":"6.50000000","longitude":"-9.50000000","timezones":[{"zoneName":"Africa/Monrovia","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Libya","isoCode":"LY","flag":"\uD83C\uDDF1\uD83C\uDDFE","phonecode":"218","currency":"LYD","latitude":"25.00000000","longitude":"17.00000000","timezones":[{"zoneName":"Africa/Tripoli","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Liechtenstein","isoCode":"LI","flag":"\uD83C\uDDF1\uD83C\uDDEE","phonecode":"423","currency":"CHF","latitude":"47.26666666","longitude":"9.53333333","timezones":[{"zoneName":"Europe/Vaduz","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Lithuania","isoCode":"LT","flag":"\uD83C\uDDF1\uD83C\uDDF9","phonecode":"370","currency":"EUR","latitude":"56.00000000","longitude":"24.00000000","timezones":[{"zoneName":"Europe/Vilnius","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Luxembourg","isoCode":"LU","flag":"\uD83C\uDDF1\uD83C\uDDFA","phonecode":"352","currency":"EUR","latitude":"49.75000000","longitude":"6.16666666","timezones":[{"zoneName":"Europe/Luxembourg","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Macau S.A.R.","isoCode":"MO","flag":"\uD83C\uDDF2\uD83C\uDDF4","phonecode":"853","currency":"MOP","latitude":"22.16666666","longitude":"113.55000000","timezones":[{"zoneName":"Asia/Macau","gmtOffset":28800,"gmtOffsetName":"UTC+08:00","abbreviation":"CST","tzName":"China Standard Time"}]},{"name":"Macedonia","isoCode":"MK","flag":"\uD83C\uDDF2\uD83C\uDDF0","phonecode":"389","currency":"MKD","latitude":"41.83333333","longitude":"22.00000000","timezones":[{"zoneName":"Europe/Skopje","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Madagascar","isoCode":"MG","flag":"\uD83C\uDDF2\uD83C\uDDEC","phonecode":"261","currency":"MGA","latitude":"-20.00000000","longitude":"47.00000000","timezones":[{"zoneName":"Indian/Antananarivo","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"EAT","tzName":"East Africa Time"}]},{"name":"Malawi","isoCode":"MW","flag":"\uD83C\uDDF2\uD83C\uDDFC","phonecode":"265","currency":"MWK","latitude":"-13.50000000","longitude":"34.00000000","timezones":[{"zoneName":"Africa/Blantyre","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"CAT","tzName":"Central Africa Time"}]},{"name":"Malaysia","isoCode":"MY","flag":"\uD83C\uDDF2\uD83C\uDDFE","phonecode":"60","currency":"MYR","latitude":"2.50000000","longitude":"112.50000000","timezones":[{"zoneName":"Asia/Kuala_Lumpur","gmtOffset":28800,"gmtOffsetName":"UTC+08:00","abbreviation":"MYT","tzName":"Malaysia Time"},{"zoneName":"Asia/Kuching","gmtOffset":28800,"gmtOffsetName":"UTC+08:00","abbreviation":"MYT","tzName":"Malaysia Time"}]},{"name":"Maldives","isoCode":"MV","flag":"\uD83C\uDDF2\uD83C\uDDFB","phonecode":"960","currency":"MVR","latitude":"3.25000000","longitude":"73.00000000","timezones":[{"zoneName":"Indian/Maldives","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"MVT","tzName":"Maldives Time"}]},{"name":"Mali","isoCode":"ML","flag":"\uD83C\uDDF2\uD83C\uDDF1","phonecode":"223","currency":"XOF","latitude":"17.00000000","longitude":"-4.00000000","timezones":[{"zoneName":"Africa/Bamako","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Malta","isoCode":"MT","flag":"\uD83C\uDDF2\uD83C\uDDF9","phonecode":"356","currency":"EUR","latitude":"35.83333333","longitude":"14.58333333","timezones":[{"zoneName":"Europe/Malta","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Man (Isle of)","isoCode":"IM","flag":"\uD83C\uDDEE\uD83C\uDDF2","phonecode":"+44-1624","currency":"GBP","latitude":"54.25000000","longitude":"-4.50000000","timezones":[{"zoneName":"Europe/Isle_of_Man","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Marshall Islands","isoCode":"MH","flag":"\uD83C\uDDF2\uD83C\uDDED","phonecode":"692","currency":"USD","latitude":"9.00000000","longitude":"168.00000000","timezones":[{"zoneName":"Pacific/Kwajalein","gmtOffset":43200,"gmtOffsetName":"UTC+12:00","abbreviation":"MHT","tzName":"Marshall Islands Time"},{"zoneName":"Pacific/Majuro","gmtOffset":43200,"gmtOffsetName":"UTC+12:00","abbreviation":"MHT","tzName":"Marshall Islands Time"}]},{"name":"Martinique","isoCode":"MQ","flag":"\uD83C\uDDF2\uD83C\uDDF6","phonecode":"596","currency":"EUR","latitude":"14.66666700","longitude":"-61.00000000","timezones":[{"zoneName":"America/Martinique","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Mauritania","isoCode":"MR","flag":"\uD83C\uDDF2\uD83C\uDDF7","phonecode":"222","currency":"MRO","latitude":"20.00000000","longitude":"-12.00000000","timezones":[{"zoneName":"Africa/Nouakchott","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Mauritius","isoCode":"MU","flag":"\uD83C\uDDF2\uD83C\uDDFA","phonecode":"230","currency":"MUR","latitude":"-20.28333333","longitude":"57.55000000","timezones":[{"zoneName":"Indian/Mauritius","gmtOffset":14400,"gmtOffsetName":"UTC+04:00","abbreviation":"MUT","tzName":"Mauritius Time"}]},{"name":"Mayotte","isoCode":"YT","flag":"\uD83C\uDDFE\uD83C\uDDF9","phonecode":"262","currency":"EUR","latitude":"-12.83333333","longitude":"45.16666666","timezones":[{"zoneName":"Indian/Mayotte","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"EAT","tzName":"East Africa Time"}]},{"name":"Mexico","isoCode":"MX","flag":"\uD83C\uDDF2\uD83C\uDDFD","phonecode":"52","currency":"MXN","latitude":"23.00000000","longitude":"-102.00000000","timezones":[{"zoneName":"America/Bahia_Banderas","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Cancun","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Chihuahua","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America"},{"zoneName":"America/Hermosillo","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America"},{"zoneName":"America/Matamoros","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Mazatlan","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America"},{"zoneName":"America/Merida","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Mexico_City","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Monterrey","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Ojinaga","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America"},{"zoneName":"America/Tijuana","gmtOffset":-28800,"gmtOffsetName":"UTC-08:00","abbreviation":"PST","tzName":"Pacific Standard Time (North America"}]},{"name":"Micronesia","isoCode":"FM","flag":"\uD83C\uDDEB\uD83C\uDDF2","phonecode":"691","currency":"USD","latitude":"6.91666666","longitude":"158.25000000","timezones":[{"zoneName":"Pacific/Chuuk","gmtOffset":36000,"gmtOffsetName":"UTC+10:00","abbreviation":"CHUT","tzName":"Chuuk Time"},{"zoneName":"Pacific/Kosrae","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"KOST","tzName":"Kosrae Time"},{"zoneName":"Pacific/Pohnpei","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"PONT","tzName":"Pohnpei Standard Time"}]},{"name":"Moldova","isoCode":"MD","flag":"\uD83C\uDDF2\uD83C\uDDE9","phonecode":"373","currency":"MDL","latitude":"47.00000000","longitude":"29.00000000","timezones":[{"zoneName":"Europe/Chisinau","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Monaco","isoCode":"MC","flag":"\uD83C\uDDF2\uD83C\uDDE8","phonecode":"377","currency":"EUR","latitude":"43.73333333","longitude":"7.40000000","timezones":[{"zoneName":"Europe/Monaco","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Mongolia","isoCode":"MN","flag":"\uD83C\uDDF2\uD83C\uDDF3","phonecode":"976","currency":"MNT","latitude":"46.00000000","longitude":"105.00000000","timezones":[{"zoneName":"Asia/Choibalsan","gmtOffset":28800,"gmtOffsetName":"UTC+08:00","abbreviation":"CHOT","tzName":"Choibalsan Standard Time"},{"zoneName":"Asia/Hovd","gmtOffset":25200,"gmtOffsetName":"UTC+07:00","abbreviation":"HOVT","tzName":"Hovd Time"},{"zoneName":"Asia/Ulaanbaatar","gmtOffset":28800,"gmtOffsetName":"UTC+08:00","abbreviation":"ULAT","tzName":"Ulaanbaatar Standard Time"}]},{"name":"Montenegro","isoCode":"ME","flag":"\uD83C\uDDF2\uD83C\uDDEA","phonecode":"382","currency":"EUR","latitude":"42.50000000","longitude":"19.30000000","timezones":[{"zoneName":"Europe/Podgorica","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Montserrat","isoCode":"MS","flag":"\uD83C\uDDF2\uD83C\uDDF8","phonecode":"+1-664","currency":"XCD","latitude":"16.75000000","longitude":"-62.20000000","timezones":[{"zoneName":"America/Montserrat","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Morocco","isoCode":"MA","flag":"\uD83C\uDDF2\uD83C\uDDE6","phonecode":"212","currency":"MAD","latitude":"32.00000000","longitude":"-5.00000000","timezones":[{"zoneName":"Africa/Casablanca","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"WEST","tzName":"Western European Summer Time"}]},{"name":"Mozambique","isoCode":"MZ","flag":"\uD83C\uDDF2\uD83C\uDDFF","phonecode":"258","currency":"MZN","latitude":"-18.25000000","longitude":"35.00000000","timezones":[{"zoneName":"Africa/Maputo","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"CAT","tzName":"Central Africa Time"}]},{"name":"Myanmar","isoCode":"MM","flag":"\uD83C\uDDF2\uD83C\uDDF2","phonecode":"95","currency":"MMK","latitude":"22.00000000","longitude":"98.00000000","timezones":[{"zoneName":"Asia/Yangon","gmtOffset":23400,"gmtOffsetName":"UTC+06:30","abbreviation":"MMT","tzName":"Myanmar Standard Time"}]},{"name":"Namibia","isoCode":"NA","flag":"\uD83C\uDDF3\uD83C\uDDE6","phonecode":"264","currency":"NAD","latitude":"-22.00000000","longitude":"17.00000000","timezones":[{"zoneName":"Africa/Windhoek","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"WAST","tzName":"West Africa Summer Time"}]},{"name":"Nauru","isoCode":"NR","flag":"\uD83C\uDDF3\uD83C\uDDF7","phonecode":"674","currency":"AUD","latitude":"-0.53333333","longitude":"166.91666666","timezones":[{"zoneName":"Pacific/Nauru","gmtOffset":43200,"gmtOffsetName":"UTC+12:00","abbreviation":"NRT","tzName":"Nauru Time"}]},{"name":"Nepal","isoCode":"NP","flag":"\uD83C\uDDF3\uD83C\uDDF5","phonecode":"977","currency":"NPR","latitude":"28.00000000","longitude":"84.00000000","timezones":[{"zoneName":"Asia/Kathmandu","gmtOffset":20700,"gmtOffsetName":"UTC+05:45","abbreviation":"NPT","tzName":"Nepal Time"}]},{"name":"Bonaire, Sint Eustatius and Saba","isoCode":"BQ","flag":"\uD83C\uDDE7\uD83C\uDDF6","phonecode":"599","currency":"USD","latitude":"12.15000000","longitude":"-68.26666700","timezones":[{"zoneName":"America/Anguilla","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Netherlands","isoCode":"NL","flag":"\uD83C\uDDF3\uD83C\uDDF1","phonecode":"31","currency":"EUR","latitude":"52.50000000","longitude":"5.75000000","timezones":[{"zoneName":"Europe/Amsterdam","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"New Caledonia","isoCode":"NC","flag":"\uD83C\uDDF3\uD83C\uDDE8","phonecode":"687","currency":"XPF","latitude":"-21.50000000","longitude":"165.50000000","timezones":[{"zoneName":"Pacific/Noumea","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"NCT","tzName":"New Caledonia Time"}]},{"name":"New Zealand","isoCode":"NZ","flag":"\uD83C\uDDF3\uD83C\uDDFF","phonecode":"64","currency":"NZD","latitude":"-41.00000000","longitude":"174.00000000","timezones":[{"zoneName":"Pacific/Auckland","gmtOffset":46800,"gmtOffsetName":"UTC+13:00","abbreviation":"NZDT","tzName":"New Zealand Daylight Time"},{"zoneName":"Pacific/Chatham","gmtOffset":49500,"gmtOffsetName":"UTC+13:45","abbreviation":"CHAST","tzName":"Chatham Standard Time"}]},{"name":"Nicaragua","isoCode":"NI","flag":"\uD83C\uDDF3\uD83C\uDDEE","phonecode":"505","currency":"NIO","latitude":"13.00000000","longitude":"-85.00000000","timezones":[{"zoneName":"America/Managua","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"}]},{"name":"Niger","isoCode":"NE","flag":"\uD83C\uDDF3\uD83C\uDDEA","phonecode":"227","currency":"XOF","latitude":"16.00000000","longitude":"8.00000000","timezones":[{"zoneName":"Africa/Niamey","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"WAT","tzName":"West Africa Time"}]},{"name":"Nigeria","isoCode":"NG","flag":"\uD83C\uDDF3\uD83C\uDDEC","phonecode":"234","currency":"NGN","latitude":"10.00000000","longitude":"8.00000000","timezones":[{"zoneName":"Africa/Lagos","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"WAT","tzName":"West Africa Time"}]},{"name":"Niue","isoCode":"NU","flag":"\uD83C\uDDF3\uD83C\uDDFA","phonecode":"683","currency":"NZD","latitude":"-19.03333333","longitude":"-169.86666666","timezones":[{"zoneName":"Pacific/Niue","gmtOffset":-39600,"gmtOffsetName":"UTC-11:00","abbreviation":"NUT","tzName":"Niue Time"}]},{"name":"Norfolk Island","isoCode":"NF","flag":"\uD83C\uDDF3\uD83C\uDDEB","phonecode":"672","currency":"AUD","latitude":"-29.03333333","longitude":"167.95000000","timezones":[{"zoneName":"Pacific/Norfolk","gmtOffset":43200,"gmtOffsetName":"UTC+12:00","abbreviation":"NFT","tzName":"Norfolk Time"}]},{"name":"Northern Mariana Islands","isoCode":"MP","flag":"\uD83C\uDDF2\uD83C\uDDF5","phonecode":"+1-670","currency":"USD","latitude":"15.20000000","longitude":"145.75000000","timezones":[{"zoneName":"Pacific/Saipan","gmtOffset":36000,"gmtOffsetName":"UTC+10:00","abbreviation":"ChST","tzName":"Chamorro Standard Time"}]},{"name":"Norway","isoCode":"NO","flag":"\uD83C\uDDF3\uD83C\uDDF4","phonecode":"47","currency":"NOK","latitude":"62.00000000","longitude":"10.00000000","timezones":[{"zoneName":"Europe/Oslo","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Oman","isoCode":"OM","flag":"\uD83C\uDDF4\uD83C\uDDF2","phonecode":"968","currency":"OMR","latitude":"21.00000000","longitude":"57.00000000","timezones":[{"zoneName":"Asia/Muscat","gmtOffset":14400,"gmtOffsetName":"UTC+04:00","abbreviation":"GST","tzName":"Gulf Standard Time"}]},{"name":"Pakistan","isoCode":"PK","flag":"\uD83C\uDDF5\uD83C\uDDF0","phonecode":"92","currency":"PKR","latitude":"30.00000000","longitude":"70.00000000","timezones":[{"zoneName":"Asia/Karachi","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"PKT","tzName":"Pakistan Standard Time"}]},{"name":"Palau","isoCode":"PW","flag":"\uD83C\uDDF5\uD83C\uDDFC","phonecode":"680","currency":"USD","latitude":"7.50000000","longitude":"134.50000000","timezones":[{"zoneName":"Pacific/Palau","gmtOffset":32400,"gmtOffsetName":"UTC+09:00","abbreviation":"PWT","tzName":"Palau Time"}]},{"name":"Palestinian Territory Occupied","isoCode":"PS","flag":"\uD83C\uDDF5\uD83C\uDDF8","phonecode":"970","currency":"ILS","latitude":"31.90000000","longitude":"35.20000000","timezones":[{"zoneName":"Asia/Gaza","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"},{"zoneName":"Asia/Hebron","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Panama","isoCode":"PA","flag":"\uD83C\uDDF5\uD83C\uDDE6","phonecode":"507","currency":"PAB","latitude":"9.00000000","longitude":"-80.00000000","timezones":[{"zoneName":"America/Panama","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"}]},{"name":"Papua new Guinea","isoCode":"PG","flag":"\uD83C\uDDF5\uD83C\uDDEC","phonecode":"675","currency":"PGK","latitude":"-6.00000000","longitude":"147.00000000","timezones":[{"zoneName":"Pacific/Bougainville","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"BST","tzName":"Bougainville Standard Time[6"},{"zoneName":"Pacific/Port_Moresby","gmtOffset":36000,"gmtOffsetName":"UTC+10:00","abbreviation":"PGT","tzName":"Papua New Guinea Time"}]},{"name":"Paraguay","isoCode":"PY","flag":"\uD83C\uDDF5\uD83C\uDDFE","phonecode":"595","currency":"PYG","latitude":"-23.00000000","longitude":"-58.00000000","timezones":[{"zoneName":"America/Asuncion","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"PYST","tzName":"Paraguay Summer Time"}]},{"name":"Peru","isoCode":"PE","flag":"\uD83C\uDDF5\uD83C\uDDEA","phonecode":"51","currency":"PEN","latitude":"-10.00000000","longitude":"-76.00000000","timezones":[{"zoneName":"America/Lima","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"PET","tzName":"Peru Time"}]},{"name":"Philippines","isoCode":"PH","flag":"\uD83C\uDDF5\uD83C\uDDED","phonecode":"63","currency":"PHP","latitude":"13.00000000","longitude":"122.00000000","timezones":[{"zoneName":"Asia/Manila","gmtOffset":28800,"gmtOffsetName":"UTC+08:00","abbreviation":"PHT","tzName":"Philippine Time"}]},{"name":"Pitcairn Island","isoCode":"PN","flag":"\uD83C\uDDF5\uD83C\uDDF3","phonecode":"870","currency":"NZD","latitude":"-25.06666666","longitude":"-130.10000000","timezones":[{"zoneName":"Pacific/Pitcairn","gmtOffset":-28800,"gmtOffsetName":"UTC-08:00","abbreviation":"PST","tzName":"Pacific Standard Time (North America"}]},{"name":"Poland","isoCode":"PL","flag":"\uD83C\uDDF5\uD83C\uDDF1","phonecode":"48","currency":"PLN","latitude":"52.00000000","longitude":"20.00000000","timezones":[{"zoneName":"Europe/Warsaw","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Portugal","isoCode":"PT","flag":"\uD83C\uDDF5\uD83C\uDDF9","phonecode":"351","currency":"EUR","latitude":"39.50000000","longitude":"-8.00000000","timezones":[{"zoneName":"Atlantic/Azores","gmtOffset":-3600,"gmtOffsetName":"UTC-01:00","abbreviation":"AZOT","tzName":"Azores Standard Time"},{"zoneName":"Atlantic/Madeira","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"WET","tzName":"Western European Time"},{"zoneName":"Europe/Lisbon","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"WET","tzName":"Western European Time"}]},{"name":"Puerto Rico","isoCode":"PR","flag":"\uD83C\uDDF5\uD83C\uDDF7","phonecode":"+1-787 and 1-939","currency":"USD","latitude":"18.25000000","longitude":"-66.50000000","timezones":[{"zoneName":"America/Puerto_Rico","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Qatar","isoCode":"QA","flag":"\uD83C\uDDF6\uD83C\uDDE6","phonecode":"974","currency":"QAR","latitude":"25.50000000","longitude":"51.25000000","timezones":[{"zoneName":"Asia/Qatar","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"AST","tzName":"Arabia Standard Time"}]},{"name":"Reunion","isoCode":"RE","flag":"\uD83C\uDDF7\uD83C\uDDEA","phonecode":"262","currency":"EUR","latitude":"-21.15000000","longitude":"55.50000000","timezones":[{"zoneName":"Indian/Reunion","gmtOffset":14400,"gmtOffsetName":"UTC+04:00","abbreviation":"RET","tzName":"R\xe9union Time"}]},{"name":"Romania","isoCode":"RO","flag":"\uD83C\uDDF7\uD83C\uDDF4","phonecode":"40","currency":"RON","latitude":"46.00000000","longitude":"25.00000000","timezones":[{"zoneName":"Europe/Bucharest","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Russia","isoCode":"RU","flag":"\uD83C\uDDF7\uD83C\uDDFA","phonecode":"7","currency":"RUB","latitude":"60.00000000","longitude":"100.00000000","timezones":[{"zoneName":"Asia/Anadyr","gmtOffset":43200,"gmtOffsetName":"UTC+12:00","abbreviation":"ANAT","tzName":"Anadyr Time[4"},{"zoneName":"Asia/Barnaul","gmtOffset":25200,"gmtOffsetName":"UTC+07:00","abbreviation":"KRAT","tzName":"Krasnoyarsk Time"},{"zoneName":"Asia/Chita","gmtOffset":32400,"gmtOffsetName":"UTC+09:00","abbreviation":"YAKT","tzName":"Yakutsk Time"},{"zoneName":"Asia/Irkutsk","gmtOffset":28800,"gmtOffsetName":"UTC+08:00","abbreviation":"IRKT","tzName":"Irkutsk Time"},{"zoneName":"Asia/Kamchatka","gmtOffset":43200,"gmtOffsetName":"UTC+12:00","abbreviation":"PETT","tzName":"Kamchatka Time"},{"zoneName":"Asia/Khandyga","gmtOffset":32400,"gmtOffsetName":"UTC+09:00","abbreviation":"YAKT","tzName":"Yakutsk Time"},{"zoneName":"Asia/Krasnoyarsk","gmtOffset":25200,"gmtOffsetName":"UTC+07:00","abbreviation":"KRAT","tzName":"Krasnoyarsk Time"},{"zoneName":"Asia/Magadan","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"MAGT","tzName":"Magadan Time"},{"zoneName":"Asia/Novokuznetsk","gmtOffset":25200,"gmtOffsetName":"UTC+07:00","abbreviation":"KRAT","tzName":"Krasnoyarsk Time"},{"zoneName":"Asia/Novosibirsk","gmtOffset":25200,"gmtOffsetName":"UTC+07:00","abbreviation":"NOVT","tzName":"Novosibirsk Time"},{"zoneName":"Asia/Omsk","gmtOffset":21600,"gmtOffsetName":"UTC+06:00","abbreviation":"OMST","tzName":"Omsk Time"},{"zoneName":"Asia/Sakhalin","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"SAKT","tzName":"Sakhalin Island Time"},{"zoneName":"Asia/Srednekolymsk","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"SRET","tzName":"Srednekolymsk Time"},{"zoneName":"Asia/Tomsk","gmtOffset":25200,"gmtOffsetName":"UTC+07:00","abbreviation":"MSD+3","tzName":"Moscow Daylight Time+3"},{"zoneName":"Asia/Ust-Nera","gmtOffset":36000,"gmtOffsetName":"UTC+10:00","abbreviation":"VLAT","tzName":"Vladivostok Time"},{"zoneName":"Asia/Vladivostok","gmtOffset":36000,"gmtOffsetName":"UTC+10:00","abbreviation":"VLAT","tzName":"Vladivostok Time"},{"zoneName":"Asia/Yakutsk","gmtOffset":32400,"gmtOffsetName":"UTC+09:00","abbreviation":"YAKT","tzName":"Yakutsk Time"},{"zoneName":"Asia/Yekaterinburg","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"YEKT","tzName":"Yekaterinburg Time"},{"zoneName":"Europe/Astrakhan","gmtOffset":14400,"gmtOffsetName":"UTC+04:00","abbreviation":"SAMT","tzName":"Samara Time"},{"zoneName":"Europe/Kaliningrad","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"},{"zoneName":"Europe/Kirov","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"MSK","tzName":"Moscow Time"},{"zoneName":"Europe/Moscow","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"MSK","tzName":"Moscow Time"},{"zoneName":"Europe/Samara","gmtOffset":14400,"gmtOffsetName":"UTC+04:00","abbreviation":"SAMT","tzName":"Samara Time"},{"zoneName":"Europe/Saratov","gmtOffset":14400,"gmtOffsetName":"UTC+04:00","abbreviation":"MSD","tzName":"Moscow Daylight Time+4"},{"zoneName":"Europe/Ulyanovsk","gmtOffset":14400,"gmtOffsetName":"UTC+04:00","abbreviation":"SAMT","tzName":"Samara Time"},{"zoneName":"Europe/Volgograd","gmtOffset":14400,"gmtOffsetName":"UTC+04:00","abbreviation":"MSK","tzName":"Moscow Standard Time"}]},{"name":"Rwanda","isoCode":"RW","flag":"\uD83C\uDDF7\uD83C\uDDFC","phonecode":"250","currency":"RWF","latitude":"-2.00000000","longitude":"30.00000000","timezones":[{"zoneName":"Africa/Kigali","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"CAT","tzName":"Central Africa Time"}]},{"name":"Saint Helena","isoCode":"SH","flag":"\uD83C\uDDF8\uD83C\uDDED","phonecode":"290","currency":"SHP","latitude":"-15.95000000","longitude":"-5.70000000","timezones":[{"zoneName":"Atlantic/St_Helena","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Saint Kitts And Nevis","isoCode":"KN","flag":"\uD83C\uDDF0\uD83C\uDDF3","phonecode":"+1-869","currency":"XCD","latitude":"17.33333333","longitude":"-62.75000000","timezones":[{"zoneName":"America/St_Kitts","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Saint Lucia","isoCode":"LC","flag":"\uD83C\uDDF1\uD83C\uDDE8","phonecode":"+1-758","currency":"XCD","latitude":"13.88333333","longitude":"-60.96666666","timezones":[{"zoneName":"America/St_Lucia","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Saint Pierre and Miquelon","isoCode":"PM","flag":"\uD83C\uDDF5\uD83C\uDDF2","phonecode":"508","currency":"EUR","latitude":"46.83333333","longitude":"-56.33333333","timezones":[{"zoneName":"America/Miquelon","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"PMDT","tzName":"Pierre & Miquelon Daylight Time"}]},{"name":"Saint Vincent And The Grenadines","isoCode":"VC","flag":"\uD83C\uDDFB\uD83C\uDDE8","phonecode":"+1-784","currency":"XCD","latitude":"13.25000000","longitude":"-61.20000000","timezones":[{"zoneName":"America/St_Vincent","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Saint-Barthelemy","isoCode":"BL","flag":"\uD83C\uDDE7\uD83C\uDDF1","phonecode":"590","currency":"EUR","latitude":"18.50000000","longitude":"-63.41666666","timezones":[{"zoneName":"America/St_Barthelemy","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Saint-Martin (French part)","isoCode":"MF","flag":"\uD83C\uDDF2\uD83C\uDDEB","phonecode":"590","currency":"EUR","latitude":"18.08333333","longitude":"-63.95000000","timezones":[{"zoneName":"America/Marigot","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Samoa","isoCode":"WS","flag":"\uD83C\uDDFC\uD83C\uDDF8","phonecode":"685","currency":"WST","latitude":"-13.58333333","longitude":"-172.33333333","timezones":[{"zoneName":"Pacific/Apia","gmtOffset":50400,"gmtOffsetName":"UTC+14:00","abbreviation":"WST","tzName":"West Samoa Time"}]},{"name":"San Marino","isoCode":"SM","flag":"\uD83C\uDDF8\uD83C\uDDF2","phonecode":"378","currency":"EUR","latitude":"43.76666666","longitude":"12.41666666","timezones":[{"zoneName":"Europe/San_Marino","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Sao Tome and Principe","isoCode":"ST","flag":"\uD83C\uDDF8\uD83C\uDDF9","phonecode":"239","currency":"STD","latitude":"1.00000000","longitude":"7.00000000","timezones":[{"zoneName":"Africa/Sao_Tome","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Saudi Arabia","isoCode":"SA","flag":"\uD83C\uDDF8\uD83C\uDDE6","phonecode":"966","currency":"SAR","latitude":"25.00000000","longitude":"45.00000000","timezones":[{"zoneName":"Asia/Riyadh","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"AST","tzName":"Arabia Standard Time"}]},{"name":"Senegal","isoCode":"SN","flag":"\uD83C\uDDF8\uD83C\uDDF3","phonecode":"221","currency":"XOF","latitude":"14.00000000","longitude":"-14.00000000","timezones":[{"zoneName":"Africa/Dakar","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Serbia","isoCode":"RS","flag":"\uD83C\uDDF7\uD83C\uDDF8","phonecode":"381","currency":"RSD","latitude":"44.00000000","longitude":"21.00000000","timezones":[{"zoneName":"Europe/Belgrade","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Seychelles","isoCode":"SC","flag":"\uD83C\uDDF8\uD83C\uDDE8","phonecode":"248","currency":"SCR","latitude":"-4.58333333","longitude":"55.66666666","timezones":[{"zoneName":"Indian/Mahe","gmtOffset":14400,"gmtOffsetName":"UTC+04:00","abbreviation":"SCT","tzName":"Seychelles Time"}]},{"name":"Sierra Leone","isoCode":"SL","flag":"\uD83C\uDDF8\uD83C\uDDF1","phonecode":"232","currency":"SLL","latitude":"8.50000000","longitude":"-11.50000000","timezones":[{"zoneName":"Africa/Freetown","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Singapore","isoCode":"SG","flag":"\uD83C\uDDF8\uD83C\uDDEC","phonecode":"65","currency":"SGD","latitude":"1.36666666","longitude":"103.80000000","timezones":[{"zoneName":"Asia/Singapore","gmtOffset":28800,"gmtOffsetName":"UTC+08:00","abbreviation":"SGT","tzName":"Singapore Time"}]},{"name":"Slovakia","isoCode":"SK","flag":"\uD83C\uDDF8\uD83C\uDDF0","phonecode":"421","currency":"EUR","latitude":"48.66666666","longitude":"19.50000000","timezones":[{"zoneName":"Europe/Bratislava","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Slovenia","isoCode":"SI","flag":"\uD83C\uDDF8\uD83C\uDDEE","phonecode":"386","currency":"EUR","latitude":"46.11666666","longitude":"14.81666666","timezones":[{"zoneName":"Europe/Ljubljana","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Solomon Islands","isoCode":"SB","flag":"\uD83C\uDDF8\uD83C\uDDE7","phonecode":"677","currency":"SBD","latitude":"-8.00000000","longitude":"159.00000000","timezones":[{"zoneName":"Pacific/Guadalcanal","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"SBT","tzName":"Solomon Islands Time"}]},{"name":"Somalia","isoCode":"SO","flag":"\uD83C\uDDF8\uD83C\uDDF4","phonecode":"252","currency":"SOS","latitude":"10.00000000","longitude":"49.00000000","timezones":[{"zoneName":"Africa/Mogadishu","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"EAT","tzName":"East Africa Time"}]},{"name":"South Africa","isoCode":"ZA","flag":"\uD83C\uDDFF\uD83C\uDDE6","phonecode":"27","currency":"ZAR","latitude":"-29.00000000","longitude":"24.00000000","timezones":[{"zoneName":"Africa/Johannesburg","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"SAST","tzName":"South African Standard Time"}]},{"name":"South Georgia","isoCode":"GS","flag":"\uD83C\uDDEC\uD83C\uDDF8","phonecode":"500","currency":"GBP","latitude":"-54.50000000","longitude":"-37.00000000","timezones":[{"zoneName":"Atlantic/South_Georgia","gmtOffset":-7200,"gmtOffsetName":"UTC-02:00","abbreviation":"GST","tzName":"South Georgia and the South Sandwich Islands Time"}]},{"name":"South Sudan","isoCode":"SS","flag":"\uD83C\uDDF8\uD83C\uDDF8","phonecode":"211","currency":"SSP","latitude":"7.00000000","longitude":"30.00000000","timezones":[{"zoneName":"Africa/Juba","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"EAT","tzName":"East Africa Time"}]},{"name":"Spain","isoCode":"ES","flag":"\uD83C\uDDEA\uD83C\uDDF8","phonecode":"34","currency":"EUR","latitude":"40.00000000","longitude":"-4.00000000","timezones":[{"zoneName":"Africa/Ceuta","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"},{"zoneName":"Atlantic/Canary","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"WET","tzName":"Western European Time"},{"zoneName":"Europe/Madrid","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Sri Lanka","isoCode":"LK","flag":"\uD83C\uDDF1\uD83C\uDDF0","phonecode":"94","currency":"LKR","latitude":"7.00000000","longitude":"81.00000000","timezones":[{"zoneName":"Asia/Colombo","gmtOffset":19800,"gmtOffsetName":"UTC+05:30","abbreviation":"IST","tzName":"Indian Standard Time"}]},{"name":"Sudan","isoCode":"SD","flag":"\uD83C\uDDF8\uD83C\uDDE9","phonecode":"249","currency":"SDG","latitude":"15.00000000","longitude":"30.00000000","timezones":[{"zoneName":"Africa/Khartoum","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EAT","tzName":"Eastern African Time"}]},{"name":"Suriname","isoCode":"SR","flag":"\uD83C\uDDF8\uD83C\uDDF7","phonecode":"597","currency":"SRD","latitude":"4.00000000","longitude":"-56.00000000","timezones":[{"zoneName":"America/Paramaribo","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"SRT","tzName":"Suriname Time"}]},{"name":"Svalbard And Jan Mayen Islands","isoCode":"SJ","flag":"\uD83C\uDDF8\uD83C\uDDEF","phonecode":"47","currency":"NOK","latitude":"78.00000000","longitude":"20.00000000","timezones":[{"zoneName":"Arctic/Longyearbyen","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Swaziland","isoCode":"SZ","flag":"\uD83C\uDDF8\uD83C\uDDFF","phonecode":"268","currency":"SZL","latitude":"-26.50000000","longitude":"31.50000000","timezones":[{"zoneName":"Africa/Mbabane","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"SAST","tzName":"South African Standard Time"}]},{"name":"Sweden","isoCode":"SE","flag":"\uD83C\uDDF8\uD83C\uDDEA","phonecode":"46","currency":"SEK","latitude":"62.00000000","longitude":"15.00000000","timezones":[{"zoneName":"Europe/Stockholm","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Switzerland","isoCode":"CH","flag":"\uD83C\uDDE8\uD83C\uDDED","phonecode":"41","currency":"CHF","latitude":"47.00000000","longitude":"8.00000000","timezones":[{"zoneName":"Europe/Zurich","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Syria","isoCode":"SY","flag":"\uD83C\uDDF8\uD83C\uDDFE","phonecode":"963","currency":"SYP","latitude":"35.00000000","longitude":"38.00000000","timezones":[{"zoneName":"Asia/Damascus","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Taiwan","isoCode":"TW","flag":"\uD83C\uDDF9\uD83C\uDDFC","phonecode":"886","currency":"TWD","latitude":"23.50000000","longitude":"121.00000000","timezones":[{"zoneName":"Asia/Taipei","gmtOffset":28800,"gmtOffsetName":"UTC+08:00","abbreviation":"CST","tzName":"China Standard Time"}]},{"name":"Tajikistan","isoCode":"TJ","flag":"\uD83C\uDDF9\uD83C\uDDEF","phonecode":"992","currency":"TJS","latitude":"39.00000000","longitude":"71.00000000","timezones":[{"zoneName":"Asia/Dushanbe","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"TJT","tzName":"Tajikistan Time"}]},{"name":"Tanzania","isoCode":"TZ","flag":"\uD83C\uDDF9\uD83C\uDDFF","phonecode":"255","currency":"TZS","latitude":"-6.00000000","longitude":"35.00000000","timezones":[{"zoneName":"Africa/Dar_es_Salaam","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"EAT","tzName":"East Africa Time"}]},{"name":"Thailand","isoCode":"TH","flag":"\uD83C\uDDF9\uD83C\uDDED","phonecode":"66","currency":"THB","latitude":"15.00000000","longitude":"100.00000000","timezones":[{"zoneName":"Asia/Bangkok","gmtOffset":25200,"gmtOffsetName":"UTC+07:00","abbreviation":"ICT","tzName":"Indochina Time"}]},{"name":"Togo","isoCode":"TG","flag":"\uD83C\uDDF9\uD83C\uDDEC","phonecode":"228","currency":"XOF","latitude":"8.00000000","longitude":"1.16666666","timezones":[{"zoneName":"Africa/Lome","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"Tokelau","isoCode":"TK","flag":"\uD83C\uDDF9\uD83C\uDDF0","phonecode":"690","currency":"NZD","latitude":"-9.00000000","longitude":"-172.00000000","timezones":[{"zoneName":"Pacific/Fakaofo","gmtOffset":46800,"gmtOffsetName":"UTC+13:00","abbreviation":"TKT","tzName":"Tokelau Time"}]},{"name":"Tonga","isoCode":"TO","flag":"\uD83C\uDDF9\uD83C\uDDF4","phonecode":"676","currency":"TOP","latitude":"-20.00000000","longitude":"-175.00000000","timezones":[{"zoneName":"Pacific/Tongatapu","gmtOffset":46800,"gmtOffsetName":"UTC+13:00","abbreviation":"TOT","tzName":"Tonga Time"}]},{"name":"Trinidad And Tobago","isoCode":"TT","flag":"\uD83C\uDDF9\uD83C\uDDF9","phonecode":"+1-868","currency":"TTD","latitude":"11.00000000","longitude":"-61.00000000","timezones":[{"zoneName":"America/Port_of_Spain","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Tunisia","isoCode":"TN","flag":"\uD83C\uDDF9\uD83C\uDDF3","phonecode":"216","currency":"TND","latitude":"34.00000000","longitude":"9.00000000","timezones":[{"zoneName":"Africa/Tunis","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Turkey","isoCode":"TR","flag":"\uD83C\uDDF9\uD83C\uDDF7","phonecode":"90","currency":"TRY","latitude":"39.00000000","longitude":"35.00000000","timezones":[{"zoneName":"Europe/Istanbul","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"Turkmenistan","isoCode":"TM","flag":"\uD83C\uDDF9\uD83C\uDDF2","phonecode":"993","currency":"TMT","latitude":"40.00000000","longitude":"60.00000000","timezones":[{"zoneName":"Asia/Ashgabat","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"TMT","tzName":"Turkmenistan Time"}]},{"name":"Turks And Caicos Islands","isoCode":"TC","flag":"\uD83C\uDDF9\uD83C\uDDE8","phonecode":"+1-649","currency":"USD","latitude":"21.75000000","longitude":"-71.58333333","timezones":[{"zoneName":"America/Grand_Turk","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"}]},{"name":"Tuvalu","isoCode":"TV","flag":"\uD83C\uDDF9\uD83C\uDDFB","phonecode":"688","currency":"AUD","latitude":"-8.00000000","longitude":"178.00000000","timezones":[{"zoneName":"Pacific/Funafuti","gmtOffset":43200,"gmtOffsetName":"UTC+12:00","abbreviation":"TVT","tzName":"Tuvalu Time"}]},{"name":"Uganda","isoCode":"UG","flag":"\uD83C\uDDFA\uD83C\uDDEC","phonecode":"256","currency":"UGX","latitude":"1.00000000","longitude":"32.00000000","timezones":[{"zoneName":"Africa/Kampala","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"EAT","tzName":"East Africa Time"}]},{"name":"Ukraine","isoCode":"UA","flag":"\uD83C\uDDFA\uD83C\uDDE6","phonecode":"380","currency":"UAH","latitude":"49.00000000","longitude":"32.00000000","timezones":[{"zoneName":"Europe/Kiev","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"},{"zoneName":"Europe/Simferopol","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"MSK","tzName":"Moscow Time"},{"zoneName":"Europe/Uzhgorod","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"},{"zoneName":"Europe/Zaporozhye","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"EET","tzName":"Eastern European Time"}]},{"name":"United Arab Emirates","isoCode":"AE","flag":"\uD83C\uDDE6\uD83C\uDDEA","phonecode":"971","currency":"AED","latitude":"24.00000000","longitude":"54.00000000","timezones":[{"zoneName":"Asia/Dubai","gmtOffset":14400,"gmtOffsetName":"UTC+04:00","abbreviation":"GST","tzName":"Gulf Standard Time"}]},{"name":"United Kingdom","isoCode":"GB","flag":"\uD83C\uDDEC\uD83C\uDDE7","phonecode":"44","currency":"GBP","latitude":"54.00000000","longitude":"-2.00000000","timezones":[{"zoneName":"Europe/London","gmtOffset":0,"gmtOffsetName":"UTC\xb100","abbreviation":"GMT","tzName":"Greenwich Mean Time"}]},{"name":"United States","isoCode":"US","flag":"\uD83C\uDDFA\uD83C\uDDF8","phonecode":"1","currency":"USD","latitude":"38.00000000","longitude":"-97.00000000","timezones":[{"zoneName":"America/Adak","gmtOffset":-36000,"gmtOffsetName":"UTC-10:00","abbreviation":"HST","tzName":"Hawaii–Aleutian Standard Time"},{"zoneName":"America/Anchorage","gmtOffset":-32400,"gmtOffsetName":"UTC-09:00","abbreviation":"AKST","tzName":"Alaska Standard Time"},{"zoneName":"America/Boise","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America"},{"zoneName":"America/Chicago","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Denver","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America"},{"zoneName":"America/Detroit","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Indiana/Indianapolis","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Indiana/Knox","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Indiana/Marengo","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Indiana/Petersburg","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Indiana/Tell_City","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Indiana/Vevay","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Indiana/Vincennes","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Indiana/Winamac","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Juneau","gmtOffset":-32400,"gmtOffsetName":"UTC-09:00","abbreviation":"AKST","tzName":"Alaska Standard Time"},{"zoneName":"America/Kentucky/Louisville","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Kentucky/Monticello","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Los_Angeles","gmtOffset":-28800,"gmtOffsetName":"UTC-08:00","abbreviation":"PST","tzName":"Pacific Standard Time (North America"},{"zoneName":"America/Menominee","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Metlakatla","gmtOffset":-32400,"gmtOffsetName":"UTC-09:00","abbreviation":"AKST","tzName":"Alaska Standard Time"},{"zoneName":"America/New_York","gmtOffset":-18000,"gmtOffsetName":"UTC-05:00","abbreviation":"EST","tzName":"Eastern Standard Time (North America"},{"zoneName":"America/Nome","gmtOffset":-32400,"gmtOffsetName":"UTC-09:00","abbreviation":"AKST","tzName":"Alaska Standard Time"},{"zoneName":"America/North_Dakota/Beulah","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/North_Dakota/Center","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/North_Dakota/New_Salem","gmtOffset":-21600,"gmtOffsetName":"UTC-06:00","abbreviation":"CST","tzName":"Central Standard Time (North America"},{"zoneName":"America/Phoenix","gmtOffset":-25200,"gmtOffsetName":"UTC-07:00","abbreviation":"MST","tzName":"Mountain Standard Time (North America"},{"zoneName":"America/Sitka","gmtOffset":-32400,"gmtOffsetName":"UTC-09:00","abbreviation":"AKST","tzName":"Alaska Standard Time"},{"zoneName":"America/Yakutat","gmtOffset":-32400,"gmtOffsetName":"UTC-09:00","abbreviation":"AKST","tzName":"Alaska Standard Time"},{"zoneName":"Pacific/Honolulu","gmtOffset":-36000,"gmtOffsetName":"UTC-10:00","abbreviation":"HST","tzName":"Hawaii–Aleutian Standard Time"}]},{"name":"United States Minor Outlying Islands","isoCode":"UM","flag":"\uD83C\uDDFA\uD83C\uDDF2","phonecode":"1","currency":"USD","latitude":"0.00000000","longitude":"0.00000000","timezones":[{"zoneName":"Pacific/Midway","gmtOffset":-39600,"gmtOffsetName":"UTC-11:00","abbreviation":"SST","tzName":"Samoa Standard Time"},{"zoneName":"Pacific/Wake","gmtOffset":43200,"gmtOffsetName":"UTC+12:00","abbreviation":"WAKT","tzName":"Wake Island Time"}]},{"name":"Uruguay","isoCode":"UY","flag":"\uD83C\uDDFA\uD83C\uDDFE","phonecode":"598","currency":"UYU","latitude":"-33.00000000","longitude":"-56.00000000","timezones":[{"zoneName":"America/Montevideo","gmtOffset":-10800,"gmtOffsetName":"UTC-03:00","abbreviation":"UYT","tzName":"Uruguay Standard Time"}]},{"name":"Uzbekistan","isoCode":"UZ","flag":"\uD83C\uDDFA\uD83C\uDDFF","phonecode":"998","currency":"UZS","latitude":"41.00000000","longitude":"64.00000000","timezones":[{"zoneName":"Asia/Samarkand","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"UZT","tzName":"Uzbekistan Time"},{"zoneName":"Asia/Tashkent","gmtOffset":18000,"gmtOffsetName":"UTC+05:00","abbreviation":"UZT","tzName":"Uzbekistan Time"}]},{"name":"Vanuatu","isoCode":"VU","flag":"\uD83C\uDDFB\uD83C\uDDFA","phonecode":"678","currency":"VUV","latitude":"-16.00000000","longitude":"167.00000000","timezones":[{"zoneName":"Pacific/Efate","gmtOffset":39600,"gmtOffsetName":"UTC+11:00","abbreviation":"VUT","tzName":"Vanuatu Time"}]},{"name":"Vatican City State (Holy See)","isoCode":"VA","flag":"\uD83C\uDDFB\uD83C\uDDE6","phonecode":"379","currency":"EUR","latitude":"41.90000000","longitude":"12.45000000","timezones":[{"zoneName":"Europe/Vatican","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Venezuela","isoCode":"VE","flag":"\uD83C\uDDFB\uD83C\uDDEA","phonecode":"58","currency":"VEF","latitude":"8.00000000","longitude":"-66.00000000","timezones":[{"zoneName":"America/Caracas","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"VET","tzName":"Venezuelan Standard Time"}]},{"name":"Vietnam","isoCode":"VN","flag":"\uD83C\uDDFB\uD83C\uDDF3","phonecode":"84","currency":"VND","latitude":"16.16666666","longitude":"107.83333333","timezones":[{"zoneName":"Asia/Ho_Chi_Minh","gmtOffset":25200,"gmtOffsetName":"UTC+07:00","abbreviation":"ICT","tzName":"Indochina Time"}]},{"name":"Virgin Islands (British)","isoCode":"VG","flag":"\uD83C\uDDFB\uD83C\uDDEC","phonecode":"+1-284","currency":"USD","latitude":"18.43138300","longitude":"-64.62305000","timezones":[{"zoneName":"America/Tortola","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Virgin Islands (US)","isoCode":"VI","flag":"\uD83C\uDDFB\uD83C\uDDEE","phonecode":"+1-340","currency":"USD","latitude":"18.34000000","longitude":"-64.93000000","timezones":[{"zoneName":"America/St_Thomas","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Wallis And Futuna Islands","isoCode":"WF","flag":"\uD83C\uDDFC\uD83C\uDDEB","phonecode":"681","currency":"XPF","latitude":"-13.30000000","longitude":"-176.20000000","timezones":[{"zoneName":"Pacific/Wallis","gmtOffset":43200,"gmtOffsetName":"UTC+12:00","abbreviation":"WFT","tzName":"Wallis & Futuna Time"}]},{"name":"Western Sahara","isoCode":"EH","flag":"\uD83C\uDDEA\uD83C\uDDED","phonecode":"212","currency":"MAD","latitude":"24.50000000","longitude":"-13.00000000","timezones":[{"zoneName":"Africa/El_Aaiun","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"WEST","tzName":"Western European Summer Time"}]},{"name":"Yemen","isoCode":"YE","flag":"\uD83C\uDDFE\uD83C\uDDEA","phonecode":"967","currency":"YER","latitude":"15.00000000","longitude":"48.00000000","timezones":[{"zoneName":"Asia/Aden","gmtOffset":10800,"gmtOffsetName":"UTC+03:00","abbreviation":"AST","tzName":"Arabia Standard Time"}]},{"name":"Zambia","isoCode":"ZM","flag":"\uD83C\uDDFF\uD83C\uDDF2","phonecode":"260","currency":"ZMW","latitude":"-15.00000000","longitude":"30.00000000","timezones":[{"zoneName":"Africa/Lusaka","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"CAT","tzName":"Central Africa Time"}]},{"name":"Zimbabwe","isoCode":"ZW","flag":"\uD83C\uDDFF\uD83C\uDDFC","phonecode":"263","currency":"ZWL","latitude":"-20.00000000","longitude":"30.00000000","timezones":[{"zoneName":"Africa/Harare","gmtOffset":7200,"gmtOffsetName":"UTC+02:00","abbreviation":"CAT","tzName":"Central Africa Time"}]},{"name":"Kosovo","isoCode":"XK","flag":"\uD83C\uDDFD\uD83C\uDDF0","phonecode":"383","currency":"EUR","latitude":"42.56129090","longitude":"20.34030350","timezones":[{"zoneName":"Europe/Belgrade","gmtOffset":3600,"gmtOffsetName":"UTC+01:00","abbreviation":"CET","tzName":"Central European Time"}]},{"name":"Cura\xe7ao","isoCode":"CW","flag":"\uD83C\uDDE8\uD83C\uDDFC","phonecode":"599","currency":"ANG","latitude":"12.11666700","longitude":"-68.93333300","timezones":[{"zoneName":"America/Curacao","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]},{"name":"Sint Maarten (Dutch part)","isoCode":"SX","flag":"\uD83C\uDDF8\uD83C\uDDFD","phonecode":"1721","currency":"ANG","latitude":"18.03333300","longitude":"-63.05000000","timezones":[{"zoneName":"America/Anguilla","gmtOffset":-14400,"gmtOffsetName":"UTC-04:00","abbreviation":"AST","tzName":"Atlantic Standard Time"}]}]');
            let i = (e, t) => {
                    if (t && null != e) {
                        let n = e.findIndex(e => e.isoCode === t);
                        return -1 !== n ? e[n] : void 0
                    }
                },
                o = (e, t, n) => {
                    if (t && n && null != e) {
                        let a = e.findIndex(e => e.isoCode === t && e.countryCode === n);
                        return -1 !== a ? e[a] : void 0
                    }
                },
                r = (e, t) => e.name < t.name ? -1 : e.name > t.name ? 1 : 0;
            var s = {
                    getCountryByCode: function(e) {
                        if (e) return i(a, e)
                    },
                    getAllCountries: function() {
                        return a
                    }
                },
                m = n(90640),
                u = {
                    getAllStates: function() {
                        return m
                    },
                    getStatesOfCountry: function(e = "") {
                        if (!e) return [];
                        let t = m.filter(t => t.countryCode === e);
                        return t.sort(r)
                    },
                    getStateByCodeAndCountry: function(e, t) {
                        if (e && t) return o(m, e, t)
                    },
                    getStateByCode: function(e) {
                        if (console.warn("WARNING! 'getStateByCode' has been deprecated, please use the new 'getStateByCodeAndCountry' function instead!"), e) return i(m, e)
                    }
                },
                l = n(41413),
                c = {
                    getAllCities: function() {
                        return l
                    },
                    getCitiesOfState: function(e, t) {
                        if (!t || !e) return [];
                        let n = l.filter(n => n.countryCode === e && n.stateCode === t);
                        return n.sort(r)
                    },
                    getCitiesOfCountry: function(e) {
                        if (!e) return [];
                        let t = l.filter(t => t.countryCode === e);
                        return t.sort(r)
                    }
                }
        },
        8679: function(e, t, n) {
            "use strict";
            var a = n(59864),
                i = {
                    childContextTypes: !0,
                    contextType: !0,
                    contextTypes: !0,
                    defaultProps: !0,
                    displayName: !0,
                    getDefaultProps: !0,
                    getDerivedStateFromError: !0,
                    getDerivedStateFromProps: !0,
                    mixins: !0,
                    propTypes: !0,
                    type: !0
                },
                o = {
                    name: !0,
                    length: !0,
                    prototype: !0,
                    caller: !0,
                    callee: !0,
                    arguments: !0,
                    arity: !0
                },
                r = {
                    $$typeof: !0,
                    compare: !0,
                    defaultProps: !0,
                    displayName: !0,
                    propTypes: !0,
                    type: !0
                },
                s = {};

            function m(e) {
                return a.isMemo(e) ? r : s[e.$$typeof] || i
            }
            s[a.ForwardRef] = {
                $$typeof: !0,
                render: !0,
                defaultProps: !0,
                displayName: !0,
                propTypes: !0
            }, s[a.Memo] = r;
            var u = Object.defineProperty,
                l = Object.getOwnPropertyNames,
                c = Object.getOwnPropertySymbols,
                f = Object.getOwnPropertyDescriptor,
                d = Object.getPrototypeOf,
                g = Object.prototype;
            e.exports = function e(t, n, a) {
                if ("string" != typeof n) {
                    if (g) {
                        var i = d(n);
                        i && i !== g && e(t, i, a)
                    }
                    var r = l(n);
                    c && (r = r.concat(c(n)));
                    for (var s = m(t), p = m(n), b = 0; b < r.length; ++b) {
                        var h = r[b];
                        if (!o[h] && !(a && a[h]) && !(p && p[h]) && !(s && s[h])) {
                            var T = f(n, h);
                            try {
                                u(t, h, T)
                            } catch (N) {}
                        }
                    }
                }
                return t
            }
        },
        19749: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "ImageLoaderProps", {
                enumerable: !0,
                get: function() {
                    return l.ImageLoaderProps
                }
            }), t.default = function(e) {
                let t, n;
                var i, {
                        src: o,
                        sizes: b,
                        unoptimized: T = !1,
                        priority: N = !1,
                        loading: v,
                        className: C,
                        quality: O,
                        width: z,
                        height: y,
                        fill: A,
                        style: S,
                        onLoad: E,
                        onLoadingComplete: U,
                        placeholder: M = "empty",
                        blurDataURL: w,
                        layout: P,
                        objectFit: k,
                        objectPosition: I,
                        lazyBoundary: x,
                        lazyRoot: R
                    } = e,
                    D = r(e, ["src", "sizes", "unoptimized", "priority", "loading", "className", "quality", "width", "height", "fill", "style", "onLoad", "onLoadingComplete", "placeholder", "blurDataURL", "layout", "objectFit", "objectPosition", "lazyBoundary", "lazyRoot"]);
                let L = s.useContext(c.ImageConfigContext),
                    V = s.useMemo(() => {
                        let e = d || L || l.imageConfigDefault,
                            t = [...e.deviceSizes, ...e.imageSizes].sort((e, t) => e - t),
                            n = e.deviceSizes.sort((e, t) => e - t);
                        return a({}, e, {
                            allSizes: t,
                            deviceSizes: n
                        })
                    }, [L]),
                    B = D,
                    F = B.loader || f.default;
                if (delete B.loader, "__next_img_default" in F) {
                    if ("custom" === V.loader) throw Error('Image with src "'.concat(o, '" is missing "loader" prop.') + "\nRead more: https://nextjs.org/docs/messages/next-image-missing-loader")
                } else {
                    let G = F;
                    F = e => {
                        let {
                            config: t
                        } = e, n = r(e, ["config"]);
                        return G(n)
                    }
                }
                if (P) {
                    "fill" === P && (A = !0);
                    let H = {
                        intrinsic: {
                            maxWidth: "100%",
                            height: "auto"
                        },
                        responsive: {
                            width: "100%",
                            height: "auto"
                        }
                    }[P];
                    H && (S = a({}, S, H));
                    let _ = {
                        responsive: "100vw",
                        fill: "100vw"
                    }[P];
                    _ && !b && (b = _)
                }
                let j = "",
                    K = p(z),
                    W = p(y);
                if ("object" == typeof(i = o) && (g(i) || void 0 !== i.src)) {
                    let $ = g(o) ? o.default : o;
                    if (!$.src) throw Error("An object should only be passed to the image component src parameter if it comes from a static image import. It must include src. Received ".concat(JSON.stringify($)));
                    if (!$.height || !$.width) throw Error("An object should only be passed to the image component src parameter if it comes from a static image import. It must include height and width. Received ".concat(JSON.stringify($)));
                    if (t = $.blurWidth, n = $.blurHeight, w = w || $.blurDataURL, j = $.src, !A) {
                        if (K || W) {
                            if (K && !W) {
                                let Y = K / $.width;
                                W = Math.round($.height * Y)
                            } else if (!K && W) {
                                let Z = W / $.height;
                                K = Math.round($.width * Z)
                            }
                        } else K = $.width, W = $.height
                    }
                }
                let X = !N && ("lazy" === v || void 0 === v);
                ((o = "string" == typeof o ? o : j).startsWith("data:") || o.startsWith("blob:")) && (T = !0, X = !1), V.unoptimized && (T = !0);
                let [q, J] = s.useState(!1), [Q, ee] = s.useState(!1), et = p(O), en = Object.assign(A ? {
                    position: "absolute",
                    height: "100%",
                    width: "100%",
                    left: 0,
                    top: 0,
                    right: 0,
                    bottom: 0,
                    objectFit: k,
                    objectPosition: I
                } : {}, Q ? {} : {
                    color: "transparent"
                }, S), ea = "blur" === M && w && !q ? {
                    backgroundSize: en.objectFit || "cover",
                    backgroundPosition: en.objectPosition || "50% 50%",
                    backgroundRepeat: "no-repeat",
                    backgroundImage: 'url("data:image/svg+xml;charset=utf-8,'.concat(u.getImageBlurSvg({
                        widthInt: K,
                        heightInt: W,
                        blurWidth: t,
                        blurHeight: n,
                        blurDataURL: w
                    }), '")')
                } : {}, ei = function(e) {
                    let {
                        config: t,
                        src: n,
                        unoptimized: a,
                        width: i,
                        quality: o,
                        sizes: r,
                        loader: s
                    } = e;
                    if (a) return {
                        src: n,
                        srcSet: void 0,
                        sizes: void 0
                    };
                    let {
                        widths: m,
                        kind: u
                    } = function(e, t, n) {
                        let {
                            deviceSizes: a,
                            allSizes: i
                        } = e;
                        if (n) {
                            let o = /(^|\s)(1?\d?\d)vw/g,
                                r = [];
                            for (let s; s = o.exec(n); s) r.push(parseInt(s[2]));
                            if (r.length) {
                                let m = .01 * Math.min(...r);
                                return {
                                    widths: i.filter(e => e >= a[0] * m),
                                    kind: "w"
                                }
                            }
                            return {
                                widths: i,
                                kind: "w"
                            }
                        }
                        if ("number" != typeof t) return {
                            widths: a,
                            kind: "w"
                        };
                        let u = [...new Set([t, 2 * t].map(e => i.find(t => t >= e) || i[i.length - 1]))];
                        return {
                            widths: u,
                            kind: "x"
                        }
                    }(t, i, r), l = m.length - 1;
                    return {
                        sizes: r || "w" !== u ? r : "100vw",
                        srcSet: m.map((e, a) => "".concat(s({
                            config: t,
                            src: n,
                            quality: o,
                            width: e
                        }), " ").concat("w" === u ? e : a + 1).concat(u)).join(", "),
                        src: s({
                            config: t,
                            src: n,
                            quality: o,
                            width: m[l]
                        })
                    }
                }({
                    config: V,
                    src: o,
                    unoptimized: T,
                    width: K,
                    quality: et,
                    sizes: b,
                    loader: F
                }), eo = o, er = {
                    imageSrcSet: ei.srcSet,
                    imageSizes: ei.sizes,
                    crossOrigin: B.crossOrigin
                }, es = s.useRef(E);
                s.useEffect(() => {
                    es.current = E
                }, [E]);
                let em = s.useRef(U);
                s.useEffect(() => {
                    em.current = U
                }, [U]);
                let eu = a({
                    isLazy: X,
                    imgAttributes: ei,
                    heightInt: W,
                    widthInt: K,
                    qualityInt: et,
                    className: C,
                    imgStyle: en,
                    blurStyle: ea,
                    loading: v,
                    config: V,
                    fill: A,
                    unoptimized: T,
                    placeholder: M,
                    loader: F,
                    srcString: eo,
                    onLoadRef: es,
                    onLoadingCompleteRef: em,
                    setBlurComplete: J,
                    setShowAltText: ee
                }, B);
                return s.default.createElement(s.default.Fragment, null, s.default.createElement(h, Object.assign({}, eu)), N ? s.default.createElement(m.default, null, s.default.createElement("link", Object.assign({
                    key: "__nimg-" + ei.src + ei.srcSet + ei.sizes,
                    rel: "preload",
                    as: "image",
                    href: ei.srcSet ? void 0 : ei.src
                }, er))) : null)
            };
            var a = n(6495).Z,
                i = n(92648).Z,
                o = n(91598).Z,
                r = n(17273).Z,
                s = o(n(67294)),
                m = i(n(83121)),
                u = n(2675),
                l = n(10139),
                c = n(28730);
            n(57238);
            var f = i(n(89824));
            let d = {
                deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
                path: "/_next/image",
                loader: "default",
                dangerouslyAllowSVG: !1,
                unoptimized: !1
            };

            function g(e) {
                return void 0 !== e.default
            }

            function p(e) {
                return "number" == typeof e || void 0 === e ? e : "string" == typeof e && /^[0-9]+$/.test(e) ? parseInt(e, 10) : NaN
            }

            function b(e, t, n, i, o, r, s) {
                if (!e || e["data-loaded-src"] === t) return;
                e["data-loaded-src"] = t;
                let m = "decode" in e ? e.decode() : Promise.resolve();
                m.catch(() => {}).then(() => {
                    if (e.parentNode) {
                        if ("blur" === n && r(!0), null == i ? void 0 : i.current) {
                            let t = new Event("load");
                            Object.defineProperty(t, "target", {
                                writable: !1,
                                value: e
                            });
                            let s = !1,
                                m = !1;
                            i.current(a({}, t, {
                                nativeEvent: t,
                                currentTarget: e,
                                target: e,
                                isDefaultPrevented: () => s,
                                isPropagationStopped: () => m,
                                persist() {},
                                preventDefault() {
                                    s = !0, t.preventDefault()
                                },
                                stopPropagation() {
                                    m = !0, t.stopPropagation()
                                }
                            }))
                        }(null == o ? void 0 : o.current) && o.current(e)
                    }
                })
            }
            let h = e => {
                var {
                    imgAttributes: t,
                    heightInt: n,
                    widthInt: i,
                    qualityInt: o,
                    className: m,
                    imgStyle: u,
                    blurStyle: l,
                    isLazy: c,
                    fill: f,
                    placeholder: d,
                    loading: g,
                    srcString: p,
                    config: h,
                    unoptimized: T,
                    loader: N,
                    onLoadRef: v,
                    onLoadingCompleteRef: C,
                    setBlurComplete: O,
                    setShowAltText: z,
                    onLoad: y,
                    onError: A
                } = e, S = r(e, ["imgAttributes", "heightInt", "widthInt", "qualityInt", "className", "imgStyle", "blurStyle", "isLazy", "fill", "placeholder", "loading", "srcString", "config", "unoptimized", "loader", "onLoadRef", "onLoadingCompleteRef", "setBlurComplete", "setShowAltText", "onLoad", "onError"]);
                return g = c ? "lazy" : g, s.default.createElement(s.default.Fragment, null, s.default.createElement("img", Object.assign({}, S, t, {
                    width: i,
                    height: n,
                    decoding: "async",
                    "data-nimg": f ? "fill" : "1",
                    className: m,
                    loading: g,
                    style: a({}, u, l),
                    ref: s.useCallback(e => {
                        e && (A && (e.src = e.src), e.complete && b(e, p, d, v, C, O, T))
                    }, [p, d, v, C, O, A, T]),
                    onLoad(e) {
                        let t = e.currentTarget;
                        b(t, p, d, v, C, O, T)
                    },
                    onError(e) {
                        z(!0), "blur" === d && O(!0), A && A(e)
                    }
                })))
            };
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        2675: function(e, t) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.getImageBlurSvg = function(e) {
                let {
                    widthInt: t,
                    heightInt: n,
                    blurWidth: a,
                    blurHeight: i,
                    blurDataURL: o
                } = e, r = a || t, s = i || n, m = o.startsWith("data:image/jpeg") ? "%3CfeComponentTransfer%3E%3CfeFuncA type='discrete' tableValues='1 1'/%3E%3C/feComponentTransfer%3E%" : "";
                return r && s ? "%3Csvg xmlns='http%3A//www.w3.org/2000/svg' viewBox='0 0 ".concat(r, " ").concat(s, "'%3E%3Cfilter id='b' color-interpolation-filters='sRGB'%3E%3CfeGaussianBlur stdDeviation='").concat(a && i ? "1" : "20", "'/%3E").concat(m, "%3C/filter%3E%3Cimage preserveAspectRatio='none' filter='url(%23b)' x='0' y='0' height='100%25' width='100%25' href='").concat(o, "'/%3E%3C/svg%3E") : "%3Csvg xmlns='http%3A//www.w3.org/2000/svg'%3E%3Cimage style='filter:blur(20px)' x='0' y='0' height='100%25' width='100%25' href='".concat(o, "'/%3E%3C/svg%3E")
            }
        },
        89824: function(e, t) {
            "use strict";

            function n(e) {
                let {
                    config: t,
                    src: n,
                    width: a,
                    quality: i
                } = e;
                return n.endsWith(".svg") && !t.dangerouslyAllowSVG ? n : "".concat(t.path, "?url=").concat(encodeURIComponent(n), "&w=").concat(a, "&q=").concat(i || 75)
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0, n.__next_img_default = !0, t.default = n
        },
        25675: function(e, t, n) {
            e.exports = n(19749)
        },
        92703: function(e, t, n) {
            "use strict";
            var a = n(50414);

            function i() {}

            function o() {}
            o.resetWarningCache = i, e.exports = function() {
                function e(e, t, n, i, o, r) {
                    if (r !== a) {
                        var s = Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
                        throw s.name = "Invariant Violation", s
                    }
                }

                function t() {
                    return e
                }
                e.isRequired = e;
                var n = {
                    array: e,
                    bigint: e,
                    bool: e,
                    func: e,
                    number: e,
                    object: e,
                    string: e,
                    symbol: e,
                    any: e,
                    arrayOf: t,
                    element: e,
                    elementType: e,
                    instanceOf: t,
                    node: e,
                    objectOf: t,
                    oneOf: t,
                    oneOfType: t,
                    shape: t,
                    exact: t,
                    checkPropTypes: o,
                    resetWarningCache: i
                };
                return n.PropTypes = n, n
            }
        },
        45697: function(e, t, n) {
            e.exports = n(92703)()
        },
        50414: function(e) {
            "use strict";
            e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"
        },
        69921: function(e, t) {
            "use strict";
            /** @license React v16.13.1
             * react-is.production.min.js
             *
             * Copyright (c) Facebook, Inc. and its affiliates.
             *
             * This source code is licensed under the MIT license found in the
             * LICENSE file in the root directory of this source tree.
             */
            var n = "function" == typeof Symbol && Symbol.for,
                a = n ? Symbol.for("react.element") : 60103,
                i = n ? Symbol.for("react.portal") : 60106,
                o = n ? Symbol.for("react.fragment") : 60107,
                r = n ? Symbol.for("react.strict_mode") : 60108,
                s = n ? Symbol.for("react.profiler") : 60114,
                m = n ? Symbol.for("react.provider") : 60109,
                u = n ? Symbol.for("react.context") : 60110,
                l = n ? Symbol.for("react.async_mode") : 60111,
                c = n ? Symbol.for("react.concurrent_mode") : 60111,
                f = n ? Symbol.for("react.forward_ref") : 60112,
                d = n ? Symbol.for("react.suspense") : 60113,
                g = n ? Symbol.for("react.suspense_list") : 60120,
                p = n ? Symbol.for("react.memo") : 60115,
                b = n ? Symbol.for("react.lazy") : 60116,
                h = n ? Symbol.for("react.block") : 60121,
                T = n ? Symbol.for("react.fundamental") : 60117,
                N = n ? Symbol.for("react.responder") : 60118,
                v = n ? Symbol.for("react.scope") : 60119;

            function C(e) {
                if ("object" == typeof e && null !== e) {
                    var t = e.$$typeof;
                    switch (t) {
                        case a:
                            switch (e = e.type) {
                                case l:
                                case c:
                                case o:
                                case s:
                                case r:
                                case d:
                                    return e;
                                default:
                                    switch (e = e && e.$$typeof) {
                                        case u:
                                        case f:
                                        case b:
                                        case p:
                                        case m:
                                            return e;
                                        default:
                                            return t
                                    }
                            }
                        case i:
                            return t
                    }
                }
            }

            function O(e) {
                return C(e) === c
            }
            t.AsyncMode = l, t.ConcurrentMode = c, t.ContextConsumer = u, t.ContextProvider = m, t.Element = a, t.ForwardRef = f, t.Fragment = o, t.Lazy = b, t.Memo = p, t.Portal = i, t.Profiler = s, t.StrictMode = r, t.Suspense = d, t.isAsyncMode = function(e) {
                return O(e) || C(e) === l
            }, t.isConcurrentMode = O, t.isContextConsumer = function(e) {
                return C(e) === u
            }, t.isContextProvider = function(e) {
                return C(e) === m
            }, t.isElement = function(e) {
                return "object" == typeof e && null !== e && e.$$typeof === a
            }, t.isForwardRef = function(e) {
                return C(e) === f
            }, t.isFragment = function(e) {
                return C(e) === o
            }, t.isLazy = function(e) {
                return C(e) === b
            }, t.isMemo = function(e) {
                return C(e) === p
            }, t.isPortal = function(e) {
                return C(e) === i
            }, t.isProfiler = function(e) {
                return C(e) === s
            }, t.isStrictMode = function(e) {
                return C(e) === r
            }, t.isSuspense = function(e) {
                return C(e) === d
            }, t.isValidElementType = function(e) {
                return "string" == typeof e || "function" == typeof e || e === o || e === c || e === s || e === r || e === d || e === g || "object" == typeof e && null !== e && (e.$$typeof === b || e.$$typeof === p || e.$$typeof === m || e.$$typeof === u || e.$$typeof === f || e.$$typeof === T || e.$$typeof === N || e.$$typeof === v || e.$$typeof === h)
            }, t.typeOf = C
        },
        59864: function(e, t, n) {
            "use strict";
            e.exports = n(69921)
        },
        37038: function(e, t, n) {
            "use strict";
            let a;

            function i(e) {
                return (i = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                    return typeof e
                } : function(e) {
                    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                })(e)
            }

            function o(e) {
                var t = function(e, t) {
                    if ("object" !== i(e) || null === e) return e;
                    var n = e[Symbol.toPrimitive];
                    if (void 0 !== n) {
                        var a = n.call(e, t || "default");
                        if ("object" !== i(a)) return a;
                        throw TypeError("@@toPrimitive must return a primitive value.")
                    }
                    return ("string" === t ? String : Number)(e)
                }(e, "string");
                return "symbol" === i(t) ? t : String(t)
            }

            function r(e, t, n) {
                return (t = o(t)) in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e
            }

            function s(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(e);
                    t && (a = a.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    })), n.push.apply(n, a)
                }
                return n
            }

            function m(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? s(Object(n), !0).forEach(function(t) {
                        r(e, t, n[t])
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                    })
                }
                return e
            }

            function u(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, a = Array(t); n < t; n++) a[n] = e[n];
                return a
            }

            function l(e, t) {
                if (e) {
                    if ("string" == typeof e) return u(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    if ("Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n) return Array.from(e);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return u(e, t)
                }
            }

            function c(e, t) {
                return function(e) {
                    if (Array.isArray(e)) return e
                }(e) || function(e, t) {
                    var n = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != n) {
                        var a, i, o, r, s = [],
                            m = !0,
                            u = !1;
                        try {
                            if (o = (n = n.call(e)).next, 0 === t) {
                                if (Object(n) !== n) return;
                                m = !1
                            } else
                                for (; !(m = (a = o.call(n)).done) && (s.push(a.value), s.length !== t); m = !0);
                        } catch (l) {
                            u = !0, i = l
                        } finally {
                            try {
                                if (!m && null != n.return && (r = n.return(), Object(r) !== r)) return
                            } finally {
                                if (u) throw i
                            }
                        }
                        return s
                    }
                }(e, t) || l(e, t) || function() {
                    throw TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }

            function f(e, t) {
                if (null == e) return {};
                var n, a, i = function(e, t) {
                    if (null == e) return {};
                    var n, a, i = {},
                        o = Object.keys(e);
                    for (a = 0; a < o.length; a++) n = o[a], t.indexOf(n) >= 0 || (i[n] = e[n]);
                    return i
                }(e, t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    for (a = 0; a < o.length; a++) n = o[a], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (i[n] = e[n])
                }
                return i
            }
            n.d(t, {
                ZP: function() {
                    return nY
                }
            });
            var d, g, p, b, h, T, N, v = n(67294),
                C = n.t(v, 2),
                O = ["defaultInputValue", "defaultMenuIsOpen", "defaultValue", "inputValue", "menuIsOpen", "onChange", "onInputChange", "onMenuClose", "onMenuOpen", "value"];

            function z() {
                return (z = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a])
                    }
                    return e
                }).apply(this, arguments)
            }

            function y(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var a = t[n];
                    a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(e, o(a.key), a)
                }
            }

            function A(e, t) {
                return (A = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }

            function S(e) {
                return (S = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(e) {
                    return e.__proto__ || Object.getPrototypeOf(e)
                })(e)
            }

            function E(e) {
                return function(e) {
                    if (Array.isArray(e)) return u(e)
                }(e) || function(e) {
                    if ("undefined" != typeof Symbol && null != e[Symbol.iterator] || null != e["@@iterator"]) return Array.from(e)
                }(e) || l(e) || function() {
                    throw TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }()
            }
            var U = function() {
                    function e(e) {
                        var t = this;
                        this._insertTag = function(e) {
                            var n;
                            n = 0 === t.tags.length ? t.insertionPoint ? t.insertionPoint.nextSibling : t.prepend ? t.container.firstChild : t.before : t.tags[t.tags.length - 1].nextSibling, t.container.insertBefore(e, n), t.tags.push(e)
                        }, this.isSpeedy = void 0 === e.speedy || e.speedy, this.tags = [], this.ctr = 0, this.nonce = e.nonce, this.key = e.key, this.container = e.container, this.prepend = e.prepend, this.insertionPoint = e.insertionPoint, this.before = null
                    }
                    var t = e.prototype;
                    return t.hydrate = function(e) {
                        e.forEach(this._insertTag)
                    }, t.insert = function(e) {
                        if (this.ctr % (this.isSpeedy ? 65e3 : 1) == 0) {
                            var t;
                            this._insertTag(((t = document.createElement("style")).setAttribute("data-emotion", this.key), void 0 !== this.nonce && t.setAttribute("nonce", this.nonce), t.appendChild(document.createTextNode("")), t.setAttribute("data-s", ""), t))
                        }
                        var n = this.tags[this.tags.length - 1];
                        if (this.isSpeedy) {
                            var a = function(e) {
                                if (e.sheet) return e.sheet;
                                for (var t = 0; t < document.styleSheets.length; t++)
                                    if (document.styleSheets[t].ownerNode === e) return document.styleSheets[t]
                            }(n);
                            try {
                                a.insertRule(e, a.cssRules.length)
                            } catch (i) {}
                        } else n.appendChild(document.createTextNode(e));
                        this.ctr++
                    }, t.flush = function() {
                        this.tags.forEach(function(e) {
                            return e.parentNode && e.parentNode.removeChild(e)
                        }), this.tags = [], this.ctr = 0
                    }, e
                }(),
                M = Math.abs,
                w = String.fromCharCode,
                P = Object.assign;

            function k(e, t, n) {
                return e.replace(t, n)
            }

            function I(e, t) {
                return e.indexOf(t)
            }

            function x(e, t) {
                return 0 | e.charCodeAt(t)
            }

            function R(e, t, n) {
                return e.slice(t, n)
            }

            function D(e) {
                return e.length
            }

            function L(e, t) {
                return t.push(e), e
            }
            var V = 1,
                B = 1,
                F = 0,
                G = 0,
                H = 0,
                _ = "";

            function j(e, t, n, a, i, o, r) {
                return {
                    value: e,
                    root: t,
                    parent: n,
                    type: a,
                    props: i,
                    children: o,
                    line: V,
                    column: B,
                    length: r,
                    return: ""
                }
            }

            function K(e, t) {
                return P(j("", null, null, "", null, null, 0), e, {
                    length: -e.length
                }, t)
            }

            function W() {
                return H = G < F ? x(_, G++) : 0, B++, 10 === H && (B = 1, V++), H
            }

            function $() {
                return x(_, G)
            }

            function Y(e) {
                switch (e) {
                    case 0:
                    case 9:
                    case 10:
                    case 13:
                    case 32:
                        return 5;
                    case 33:
                    case 43:
                    case 44:
                    case 47:
                    case 62:
                    case 64:
                    case 126:
                    case 59:
                    case 123:
                    case 125:
                        return 4;
                    case 58:
                        return 3;
                    case 34:
                    case 39:
                    case 40:
                    case 91:
                        return 2;
                    case 41:
                    case 93:
                        return 1
                }
                return 0
            }

            function Z(e) {
                return V = B = 1, F = D(_ = e), G = 0, []
            }

            function X(e) {
                var t, n;
                return (t = G - 1, n = function e(t) {
                    for (; W();) switch (H) {
                        case t:
                            return G;
                        case 34:
                        case 39:
                            34 !== t && 39 !== t && e(H);
                            break;
                        case 40:
                            41 === t && e(t);
                            break;
                        case 92:
                            W()
                    }
                    return G
                }(91 === e ? e + 2 : 40 === e ? e + 1 : e), R(_, t, n)).trim()
            }
            var q = "-ms-",
                J = "-moz-",
                Q = "-webkit-",
                ee = "comm",
                et = "rule",
                en = "decl",
                ea = "@keyframes";

            function ei(e, t) {
                for (var n = "", a = e.length, i = 0; i < a; i++) n += t(e[i], i, e, t) || "";
                return n
            }

            function eo(e, t, n, a) {
                switch (e.type) {
                    case "@import":
                    case en:
                        return e.return = e.return || e.value;
                    case ee:
                        return "";
                    case ea:
                        return e.return = e.value + "{" + ei(e.children, a) + "}";
                    case et:
                        e.value = e.props.join(",")
                }
                return D(n = ei(e.children, a)) ? e.return = e.value + "{" + n + "}" : ""
            }

            function er(e, t, n, a, i, o, r, s, m, u, l) {
                for (var c = i - 1, f = 0 === i ? o : [""], d = f.length, g = 0, p = 0, b = 0; g < a; ++g)
                    for (var h = 0, T = R(e, c + 1, c = M(p = r[g])), N = e; h < d; ++h)(N = (p > 0 ? f[h] + " " + T : k(T, /&\f/g, f[h])).trim()) && (m[b++] = N);
                return j(e, t, n, 0 === i ? et : s, m, u, l)
            }

            function es(e, t, n, a) {
                return j(e, t, n, en, R(e, 0, a), R(e, a + 1, -1), a)
            }
            var em = function(e, t, n) {
                    for (var a = 0, i = 0; a = i, i = $(), 38 === a && 12 === i && (t[n] = 1), !Y(i);) W();
                    return R(_, e, G)
                },
                eu = function(e, t) {
                    var n = -1,
                        a = 44;
                    do switch (Y(a)) {
                        case 0:
                            38 === a && 12 === $() && (t[n] = 1), e[n] += em(G - 1, t, n);
                            break;
                        case 2:
                            e[n] += X(a);
                            break;
                        case 4:
                            if (44 === a) {
                                e[++n] = 58 === $() ? "&\f" : "", t[n] = e[n].length;
                                break
                            }
                        default:
                            e[n] += w(a)
                    }
                    while (a = W());
                    return e
                },
                el = function(e, t) {
                    var n;
                    return n = eu(Z(e), t), _ = "", n
                },
                ec = new WeakMap,
                ef = function(e) {
                    if ("rule" === e.type && e.parent && !(e.length < 1)) {
                        for (var t = e.value, n = e.parent, a = e.column === n.column && e.line === n.line;
                            "rule" !== n.type;)
                            if (!(n = n.parent)) return;
                        if ((1 !== e.props.length || 58 === t.charCodeAt(0) || ec.get(n)) && !a) {
                            ec.set(e, !0);
                            for (var i = [], o = el(t, i), r = n.props, s = 0, m = 0; s < o.length; s++)
                                for (var u = 0; u < r.length; u++, m++) e.props[m] = i[s] ? o[s].replace(/&\f/g, r[u]) : r[u] + " " + o[s]
                        }
                    }
                },
                ed = function(e) {
                    if ("decl" === e.type) {
                        var t = e.value;
                        108 === t.charCodeAt(0) && 98 === t.charCodeAt(2) && (e.return = "", e.value = "")
                    }
                },
                eg = [function(e, t, n, a) {
                    if (e.length > -1 && !e.return) switch (e.type) {
                        case en:
                            e.return = function e(t, n) {
                                switch (45 ^ x(t, 0) ? (((n << 2 ^ x(t, 0)) << 2 ^ x(t, 1)) << 2 ^ x(t, 2)) << 2 ^ x(t, 3) : 0) {
                                    case 5103:
                                        return Q + "print-" + t + t;
                                    case 5737:
                                    case 4201:
                                    case 3177:
                                    case 3433:
                                    case 1641:
                                    case 4457:
                                    case 2921:
                                    case 5572:
                                    case 6356:
                                    case 5844:
                                    case 3191:
                                    case 6645:
                                    case 3005:
                                    case 6391:
                                    case 5879:
                                    case 5623:
                                    case 6135:
                                    case 4599:
                                    case 4855:
                                    case 4215:
                                    case 6389:
                                    case 5109:
                                    case 5365:
                                    case 5621:
                                    case 3829:
                                        return Q + t + t;
                                    case 5349:
                                    case 4246:
                                    case 4810:
                                    case 6968:
                                    case 2756:
                                        return Q + t + J + t + q + t + t;
                                    case 6828:
                                    case 4268:
                                        return Q + t + q + t + t;
                                    case 6165:
                                        return Q + t + q + "flex-" + t + t;
                                    case 5187:
                                        return Q + t + k(t, /(\w+).+(:[^]+)/, Q + "box-$1$2" + q + "flex-$1$2") + t;
                                    case 5443:
                                        return Q + t + q + "flex-item-" + k(t, /flex-|-self/, "") + t;
                                    case 4675:
                                        return Q + t + q + "flex-line-pack" + k(t, /align-content|flex-|-self/, "") + t;
                                    case 5548:
                                        return Q + t + q + k(t, "shrink", "negative") + t;
                                    case 5292:
                                        return Q + t + q + k(t, "basis", "preferred-size") + t;
                                    case 6060:
                                        return Q + "box-" + k(t, "-grow", "") + Q + t + q + k(t, "grow", "positive") + t;
                                    case 4554:
                                        return Q + k(t, /([^-])(transform)/g, "$1" + Q + "$2") + t;
                                    case 6187:
                                        return k(k(k(t, /(zoom-|grab)/, Q + "$1"), /(image-set)/, Q + "$1"), t, "") + t;
                                    case 5495:
                                    case 3959:
                                        return k(t, /(image-set\([^]*)/, Q + "$1$`$1");
                                    case 4968:
                                        return k(k(t, /(.+:)(flex-)?(.*)/, Q + "box-pack:$3" + q + "flex-pack:$3"), /s.+-b[^;]+/, "justify") + Q + t + t;
                                    case 4095:
                                    case 3583:
                                    case 4068:
                                    case 2532:
                                        return k(t, /(.+)-inline(.+)/, Q + "$1$2") + t;
                                    case 8116:
                                    case 7059:
                                    case 5753:
                                    case 5535:
                                    case 5445:
                                    case 5701:
                                    case 4933:
                                    case 4677:
                                    case 5533:
                                    case 5789:
                                    case 5021:
                                    case 4765:
                                        if (D(t) - 1 - n > 6) switch (x(t, n + 1)) {
                                            case 109:
                                                if (45 !== x(t, n + 4)) break;
                                            case 102:
                                                return k(t, /(.+:)(.+)-([^]+)/, "$1" + Q + "$2-$3$1" + J + (108 == x(t, n + 3) ? "$3" : "$2-$3")) + t;
                                            case 115:
                                                return ~I(t, "stretch") ? e(k(t, "stretch", "fill-available"), n) + t : t
                                        }
                                        break;
                                    case 4949:
                                        if (115 !== x(t, n + 1)) break;
                                    case 6444:
                                        switch (x(t, D(t) - 3 - (~I(t, "!important") && 10))) {
                                            case 107:
                                                return k(t, ":", ":" + Q) + t;
                                            case 101:
                                                return k(t, /(.+:)([^;!]+)(;|!.+)?/, "$1" + Q + (45 === x(t, 14) ? "inline-" : "") + "box$3$1" + Q + "$2$3$1" + q + "$2box$3") + t
                                        }
                                        break;
                                    case 5936:
                                        switch (x(t, n + 11)) {
                                            case 114:
                                                return Q + t + q + k(t, /[svh]\w+-[tblr]{2}/, "tb") + t;
                                            case 108:
                                                return Q + t + q + k(t, /[svh]\w+-[tblr]{2}/, "tb-rl") + t;
                                            case 45:
                                                return Q + t + q + k(t, /[svh]\w+-[tblr]{2}/, "lr") + t
                                        }
                                        return Q + t + q + t + t
                                }
                                return t
                            }(e.value, e.length);
                            break;
                        case ea:
                            return ei([K(e, {
                                value: k(e.value, "@", "@" + Q)
                            })], a);
                        case et:
                            if (e.length) {
                                var i, o;
                                return i = e.props, o = function(t) {
                                    var n;
                                    switch (n = t, (n = /(::plac\w+|:read-\w+)/.exec(n)) ? n[0] : n) {
                                        case ":read-only":
                                        case ":read-write":
                                            return ei([K(e, {
                                                props: [k(t, /:(read-\w+)/, ":" + J + "$1")]
                                            })], a);
                                        case "::placeholder":
                                            return ei([K(e, {
                                                props: [k(t, /:(plac\w+)/, ":" + Q + "input-$1")]
                                            }), K(e, {
                                                props: [k(t, /:(plac\w+)/, ":" + J + "$1")]
                                            }), K(e, {
                                                props: [k(t, /:(plac\w+)/, q + "input-$1")]
                                            })], a)
                                    }
                                    return ""
                                }, i.map(o).join("")
                            }
                    }
                }],
                ep = function(e, t, n) {
                    var a = e.key + "-" + t.name;
                    !1 === n && void 0 === e.registered[a] && (e.registered[a] = t.styles)
                },
                eb = function(e, t, n) {
                    ep(e, t, n);
                    var a = e.key + "-" + t.name;
                    if (void 0 === e.inserted[t.name]) {
                        var i = t;
                        do e.insert(t === i ? "." + a : "", i, e.sheet, !0), i = i.next; while (void 0 !== i)
                    }
                },
                eh = function(e) {
                    for (var t, n = 0, a = 0, i = e.length; i >= 4; ++a, i -= 4) t = (65535 & (t = 255 & e.charCodeAt(a) | (255 & e.charCodeAt(++a)) << 8 | (255 & e.charCodeAt(++a)) << 16 | (255 & e.charCodeAt(++a)) << 24)) * 1540483477 + ((t >>> 16) * 59797 << 16), t ^= t >>> 24, n = (65535 & t) * 1540483477 + ((t >>> 16) * 59797 << 16) ^ (65535 & n) * 1540483477 + ((n >>> 16) * 59797 << 16);
                    switch (i) {
                        case 3:
                            n ^= (255 & e.charCodeAt(a + 2)) << 16;
                        case 2:
                            n ^= (255 & e.charCodeAt(a + 1)) << 8;
                        case 1:
                            n ^= 255 & e.charCodeAt(a), n = (65535 & n) * 1540483477 + ((n >>> 16) * 59797 << 16)
                    }
                    return n ^= n >>> 13, (((n = (65535 & n) * 1540483477 + ((n >>> 16) * 59797 << 16)) ^ n >>> 15) >>> 0).toString(36)
                },
                eT = {
                    animationIterationCount: 1,
                    borderImageOutset: 1,
                    borderImageSlice: 1,
                    borderImageWidth: 1,
                    boxFlex: 1,
                    boxFlexGroup: 1,
                    boxOrdinalGroup: 1,
                    columnCount: 1,
                    columns: 1,
                    flex: 1,
                    flexGrow: 1,
                    flexPositive: 1,
                    flexShrink: 1,
                    flexNegative: 1,
                    flexOrder: 1,
                    gridRow: 1,
                    gridRowEnd: 1,
                    gridRowSpan: 1,
                    gridRowStart: 1,
                    gridColumn: 1,
                    gridColumnEnd: 1,
                    gridColumnSpan: 1,
                    gridColumnStart: 1,
                    msGridRow: 1,
                    msGridRowSpan: 1,
                    msGridColumn: 1,
                    msGridColumnSpan: 1,
                    fontWeight: 1,
                    lineHeight: 1,
                    opacity: 1,
                    order: 1,
                    orphans: 1,
                    tabSize: 1,
                    widows: 1,
                    zIndex: 1,
                    zoom: 1,
                    WebkitLineClamp: 1,
                    fillOpacity: 1,
                    floodOpacity: 1,
                    stopOpacity: 1,
                    strokeDasharray: 1,
                    strokeDashoffset: 1,
                    strokeMiterlimit: 1,
                    strokeOpacity: 1,
                    strokeWidth: 1
                },
                eN = /[A-Z]|^ms/g,
                ev = /_EMO_([^_]+?)_([^]*?)_EMO_/g,
                eC = function(e) {
                    return 45 === e.charCodeAt(1)
                },
                eO = function(e) {
                    return null != e && "boolean" != typeof e
                },
                ez = (d = function(e) {
                    return eC(e) ? e : e.replace(eN, "-$&").toLowerCase()
                }, g = Object.create(null), function(e) {
                    return void 0 === g[e] && (g[e] = d(e)), g[e]
                }),
                ey = function(e, t) {
                    switch (e) {
                        case "animation":
                        case "animationName":
                            if ("string" == typeof t) return t.replace(ev, function(e, t, n) {
                                return T = {
                                    name: t,
                                    styles: n,
                                    next: T
                                }, t
                            })
                    }
                    return 1 === eT[e] || eC(e) || "number" != typeof t || 0 === t ? t : t + "px"
                };

            function eA(e, t, n) {
                if (null == n) return "";
                if (void 0 !== n.__emotion_styles) return n;
                switch (typeof n) {
                    case "boolean":
                        return "";
                    case "object":
                        if (1 === n.anim) return T = {
                            name: n.name,
                            styles: n.styles,
                            next: T
                        }, n.name;
                        if (void 0 !== n.styles) {
                            var a = n.next;
                            if (void 0 !== a)
                                for (; void 0 !== a;) T = {
                                    name: a.name,
                                    styles: a.styles,
                                    next: T
                                }, a = a.next;
                            return n.styles + ";"
                        }
                        return function(e, t, n) {
                            var a = "";
                            if (Array.isArray(n))
                                for (var i = 0; i < n.length; i++) a += eA(e, t, n[i]) + ";";
                            else
                                for (var o in n) {
                                    var r = n[o];
                                    if ("object" != typeof r) null != t && void 0 !== t[r] ? a += o + "{" + t[r] + "}" : eO(r) && (a += ez(o) + ":" + ey(o, r) + ";");
                                    else if (Array.isArray(r) && "string" == typeof r[0] && (null == t || void 0 === t[r[0]]))
                                        for (var s = 0; s < r.length; s++) eO(r[s]) && (a += ez(o) + ":" + ey(o, r[s]) + ";");
                                    else {
                                        var m = eA(e, t, r);
                                        switch (o) {
                                            case "animation":
                                            case "animationName":
                                                a += ez(o) + ":" + m + ";";
                                                break;
                                            default:
                                                a += o + "{" + m + "}"
                                        }
                                    }
                                }
                            return a
                        }(e, t, n);
                    case "function":
                        if (void 0 !== e) {
                            var i = T,
                                o = n(e);
                            return T = i, eA(e, t, o)
                        }
                }
                if (null == t) return n;
                var r = t[n];
                return void 0 !== r ? r : n
            }
            var eS = /label:\s*([^\s;\n{]+)\s*(;|$)/g,
                eE = function(e, t, n) {
                    if (1 === e.length && "object" == typeof e[0] && null !== e[0] && void 0 !== e[0].styles) return e[0];
                    var a, i = !0,
                        o = "";
                    T = void 0;
                    var r = e[0];
                    null == r || void 0 === r.raw ? (i = !1, o += eA(n, t, r)) : o += r[0];
                    for (var s = 1; s < e.length; s++) o += eA(n, t, e[s]), i && (o += r[s]);
                    eS.lastIndex = 0;
                    for (var m = ""; null !== (a = eS.exec(o));) m += "-" + a[1];
                    return {
                        name: eh(o) + m,
                        styles: o,
                        next: T
                    }
                },
                eU = function(e) {
                    return e()
                },
                eM = !!C.useInsertionEffect && C.useInsertionEffect,
                ew = eM || eU;
            eM || v.useLayoutEffect;
            var eP = {}.hasOwnProperty,
                ek = (0, v.createContext)("undefined" != typeof HTMLElement ? function(e) {
                    var t, n, a, i, o, r, s = e.key;
                    if ("css" === s) {
                        var m = document.querySelectorAll("style[data-emotion]:not([data-s])");
                        Array.prototype.forEach.call(m, function(e) {
                            -1 !== e.getAttribute("data-emotion").indexOf(" ") && (document.head.appendChild(e), e.setAttribute("data-s", ""))
                        })
                    }
                    var u = e.stylisPlugins || eg,
                        l = {},
                        c = [];
                    i = e.container || document.head, Array.prototype.forEach.call(document.querySelectorAll('style[data-emotion^="' + s + ' "]'), function(e) {
                        for (var t = e.getAttribute("data-emotion").split(" "), n = 1; n < t.length; n++) l[t[n]] = !0;
                        c.push(e)
                    });
                    var f = (n = (t = [ef, ed].concat(u, [eo, (a = function(e) {
                            r.insert(e)
                        }, function(e) {
                            !e.root && (e = e.return) && a(e)
                        })])).length, function(e, a, i, o) {
                            for (var r = "", s = 0; s < n; s++) r += t[s](e, a, i, o) || "";
                            return r
                        }),
                        d = function(e) {
                            var t, n;
                            return ei((n = function e(t, n, a, i, o, r, s, m, u) {
                                for (var l, c = 0, f = 0, d = s, g = 0, p = 0, b = 0, h = 1, T = 1, N = 1, v = 0, C = "", O = o, z = r, y = i, A = C; T;) switch (b = v, v = W()) {
                                    case 40:
                                        if (108 != b && 58 == x(A, d - 1)) {
                                            -1 != I(A += k(X(v), "&", "&\f"), "&\f") && (N = -1);
                                            break
                                        }
                                    case 34:
                                    case 39:
                                    case 91:
                                        A += X(v);
                                        break;
                                    case 9:
                                    case 10:
                                    case 13:
                                    case 32:
                                        A += function(e) {
                                            for (; H = $();)
                                                if (H < 33) W();
                                                else break;
                                            return Y(e) > 2 || Y(H) > 3 ? "" : " "
                                        }(b);
                                        break;
                                    case 92:
                                        A += function(e, t) {
                                            for (var n; --t && W() && !(H < 48) && !(H > 102) && (!(H > 57) || !(H < 65)) && (!(H > 70) || !(H < 97)););
                                            return n = G + (t < 6 && 32 == $() && 32 == W()), R(_, e, n)
                                        }(G - 1, 7);
                                        continue;
                                    case 47:
                                        switch ($()) {
                                            case 42:
                                            case 47:
                                                L(j(l = function(e, t) {
                                                    for (; W();)
                                                        if (e + H === 57) break;
                                                        else if (e + H === 84 && 47 === $()) break;
                                                    return "/*" + R(_, t, G - 1) + "*" + w(47 === e ? e : W())
                                                }(W(), G), n, a, ee, w(H), R(l, 2, -2), 0), u);
                                                break;
                                            default:
                                                A += "/"
                                        }
                                        break;
                                    case 123 * h:
                                        m[c++] = D(A) * N;
                                    case 125 * h:
                                    case 59:
                                    case 0:
                                        switch (v) {
                                            case 0:
                                            case 125:
                                                T = 0;
                                            case 59 + f:
                                                p > 0 && D(A) - d && L(p > 32 ? es(A + ";", i, a, d - 1) : es(k(A, " ", "") + ";", i, a, d - 2), u);
                                                break;
                                            case 59:
                                                A += ";";
                                            default:
                                                if (L(y = er(A, n, a, c, f, o, m, C, O = [], z = [], d), r), 123 === v) {
                                                    if (0 === f) e(A, n, y, y, O, r, d, m, z);
                                                    else switch (99 === g && 110 === x(A, 3) ? 100 : g) {
                                                        case 100:
                                                        case 109:
                                                        case 115:
                                                            e(t, y, y, i && L(er(t, y, y, 0, 0, o, m, C, o, O = [], d), z), o, z, d, m, i ? O : z);
                                                            break;
                                                        default:
                                                            e(A, y, y, y, [""], z, 0, m, z)
                                                    }
                                                }
                                        }
                                        c = f = p = 0, h = N = 1, C = A = "", d = s;
                                        break;
                                    case 58:
                                        d = 1 + D(A), p = b;
                                    default:
                                        if (h < 1) {
                                            if (123 == v) --h;
                                            else if (125 == v && 0 == h++ && 125 == (H = G > 0 ? x(_, --G) : 0, B--, 10 === H && (B = 1, V--), H)) continue
                                        }
                                        switch (A += w(v), v * h) {
                                            case 38:
                                                N = f > 0 ? 1 : (A += "\f", -1);
                                                break;
                                            case 44:
                                                m[c++] = (D(A) - 1) * N, N = 1;
                                                break;
                                            case 64:
                                                45 === $() && (A += X(W())), g = $(), f = d = D(C = A += function(e) {
                                                    for (; !Y($());) W();
                                                    return R(_, e, G)
                                                }(G)), v++;
                                                break;
                                            case 45:
                                                45 === b && 2 == D(A) && (h = 0)
                                        }
                                }
                                return r
                            }("", null, null, null, [""], t = Z(t = e), 0, [0], t), _ = "", n), f)
                        };
                    o = function(e, t, n, a) {
                        r = n, d(e ? e + "{" + t.styles + "}" : t.styles), a && (g.inserted[t.name] = !0)
                    };
                    var g = {
                        key: s,
                        sheet: new U({
                            key: s,
                            container: i,
                            nonce: e.nonce,
                            speedy: e.speedy,
                            prepend: e.prepend,
                            insertionPoint: e.insertionPoint
                        }),
                        nonce: e.nonce,
                        inserted: l,
                        registered: {},
                        insert: o
                    };
                    return g.sheet.hydrate(c), g
                }({
                    key: "css"
                }) : null);
            ek.Provider;
            var eI = (0, v.createContext)({}),
                ex = "__EMOTION_TYPE_PLEASE_DO_NOT_USE__",
                eR = function(e, t) {
                    var n = {};
                    for (var a in t) eP.call(t, a) && (n[a] = t[a]);
                    return n[ex] = e, n
                },
                eD = function(e) {
                    var t = e.cache,
                        n = e.serialized,
                        a = e.isStringTag;
                    return ep(t, n, a), ew(function() {
                        return eb(t, n, a)
                    }), null
                },
                eL = (p = function(e, t, n) {
                    var a, i, o, r = e.css;
                    "string" == typeof r && void 0 !== t.registered[r] && (r = t.registered[r]);
                    var s = e[ex],
                        m = [r],
                        u = "";
                    "string" == typeof e.className ? (a = t.registered, i = e.className, o = "", i.split(" ").forEach(function(e) {
                        void 0 !== a[e] ? m.push(a[e] + ";") : o += e + " "
                    }), u = o) : null != e.className && (u = e.className + " ");
                    var l = eE(m, void 0, (0, v.useContext)(eI));
                    u += t.key + "-" + l.name;
                    var c = {};
                    for (var f in e) eP.call(e, f) && "css" !== f && f !== ex && (c[f] = e[f]);
                    return c.ref = n, c.className = u, (0, v.createElement)(v.Fragment, null, (0, v.createElement)(eD, {
                        cache: t,
                        serialized: l,
                        isStringTag: "string" == typeof s
                    }), (0, v.createElement)(s, c))
                }, (0, v.forwardRef)(function(e, t) {
                    return p(e, (0, v.useContext)(ek), t)
                }));
            n(8679);
            var eV = function(e, t) {
                var n = arguments;
                if (null == t || !eP.call(t, "css")) return v.createElement.apply(void 0, n);
                var a = n.length,
                    i = Array(a);
                i[0] = eL, i[1] = eR(e, t);
                for (var o = 2; o < a; o++) i[o] = n[o];
                return v.createElement.apply(null, i)
            };

            function eB() {
                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return eE(t)
            }
            var eF = n(73935);

            function eG(e) {
                var t;
                return (null == (t = e.ownerDocument) ? void 0 : t.defaultView) || window
            }

            function eH(e) {
                return eG(e).getComputedStyle(e)
            }

            function e_(e) {
                return eW(e) ? (e.nodeName || "").toLowerCase() : ""
            }

            function ej(e) {
                return e instanceof eG(e).HTMLElement
            }

            function eK(e) {
                return e instanceof eG(e).Element
            }

            function eW(e) {
                return e instanceof eG(e).Node
            }

            function e$(e) {
                return "undefined" != typeof ShadowRoot && (e instanceof eG(e).ShadowRoot || e instanceof ShadowRoot)
            }

            function eY(e) {
                let {
                    overflow: t,
                    overflowX: n,
                    overflowY: a,
                    display: i
                } = eH(e);
                return /auto|scroll|overlay|hidden/.test(t + a + n) && !["inline", "contents"].includes(i)
            }["top", "right", "bottom", "left"].reduce((e, t) => e.concat(t, t + "-start", t + "-end"), []);
            let eZ = Math.round,
                eX = {
                    x: 1,
                    y: 1
                };

            function eq(e) {
                let t = !eK(e) && e.contextElement ? e.contextElement : eK(e) ? e : null;
                if (!t) return eX;
                let n = t.getBoundingClientRect(),
                    a = eH(t);
                if ("border-box" !== a.boxSizing) return ej(t) ? {
                    x: t.offsetWidth > 0 && eZ(n.width) / t.offsetWidth || 1,
                    y: t.offsetHeight > 0 && eZ(n.height) / t.offsetHeight || 1
                } : eX;
                let i = n.width / parseFloat(a.width),
                    o = n.height / parseFloat(a.height);
                return i && Number.isFinite(i) || (i = 1), o && Number.isFinite(o) || (o = 1), {
                    x: i,
                    y: o
                }
            }

            function eJ(e, t, n, i) {
                var o, r, s, m;
                void 0 === t && (t = !1), void 0 === n && (n = !1);
                let u = e.getBoundingClientRect(),
                    l = eX;
                t && (i ? eK(i) && (l = eq(i)) : l = eq(e));
                let c = eK(e) ? eG(e) : window,
                    f = !!/^((?!chrome|android).)*safari/i.test(function() {
                        if (a) return a;
                        let e = navigator.userAgentData;
                        return e && Array.isArray(e.brands) ? a = e.brands.map(e => e.brand + "/" + e.version).join(" ") : navigator.userAgent
                    }()) && n,
                    d = (u.left + (f && null != (o = null == (r = c.visualViewport) ? void 0 : r.offsetLeft) ? o : 0)) / l.x,
                    g = (u.top + (f && null != (s = null == (m = c.visualViewport) ? void 0 : m.offsetTop) ? s : 0)) / l.y,
                    p = u.width / l.x,
                    b = u.height / l.y;
                return {
                    width: p,
                    height: b,
                    top: g,
                    right: d + p,
                    bottom: g + b,
                    left: d,
                    x: d,
                    y: g
                }
            }

            function eQ(e, t) {
                var n;
                void 0 === t && (t = []);
                let a = function e(t) {
                        let n = function(e) {
                            if ("html" === e_(e)) return e;
                            let t = e.assignedSlot || e.parentNode || (e$(e) ? e.host : null) || ((eW(e) ? e.ownerDocument : e.document) || window.document).documentElement;
                            return e$(t) ? t.host : t
                        }(t);
                        return ["html", "body", "#document"].includes(e_(n)) ? t.ownerDocument.body : ej(n) && eY(n) ? n : e(n)
                    }(e),
                    i = a === (null == (n = e.ownerDocument) ? void 0 : n.body),
                    o = eG(a);
                return i ? t.concat(o, o.visualViewport || [], eY(a) ? a : []) : t.concat(a, eQ(a))
            }
            var e0 = v.useLayoutEffect,
                e1 = ["className", "clearValue", "cx", "getStyles", "getClassNames", "getValue", "hasValue", "isMulti", "isRtl", "options", "selectOption", "selectProps", "setValue", "theme"],
                e3 = function() {};

            function e6(e, t) {
                for (var n, a = arguments.length, i = Array(a > 2 ? a - 2 : 0), o = 2; o < a; o++) i[o - 2] = arguments[o];
                var r = [].concat(i);
                if (t && e)
                    for (var s in t) t.hasOwnProperty(s) && t[s] && r.push("".concat((n = s) ? "-" === n[0] ? e + n : e + "__" + n : e));
                return r.filter(function(e) {
                    return e
                }).map(function(e) {
                    return String(e).trim()
                }).join(" ")
            }
            var e2 = function(e) {
                    return Array.isArray(e) ? e.filter(Boolean) : "object" === i(e) && null !== e ? [e] : []
                },
                e5 = function(e) {
                    return e.className, e.clearValue, e.cx, e.getStyles, e.getClassNames, e.getValue, e.hasValue, e.isMulti, e.isRtl, e.options, e.selectOption, e.selectProps, e.setValue, e.theme, m({}, f(e, e1))
                },
                e4 = function(e, t, n) {
                    var a = e.cx,
                        i = e.getStyles,
                        o = e.getClassNames,
                        r = e.className;
                    return {
                        css: i(t, e),
                        className: a(null != n ? n : {}, o(t, e), r)
                    }
                };

            function e8(e) {
                return [document.documentElement, document.body, window].indexOf(e) > -1
            }

            function e9(e) {
                return e8(e) ? window.pageYOffset : e.scrollTop
            }

            function e7(e, t) {
                if (e8(e)) {
                    window.scrollTo(0, t);
                    return
                }
                e.scrollTop = t
            }

            function te(e, t) {
                var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 200,
                    a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : e3,
                    i = e9(e),
                    o = t - i,
                    r = 0;
                ! function t() {
                    var s;
                    r += 10, e7(e, o * ((s = (s = r) / n - 1) * s * s + 1) + i), r < n ? window.requestAnimationFrame(t) : a(e)
                }()
            }

            function tt(e, t) {
                var n = e.getBoundingClientRect(),
                    a = t.getBoundingClientRect(),
                    i = t.offsetHeight / 3;
                a.bottom + i > n.bottom ? e7(e, Math.min(t.offsetTop + t.clientHeight - e.offsetHeight + i, e.scrollHeight)) : a.top - i < n.top && e7(e, Math.max(t.offsetTop - i, 0))
            }

            function tn() {
                try {
                    return document.createEvent("TouchEvent"), !0
                } catch (e) {
                    return !1
                }
            }
            var ta = !1,
                ti = {
                    get passive() {
                        return ta = !0
                    }
                },
                to = "undefined" != typeof window ? window : {};
            to.addEventListener && to.removeEventListener && (to.addEventListener("p", e3, ti), to.removeEventListener("p", e3, !1));
            var tr = ta;

            function ts(e) {
                return null != e
            }
            var tm = function(e) {
                    for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), a = 1; a < t; a++) n[a - 1] = arguments[a];
                    return Object.entries(e).filter(function(e) {
                        var t = c(e, 1)[0];
                        return !n.includes(t)
                    }).reduce(function(e, t) {
                        var n = c(t, 2),
                            a = n[0],
                            i = n[1];
                        return e[a] = i, e
                    }, {})
                },
                tu = function(e) {
                    return "auto" === e ? "bottom" : e
                },
                tl = function(e, t) {
                    var n, a = e.placement,
                        i = e.theme,
                        o = i.borderRadius,
                        s = i.spacing,
                        u = i.colors;
                    return m((r(n = {
                        label: "menu"
                    }, a ? ({
                        bottom: "top",
                        top: "bottom"
                    })[a] : "bottom", "100%"), r(n, "position", "absolute"), r(n, "width", "100%"), r(n, "zIndex", 1), n), t ? {} : {
                        backgroundColor: u.neutral0,
                        borderRadius: o,
                        boxShadow: "0 0 0 1px hsla(0, 0%, 0%, 0.1), 0 4px 11px hsla(0, 0%, 0%, 0.1)",
                        marginBottom: s.menuGutter,
                        marginTop: s.menuGutter
                    })
                },
                tc = (0, v.createContext)(null),
                tf = function(e) {
                    var t = e.children,
                        n = e.minMenuHeight,
                        a = e.maxMenuHeight,
                        i = e.menuPlacement,
                        o = e.menuPosition,
                        r = e.menuShouldScrollIntoView,
                        s = e.theme,
                        u = ((0, v.useContext)(tc) || {}).setPortalPlacement,
                        l = (0, v.useRef)(null),
                        f = c((0, v.useState)(a), 2),
                        d = f[0],
                        g = f[1],
                        p = c((0, v.useState)(null), 2),
                        b = p[0],
                        h = p[1],
                        T = s.spacing.controlHeight;
                    return e0(function() {
                        var e = l.current;
                        if (e) {
                            var t = "fixed" === o,
                                s = function(e) {
                                    var t = e.maxHeight,
                                        n = e.menuEl,
                                        a = e.minHeight,
                                        i = e.placement,
                                        o = e.shouldScroll,
                                        r = e.isFixedPosition,
                                        s = e.controlHeight,
                                        m = function(e) {
                                            var t = getComputedStyle(e),
                                                n = "absolute" === t.position,
                                                a = /(auto|scroll)/;
                                            if ("fixed" === t.position) return document.documentElement;
                                            for (var i = e; i = i.parentElement;)
                                                if (t = getComputedStyle(i), (!n || "static" !== t.position) && a.test(t.overflow + t.overflowY + t.overflowX)) return i;
                                            return document.documentElement
                                        }(n),
                                        u = {
                                            placement: "bottom",
                                            maxHeight: t
                                        };
                                    if (!n || !n.offsetParent) return u;
                                    var l = m.getBoundingClientRect().height,
                                        c = n.getBoundingClientRect(),
                                        f = c.bottom,
                                        d = c.height,
                                        g = c.top,
                                        p = n.offsetParent.getBoundingClientRect().top,
                                        b = r ? window.innerHeight : e8(m) ? window.innerHeight : m.clientHeight,
                                        h = e9(m),
                                        T = parseInt(getComputedStyle(n).marginBottom, 10),
                                        N = parseInt(getComputedStyle(n).marginTop, 10),
                                        v = p - N,
                                        C = b - g,
                                        O = v + h,
                                        z = l - h - g,
                                        y = f - b + h + T,
                                        A = h + g - N;
                                    switch (i) {
                                        case "auto":
                                        case "bottom":
                                            if (C >= d) return {
                                                placement: "bottom",
                                                maxHeight: t
                                            };
                                            if (z >= d && !r) return o && te(m, y, 160), {
                                                placement: "bottom",
                                                maxHeight: t
                                            };
                                            if (!r && z >= a || r && C >= a) return o && te(m, y, 160), {
                                                placement: "bottom",
                                                maxHeight: r ? C - T : z - T
                                            };
                                            if ("auto" === i || r) {
                                                var S = t,
                                                    E = r ? v : O;
                                                return E >= a && (S = Math.min(E - T - s, t)), {
                                                    placement: "top",
                                                    maxHeight: S
                                                }
                                            }
                                            if ("bottom" === i) return o && e7(m, y), {
                                                placement: "bottom",
                                                maxHeight: t
                                            };
                                            break;
                                        case "top":
                                            if (v >= d) return {
                                                placement: "top",
                                                maxHeight: t
                                            };
                                            if (O >= d && !r) return o && te(m, A, 160), {
                                                placement: "top",
                                                maxHeight: t
                                            };
                                            if (!r && O >= a || r && v >= a) {
                                                var U = t;
                                                return (!r && O >= a || r && v >= a) && (U = r ? v - N : O - N), o && te(m, A, 160), {
                                                    placement: "top",
                                                    maxHeight: U
                                                }
                                            }
                                            return {
                                                placement: "bottom",
                                                maxHeight: t
                                            };
                                        default:
                                            throw Error('Invalid placement provided "'.concat(i, '".'))
                                    }
                                    return u
                                }({
                                    maxHeight: a,
                                    menuEl: e,
                                    minHeight: n,
                                    placement: i,
                                    shouldScroll: r && !t,
                                    isFixedPosition: t,
                                    controlHeight: T
                                });
                            g(s.maxHeight), h(s.placement), null == u || u(s.placement)
                        }
                    }, [a, i, o, r, n, u, T]), t({
                        ref: l,
                        placerProps: m(m({}, e), {}, {
                            placement: b || tu(i),
                            maxHeight: d
                        })
                    })
                },
                td = function(e) {
                    var t = e.children,
                        n = e.innerRef,
                        a = e.innerProps;
                    return eV("div", z({}, e4(e, "menu", {
                        menu: !0
                    }), {
                        ref: n
                    }, a), t)
                },
                tg = function(e, t) {
                    var n = e.maxHeight,
                        a = e.theme.spacing.baseUnit;
                    return m({
                        maxHeight: n,
                        overflowY: "auto",
                        position: "relative",
                        WebkitOverflowScrolling: "touch"
                    }, t ? {} : {
                        paddingBottom: a,
                        paddingTop: a
                    })
                },
                tp = function(e) {
                    var t = e.children,
                        n = e.innerProps,
                        a = e.innerRef,
                        i = e.isMulti;
                    return eV("div", z({}, e4(e, "menuList", {
                        "menu-list": !0,
                        "menu-list--is-multi": i
                    }), {
                        ref: a
                    }, n), t)
                },
                tb = function(e, t) {
                    var n = e.theme,
                        a = n.spacing.baseUnit,
                        i = n.colors;
                    return m({
                        textAlign: "center"
                    }, t ? {} : {
                        color: i.neutral40,
                        padding: "".concat(2 * a, "px ").concat(3 * a, "px")
                    })
                },
                th = function(e) {
                    var t = e.children,
                        n = e.innerProps;
                    return eV("div", z({}, e4(e, "noOptionsMessage", {
                        "menu-notice": !0,
                        "menu-notice--no-options": !0
                    }), n), t)
                };
            th.defaultProps = {
                children: "No options"
            };
            var tT = function(e) {
                var t = e.children,
                    n = e.innerProps;
                return eV("div", z({}, e4(e, "loadingMessage", {
                    "menu-notice": !0,
                    "menu-notice--loading": !0
                }), n), t)
            };
            tT.defaultProps = {
                children: "Loading..."
            };
            var tN = function(e) {
                    var t = e.rect,
                        n = e.offset,
                        a = e.position;
                    return {
                        left: t.left,
                        position: a,
                        top: n,
                        width: t.width,
                        zIndex: 1
                    }
                },
                tv = function(e) {
                    var t = e.appendTo,
                        n = e.children,
                        a = e.controlElement,
                        i = e.innerProps,
                        o = e.menuPlacement,
                        r = e.menuPosition,
                        s = (0, v.useRef)(null),
                        u = (0, v.useRef)(null),
                        l = c((0, v.useState)(tu(o)), 2),
                        f = l[0],
                        d = l[1],
                        g = (0, v.useMemo)(function() {
                            return {
                                setPortalPlacement: d
                            }
                        }, []),
                        p = c((0, v.useState)(null), 2),
                        b = p[0],
                        h = p[1],
                        T = (0, v.useCallback)(function() {
                            if (a) {
                                var e, t = {
                                        bottom: (e = a.getBoundingClientRect()).bottom,
                                        height: e.height,
                                        left: e.left,
                                        right: e.right,
                                        top: e.top,
                                        width: e.width
                                    },
                                    n = "fixed" === r ? 0 : window.pageYOffset,
                                    i = t[f] + n;
                                (i !== (null == b ? void 0 : b.offset) || t.left !== (null == b ? void 0 : b.rect.left) || t.width !== (null == b ? void 0 : b.rect.width)) && h({
                                    offset: i,
                                    rect: t
                                })
                            }
                        }, [a, r, f, null == b ? void 0 : b.offset, null == b ? void 0 : b.rect.left, null == b ? void 0 : b.rect.width]);
                    e0(function() {
                        T()
                    }, [T]);
                    var N = (0, v.useCallback)(function() {
                        "function" == typeof u.current && (u.current(), u.current = null), a && s.current && (u.current = function(e, t, n, a) {
                            void 0 === a && (a = {});
                            let {
                                ancestorScroll: i = !0,
                                ancestorResize: o = !0,
                                elementResize: r = !0,
                                animationFrame: s = !1
                            } = a, m = i && !s, u = m || o ? [...eK(e) ? eQ(e) : e.contextElement ? eQ(e.contextElement) : [], ...eQ(t)] : [];
                            u.forEach(e => {
                                m && e.addEventListener("scroll", n, {
                                    passive: !0
                                }), o && e.addEventListener("resize", n)
                            });
                            let l, c = null;
                            if (r) {
                                let f = !0;
                                c = new ResizeObserver(() => {
                                    f || n(), f = !1
                                }), eK(e) && !s && c.observe(e), eK(e) || !e.contextElement || s || c.observe(e.contextElement), c.observe(t)
                            }
                            let d = s ? eJ(e) : null;
                            return s && function t() {
                                let a = eJ(e);
                                d && (a.x !== d.x || a.y !== d.y || a.width !== d.width || a.height !== d.height) && n(), d = a, l = requestAnimationFrame(t)
                            }(), n(), () => {
                                var e;
                                u.forEach(e => {
                                    m && e.removeEventListener("scroll", n), o && e.removeEventListener("resize", n)
                                }), null == (e = c) || e.disconnect(), c = null, s && cancelAnimationFrame(l)
                            }
                        }(a, s.current, T, {
                            elementResize: "ResizeObserver" in window
                        }))
                    }, [a, T]);
                    e0(function() {
                        N()
                    }, [N]);
                    var C = (0, v.useCallback)(function(e) {
                        s.current = e, N()
                    }, [N]);
                    if (!t && "fixed" !== r || !b) return null;
                    var O = eV("div", z({
                        ref: C
                    }, e4(m(m({}, e), {}, {
                        offset: b.offset,
                        position: r,
                        rect: b.rect
                    }), "menuPortal", {
                        "menu-portal": !0
                    }), i), n);
                    return eV(tc.Provider, {
                        value: g
                    }, t ? (0, eF.createPortal)(O, t) : O)
                },
                tC = function(e) {
                    var t = e.isDisabled;
                    return {
                        label: "container",
                        direction: e.isRtl ? "rtl" : void 0,
                        pointerEvents: t ? "none" : void 0,
                        position: "relative"
                    }
                },
                tO = function(e) {
                    var t = e.children,
                        n = e.innerProps,
                        a = e.isDisabled,
                        i = e.isRtl;
                    return eV("div", z({}, e4(e, "container", {
                        "--is-disabled": a,
                        "--is-rtl": i
                    }), n), t)
                },
                tz = function(e, t) {
                    var n = e.theme.spacing,
                        a = e.isMulti,
                        i = e.hasValue,
                        o = e.selectProps.controlShouldRenderValue;
                    return m({
                        alignItems: "center",
                        display: a && i && o ? "flex" : "grid",
                        flex: 1,
                        flexWrap: "wrap",
                        WebkitOverflowScrolling: "touch",
                        position: "relative",
                        overflow: "hidden"
                    }, t ? {} : {
                        padding: "".concat(n.baseUnit / 2, "px ").concat(2 * n.baseUnit, "px")
                    })
                },
                ty = function(e) {
                    var t = e.children,
                        n = e.innerProps,
                        a = e.isMulti,
                        i = e.hasValue;
                    return eV("div", z({}, e4(e, "valueContainer", {
                        "value-container": !0,
                        "value-container--is-multi": a,
                        "value-container--has-value": i
                    }), n), t)
                },
                tA = function() {
                    return {
                        alignItems: "center",
                        alignSelf: "stretch",
                        display: "flex",
                        flexShrink: 0
                    }
                },
                tS = function(e) {
                    var t = e.children,
                        n = e.innerProps;
                    return eV("div", z({}, e4(e, "indicatorsContainer", {
                        indicators: !0
                    }), n), t)
                },
                tE = ["size"],
                tU = {
                    name: "8mmkcg",
                    styles: "display:inline-block;fill:currentColor;line-height:1;stroke:currentColor;stroke-width:0"
                },
                tM = function(e) {
                    var t = e.size;
                    return eV("svg", z({
                        height: t,
                        width: t,
                        viewBox: "0 0 20 20",
                        "aria-hidden": "true",
                        focusable: "false",
                        css: tU
                    }, f(e, tE)))
                },
                tw = function(e) {
                    return eV(tM, z({
                        size: 20
                    }, e), eV("path", {
                        d: "M14.348 14.849c-0.469 0.469-1.229 0.469-1.697 0l-2.651-3.030-2.651 3.029c-0.469 0.469-1.229 0.469-1.697 0-0.469-0.469-0.469-1.229 0-1.697l2.758-3.15-2.759-3.152c-0.469-0.469-0.469-1.228 0-1.697s1.228-0.469 1.697 0l2.652 3.031 2.651-3.031c0.469-0.469 1.228-0.469 1.697 0s0.469 1.229 0 1.697l-2.758 3.152 2.758 3.15c0.469 0.469 0.469 1.229 0 1.698z"
                    }))
                },
                tP = function(e) {
                    return eV(tM, z({
                        size: 20
                    }, e), eV("path", {
                        d: "M4.516 7.548c0.436-0.446 1.043-0.481 1.576 0l3.908 3.747 3.908-3.747c0.533-0.481 1.141-0.446 1.574 0 0.436 0.445 0.408 1.197 0 1.615-0.406 0.418-4.695 4.502-4.695 4.502-0.217 0.223-0.502 0.335-0.787 0.335s-0.57-0.112-0.789-0.335c0 0-4.287-4.084-4.695-4.502s-0.436-1.17 0-1.615z"
                    }))
                },
                tk = function(e, t) {
                    var n = e.isFocused,
                        a = e.theme,
                        i = a.spacing.baseUnit,
                        o = a.colors;
                    return m({
                        label: "indicatorContainer",
                        display: "flex",
                        transition: "color 150ms"
                    }, t ? {} : {
                        color: n ? o.neutral60 : o.neutral20,
                        padding: 2 * i,
                        ":hover": {
                            color: n ? o.neutral80 : o.neutral40
                        }
                    })
                },
                tI = function(e) {
                    var t = e.children,
                        n = e.innerProps;
                    return eV("div", z({}, e4(e, "dropdownIndicator", {
                        indicator: !0,
                        "dropdown-indicator": !0
                    }), n), t || eV(tP, null))
                },
                tx = function(e) {
                    var t = e.children,
                        n = e.innerProps;
                    return eV("div", z({}, e4(e, "clearIndicator", {
                        indicator: !0,
                        "clear-indicator": !0
                    }), n), t || eV(tw, null))
                },
                tR = function(e, t) {
                    var n = e.isDisabled,
                        a = e.theme,
                        i = a.spacing.baseUnit,
                        o = a.colors;
                    return m({
                        label: "indicatorSeparator",
                        alignSelf: "stretch",
                        width: 1
                    }, t ? {} : {
                        backgroundColor: n ? o.neutral10 : o.neutral20,
                        marginBottom: 2 * i,
                        marginTop: 2 * i
                    })
                },
                tD = function(e) {
                    return eV("span", z({}, e.innerProps, e4(e, "indicatorSeparator", {
                        "indicator-separator": !0
                    })))
                },
                tL = function() {
                    var e = eB.apply(void 0, arguments),
                        t = "animation-" + e.name;
                    return {
                        name: t,
                        styles: "@keyframes " + t + "{" + e.styles + "}",
                        anim: 1,
                        toString: function() {
                            return "_EMO_" + this.name + "_" + this.styles + "_EMO_"
                        }
                    }
                }(N || (b = ["\n  0%, 80%, 100% { opacity: 0; }\n  40% { opacity: 1; }\n"], h || (h = b.slice(0)), N = Object.freeze(Object.defineProperties(b, {
                    raw: {
                        value: Object.freeze(h)
                    }
                })))),
                tV = function(e, t) {
                    var n = e.isFocused,
                        a = e.size,
                        i = e.theme,
                        o = i.colors,
                        r = i.spacing.baseUnit;
                    return m({
                        label: "loadingIndicator",
                        display: "flex",
                        transition: "color 150ms",
                        alignSelf: "center",
                        fontSize: a,
                        lineHeight: 1,
                        marginRight: a,
                        textAlign: "center",
                        verticalAlign: "middle"
                    }, t ? {} : {
                        color: n ? o.neutral60 : o.neutral20,
                        padding: 2 * r
                    })
                },
                tB = function(e) {
                    var t = e.delay,
                        n = e.offset;
                    return eV("span", {
                        css: eB({
                            animation: "".concat(tL, " 1s ease-in-out ").concat(t, "ms infinite;"),
                            backgroundColor: "currentColor",
                            borderRadius: "1em",
                            display: "inline-block",
                            marginLeft: n ? "1em" : void 0,
                            height: "1em",
                            verticalAlign: "top",
                            width: "1em"
                        }, "", "")
                    })
                },
                tF = function(e) {
                    var t = e.innerProps,
                        n = e.isRtl;
                    return eV("div", z({}, e4(e, "loadingIndicator", {
                        indicator: !0,
                        "loading-indicator": !0
                    }), t), eV(tB, {
                        delay: 0,
                        offset: n
                    }), eV(tB, {
                        delay: 160,
                        offset: !0
                    }), eV(tB, {
                        delay: 320,
                        offset: !n
                    }))
                };
            tF.defaultProps = {
                size: 4
            };
            var tG = function(e, t) {
                    var n = e.isDisabled,
                        a = e.isFocused,
                        i = e.theme,
                        o = i.colors,
                        r = i.borderRadius;
                    return m({
                        label: "control",
                        alignItems: "center",
                        cursor: "default",
                        display: "flex",
                        flexWrap: "wrap",
                        justifyContent: "space-between",
                        minHeight: i.spacing.controlHeight,
                        outline: "0 !important",
                        position: "relative",
                        transition: "all 100ms"
                    }, t ? {} : {
                        backgroundColor: n ? o.neutral5 : o.neutral0,
                        borderColor: n ? o.neutral10 : a ? o.primary : o.neutral20,
                        borderRadius: r,
                        borderStyle: "solid",
                        borderWidth: 1,
                        boxShadow: a ? "0 0 0 1px ".concat(o.primary) : void 0,
                        "&:hover": {
                            borderColor: a ? o.primary : o.neutral30
                        }
                    })
                },
                tH = function(e) {
                    var t = e.children,
                        n = e.isDisabled,
                        a = e.isFocused,
                        i = e.innerRef,
                        o = e.innerProps,
                        r = e.menuIsOpen;
                    return eV("div", z({
                        ref: i
                    }, e4(e, "control", {
                        control: !0,
                        "control--is-disabled": n,
                        "control--is-focused": a,
                        "control--menu-is-open": r
                    }), o), t)
                },
                t_ = ["data"],
                tj = function(e, t) {
                    var n = e.theme.spacing;
                    return t ? {} : {
                        paddingBottom: 2 * n.baseUnit,
                        paddingTop: 2 * n.baseUnit
                    }
                },
                tK = function(e) {
                    var t = e.children,
                        n = e.cx,
                        a = e.getStyles,
                        i = e.getClassNames,
                        o = e.Heading,
                        r = e.headingProps,
                        s = e.innerProps,
                        m = e.label,
                        u = e.theme,
                        l = e.selectProps;
                    return eV("div", z({}, e4(e, "group", {
                        group: !0
                    }), s), eV(o, z({}, r, {
                        selectProps: l,
                        theme: u,
                        getStyles: a,
                        getClassNames: i,
                        cx: n
                    }), m), eV("div", null, t))
                },
                tW = function(e, t) {
                    var n = e.theme,
                        a = n.colors,
                        i = n.spacing;
                    return m({
                        label: "group",
                        cursor: "default",
                        display: "block"
                    }, t ? {} : {
                        color: a.neutral40,
                        fontSize: "75%",
                        fontWeight: 500,
                        marginBottom: "0.25em",
                        paddingLeft: 3 * i.baseUnit,
                        paddingRight: 3 * i.baseUnit,
                        textTransform: "uppercase"
                    })
                },
                t$ = function(e) {
                    var t = e5(e);
                    t.data;
                    var n = f(t, t_);
                    return eV("div", z({}, e4(e, "groupHeading", {
                        "group-heading": !0
                    }), n))
                },
                tY = ["innerRef", "isDisabled", "isHidden", "inputClassName"],
                tZ = function(e, t) {
                    var n = e.isDisabled,
                        a = e.value,
                        i = e.theme,
                        o = i.spacing,
                        r = i.colors;
                    return m(m({
                        visibility: n ? "hidden" : "visible",
                        transform: a ? "translateZ(0)" : ""
                    }, tq), t ? {} : {
                        margin: o.baseUnit / 2,
                        paddingBottom: o.baseUnit / 2,
                        paddingTop: o.baseUnit / 2,
                        color: r.neutral80
                    })
                },
                tX = {
                    gridArea: "1 / 2",
                    font: "inherit",
                    minWidth: "2px",
                    border: 0,
                    margin: 0,
                    outline: 0,
                    padding: 0
                },
                tq = {
                    flex: "1 1 auto",
                    display: "inline-grid",
                    gridArea: "1 / 1 / 2 / 3",
                    gridTemplateColumns: "0 min-content",
                    "&:after": m({
                        content: 'attr(data-value) " "',
                        visibility: "hidden",
                        whiteSpace: "pre"
                    }, tX)
                },
                tJ = function(e, t) {
                    var n = e.theme,
                        a = n.spacing,
                        i = n.borderRadius,
                        o = n.colors;
                    return m({
                        label: "multiValue",
                        display: "flex",
                        minWidth: 0
                    }, t ? {} : {
                        backgroundColor: o.neutral10,
                        borderRadius: i / 2,
                        margin: a.baseUnit / 2
                    })
                },
                tQ = function(e, t) {
                    var n = e.theme,
                        a = n.borderRadius,
                        i = n.colors,
                        o = e.cropWithEllipsis;
                    return m({
                        overflow: "hidden",
                        textOverflow: o || void 0 === o ? "ellipsis" : void 0,
                        whiteSpace: "nowrap"
                    }, t ? {} : {
                        borderRadius: a / 2,
                        color: i.neutral80,
                        fontSize: "85%",
                        padding: 3,
                        paddingLeft: 6
                    })
                },
                t0 = function(e, t) {
                    var n = e.theme,
                        a = n.spacing,
                        i = n.borderRadius,
                        o = n.colors,
                        r = e.isFocused;
                    return m({
                        alignItems: "center",
                        display: "flex"
                    }, t ? {} : {
                        borderRadius: i / 2,
                        backgroundColor: r ? o.dangerLight : void 0,
                        paddingLeft: a.baseUnit,
                        paddingRight: a.baseUnit,
                        ":hover": {
                            backgroundColor: o.dangerLight,
                            color: o.danger
                        }
                    })
                },
                t1 = function(e) {
                    var t = e.children;
                    return eV("div", e.innerProps, t)
                },
                t3 = function(e, t) {
                    var n = e.isDisabled,
                        a = e.isFocused,
                        i = e.isSelected,
                        o = e.theme,
                        r = o.spacing,
                        s = o.colors;
                    return m({
                        label: "option",
                        cursor: "default",
                        display: "block",
                        fontSize: "inherit",
                        width: "100%",
                        userSelect: "none",
                        WebkitTapHighlightColor: "rgba(0, 0, 0, 0)"
                    }, t ? {} : {
                        backgroundColor: i ? s.primary : a ? s.primary25 : "transparent",
                        color: n ? s.neutral20 : i ? s.neutral0 : "inherit",
                        padding: "".concat(2 * r.baseUnit, "px ").concat(3 * r.baseUnit, "px"),
                        ":active": {
                            backgroundColor: n ? void 0 : i ? s.primary : s.primary50
                        }
                    })
                },
                t6 = function(e, t) {
                    var n = e.theme,
                        a = n.spacing,
                        i = n.colors;
                    return m({
                        label: "placeholder",
                        gridArea: "1 / 1 / 2 / 3"
                    }, t ? {} : {
                        color: i.neutral50,
                        marginLeft: a.baseUnit / 2,
                        marginRight: a.baseUnit / 2
                    })
                },
                t2 = function(e, t) {
                    var n = e.isDisabled,
                        a = e.theme,
                        i = a.spacing,
                        o = a.colors;
                    return m({
                        label: "singleValue",
                        gridArea: "1 / 1 / 2 / 3",
                        maxWidth: "100%",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap"
                    }, t ? {} : {
                        color: n ? o.neutral40 : o.neutral80,
                        marginLeft: i.baseUnit / 2,
                        marginRight: i.baseUnit / 2
                    })
                },
                t5 = {
                    ClearIndicator: tx,
                    Control: tH,
                    DropdownIndicator: tI,
                    DownChevron: tP,
                    CrossIcon: tw,
                    Group: tK,
                    GroupHeading: t$,
                    IndicatorsContainer: tS,
                    IndicatorSeparator: tD,
                    Input: function(e) {
                        var t = e.cx,
                            n = e.value,
                            a = e5(e),
                            i = a.innerRef,
                            o = a.isDisabled,
                            r = a.isHidden,
                            s = a.inputClassName,
                            u = f(a, tY);
                        return eV("div", z({}, e4(e, "input", {
                            "input-container": !0
                        }), {
                            "data-value": n || ""
                        }), eV("input", z({
                            className: t({
                                input: !0
                            }, s),
                            ref: i,
                            style: m({
                                label: "input",
                                color: "inherit",
                                background: 0,
                                opacity: r ? 0 : 1,
                                width: "100%"
                            }, tX),
                            disabled: o
                        }, u)))
                    },
                    LoadingIndicator: tF,
                    Menu: td,
                    MenuList: tp,
                    MenuPortal: tv,
                    LoadingMessage: tT,
                    NoOptionsMessage: th,
                    MultiValue: function(e) {
                        var t = e.children,
                            n = e.components,
                            a = e.data,
                            i = e.innerProps,
                            o = e.isDisabled,
                            r = e.removeProps,
                            s = e.selectProps,
                            u = n.Container,
                            l = n.Label,
                            c = n.Remove;
                        return eV(u, {
                            data: a,
                            innerProps: m(m({}, e4(e, "multiValue", {
                                "multi-value": !0,
                                "multi-value--is-disabled": o
                            })), i),
                            selectProps: s
                        }, eV(l, {
                            data: a,
                            innerProps: m({}, e4(e, "multiValueLabel", {
                                "multi-value__label": !0
                            })),
                            selectProps: s
                        }, t), eV(c, {
                            data: a,
                            innerProps: m(m({}, e4(e, "multiValueRemove", {
                                "multi-value__remove": !0
                            })), {}, {
                                "aria-label": "Remove ".concat(t || "option")
                            }, r),
                            selectProps: s
                        }))
                    },
                    MultiValueContainer: t1,
                    MultiValueLabel: t1,
                    MultiValueRemove: function(e) {
                        var t = e.children;
                        return eV("div", z({
                            role: "button"
                        }, e.innerProps), t || eV(tw, {
                            size: 14
                        }))
                    },
                    Option: function(e) {
                        var t = e.children,
                            n = e.isDisabled,
                            a = e.isFocused,
                            i = e.isSelected,
                            o = e.innerRef,
                            r = e.innerProps;
                        return eV("div", z({}, e4(e, "option", {
                            option: !0,
                            "option--is-disabled": n,
                            "option--is-focused": a,
                            "option--is-selected": i
                        }), {
                            ref: o,
                            "aria-disabled": n
                        }, r), t)
                    },
                    Placeholder: function(e) {
                        var t = e.children,
                            n = e.innerProps;
                        return eV("div", z({}, e4(e, "placeholder", {
                            placeholder: !0
                        }), n), t)
                    },
                    SelectContainer: tO,
                    SingleValue: function(e) {
                        var t = e.children,
                            n = e.isDisabled,
                            a = e.innerProps;
                        return eV("div", z({}, e4(e, "singleValue", {
                            "single-value": !0,
                            "single-value--is-disabled": n
                        }), a), t)
                    },
                    ValueContainer: ty
                },
                t4 = Number.isNaN || function(e) {
                    return "number" == typeof e && e != e
                };

            function t8(e, t) {
                if (e.length !== t.length) return !1;
                for (var n, a, i = 0; i < e.length; i++)
                    if (!((n = e[i]) === (a = t[i]) || t4(n) && t4(a))) return !1;
                return !0
            }
            for (var t9 = {
                    name: "7pg0cj-a11yText",
                    styles: "label:a11yText;z-index:9999;border:0;clip:rect(1px, 1px, 1px, 1px);height:1px;width:1px;position:absolute;overflow:hidden;padding:0;white-space:nowrap"
                }, t7 = function(e) {
                    return eV("span", z({
                        css: t9
                    }, e))
                }, ne = {
                    guidance: function(e) {
                        var t = e.isSearchable,
                            n = e.isMulti,
                            a = e.isDisabled,
                            i = e.tabSelectsValue,
                            o = e.context;
                        switch (o) {
                            case "menu":
                                return "Use Up and Down to choose options".concat(a ? "" : ", press Enter to select the currently focused option", ", press Escape to exit the menu").concat(i ? ", press Tab to select the option and exit the menu" : "", ".");
                            case "input":
                                return "".concat(e["aria-label"] || "Select", " is focused ").concat(t ? ",type to refine list" : "", ", press Down to open the menu, ").concat(n ? " press left to focus selected values" : "");
                            case "value":
                                return "Use left and right to toggle between focused values, press Backspace to remove the currently focused value";
                            default:
                                return ""
                        }
                    },
                    onChange: function(e) {
                        var t = e.action,
                            n = e.label,
                            a = void 0 === n ? "" : n,
                            i = e.labels,
                            o = e.isDisabled;
                        switch (t) {
                            case "deselect-option":
                            case "pop-value":
                            case "remove-value":
                                return "option ".concat(a, ", deselected.");
                            case "clear":
                                return "All selected options have been cleared.";
                            case "initial-input-focus":
                                return "option".concat(i.length > 1 ? "s" : "", " ").concat(i.join(","), ", selected.");
                            case "select-option":
                                return o ? "option ".concat(a, " is disabled. Select another option.") : "option ".concat(a, ", selected.");
                            default:
                                return ""
                        }
                    },
                    onFocus: function(e) {
                        var t = e.context,
                            n = e.focused,
                            a = e.options,
                            i = e.label,
                            o = void 0 === i ? "" : i,
                            r = e.selectValue,
                            s = e.isDisabled,
                            m = e.isSelected,
                            u = function(e, t) {
                                return e && e.length ? "".concat(e.indexOf(t) + 1, " of ").concat(e.length) : ""
                            };
                        if ("value" === t && r) return "value ".concat(o, " focused, ").concat(u(r, n), ".");
                        if ("menu" === t) {
                            var l = "".concat(m ? "selected" : "focused").concat(s ? " disabled" : "");
                            return "option ".concat(o, " ").concat(l, ", ").concat(u(a, n), ".")
                        }
                        return ""
                    },
                    onFilter: function(e) {
                        var t = e.inputValue,
                            n = e.resultsMessage;
                        return "".concat(n).concat(t ? " for search term " + t : "", ".")
                    }
                }, nt = function(e) {
                    var t = e.ariaSelection,
                        n = e.focusedOption,
                        a = e.focusedValue,
                        i = e.focusableOptions,
                        o = e.isFocused,
                        r = e.selectValue,
                        s = e.selectProps,
                        u = e.id,
                        l = s.ariaLiveMessages,
                        c = s.getOptionLabel,
                        f = s.inputValue,
                        d = s.isMulti,
                        g = s.isOptionDisabled,
                        p = s.isSearchable,
                        b = s.menuIsOpen,
                        h = s.options,
                        T = s.screenReaderStatus,
                        N = s.tabSelectsValue,
                        C = s["aria-label"],
                        O = s["aria-live"],
                        z = (0, v.useMemo)(function() {
                            return m(m({}, ne), l || {})
                        }, [l]),
                        y = (0, v.useMemo)(function() {
                            var e = "";
                            if (t && z.onChange) {
                                var n = t.option,
                                    a = t.options,
                                    i = t.removedValue,
                                    o = t.removedValues,
                                    s = t.value,
                                    u = i || n || (Array.isArray(s) ? null : s),
                                    l = u ? c(u) : "",
                                    f = a || o || void 0,
                                    d = f ? f.map(c) : [],
                                    p = m({
                                        isDisabled: u && g(u, r),
                                        label: l,
                                        labels: d
                                    }, t);
                                e = z.onChange(p)
                            }
                            return e
                        }, [t, z, g, r, c]),
                        A = (0, v.useMemo)(function() {
                            var e = "",
                                t = n || a,
                                o = !!(n && r && r.includes(n));
                            if (t && z.onFocus) {
                                var s = {
                                    focused: t,
                                    label: c(t),
                                    isDisabled: g(t, r),
                                    isSelected: o,
                                    options: i,
                                    context: t === n ? "menu" : "value",
                                    selectValue: r
                                };
                                e = z.onFocus(s)
                            }
                            return e
                        }, [n, a, c, g, z, i, r]),
                        S = (0, v.useMemo)(function() {
                            var e = "";
                            if (b && h.length && z.onFilter) {
                                var t = T({
                                    count: i.length
                                });
                                e = z.onFilter({
                                    inputValue: f,
                                    resultsMessage: t
                                })
                            }
                            return e
                        }, [i, f, b, z, h, T]),
                        E = (0, v.useMemo)(function() {
                            var e = "";
                            return z.guidance && (e = z.guidance({
                                "aria-label": C,
                                context: a ? "value" : b ? "menu" : "input",
                                isDisabled: n && g(n, r),
                                isMulti: d,
                                isSearchable: p,
                                tabSelectsValue: N
                            })), e
                        }, [C, n, a, d, g, p, b, z, r, N]),
                        U = "".concat(A, " ").concat(S, " ").concat(E),
                        M = eV(v.Fragment, null, eV("span", {
                            id: "aria-selection"
                        }, y), eV("span", {
                            id: "aria-context"
                        }, U)),
                        w = (null == t ? void 0 : t.action) === "initial-input-focus";
                    return eV(v.Fragment, null, eV(t7, {
                        id: u
                    }, w && M), eV(t7, {
                        "aria-live": O,
                        "aria-atomic": "false",
                        "aria-relevant": "additions text"
                    }, o && !w && M))
                }, nn = [{
                    base: "A",
                    letters: "AⒶＡ\xc0\xc1\xc2ẦẤẪẨ\xc3ĀĂẰẮẴẲȦǠ\xc4ǞẢ\xc5ǺǍȀȂẠẬẶḀĄȺⱯ"
                }, {
                    base: "AA",
                    letters: "Ꜳ"
                }, {
                    base: "AE",
                    letters: "\xc6ǼǢ"
                }, {
                    base: "AO",
                    letters: "Ꜵ"
                }, {
                    base: "AU",
                    letters: "Ꜷ"
                }, {
                    base: "AV",
                    letters: "ꜸꜺ"
                }, {
                    base: "AY",
                    letters: "Ꜽ"
                }, {
                    base: "B",
                    letters: "BⒷＢḂḄḆɃƂƁ"
                }, {
                    base: "C",
                    letters: "CⒸＣĆĈĊČ\xc7ḈƇȻꜾ"
                }, {
                    base: "D",
                    letters: "DⒹＤḊĎḌḐḒḎĐƋƊƉꝹ"
                }, {
                    base: "DZ",
                    letters: "ǱǄ"
                }, {
                    base: "Dz",
                    letters: "ǲǅ"
                }, {
                    base: "E",
                    letters: "EⒺＥ\xc8\xc9\xcaỀẾỄỂẼĒḔḖĔĖ\xcbẺĚȄȆẸỆȨḜĘḘḚƐƎ"
                }, {
                    base: "F",
                    letters: "FⒻＦḞƑꝻ"
                }, {
                    base: "G",
                    letters: "GⒼＧǴĜḠĞĠǦĢǤƓꞠꝽꝾ"
                }, {
                    base: "H",
                    letters: "HⒽＨĤḢḦȞḤḨḪĦⱧⱵꞍ"
                }, {
                    base: "I",
                    letters: "IⒾＩ\xcc\xcd\xceĨĪĬİ\xcfḮỈǏȈȊỊĮḬƗ"
                }, {
                    base: "J",
                    letters: "JⒿＪĴɈ"
                }, {
                    base: "K",
                    letters: "KⓀＫḰǨḲĶḴƘⱩꝀꝂꝄꞢ"
                }, {
                    base: "L",
                    letters: "LⓁＬĿĹĽḶḸĻḼḺŁȽⱢⱠꝈꝆꞀ"
                }, {
                    base: "LJ",
                    letters: "Ǉ"
                }, {
                    base: "Lj",
                    letters: "ǈ"
                }, {
                    base: "M",
                    letters: "MⓂＭḾṀṂⱮƜ"
                }, {
                    base: "N",
                    letters: "NⓃＮǸŃ\xd1ṄŇṆŅṊṈȠƝꞐꞤ"
                }, {
                    base: "NJ",
                    letters: "Ǌ"
                }, {
                    base: "Nj",
                    letters: "ǋ"
                }, {
                    base: "O",
                    letters: "OⓄＯ\xd2\xd3\xd4ỒỐỖỔ\xd5ṌȬṎŌṐṒŎȮȰ\xd6ȪỎŐǑȌȎƠỜỚỠỞỢỌỘǪǬ\xd8ǾƆƟꝊꝌ"
                }, {
                    base: "OI",
                    letters: "Ƣ"
                }, {
                    base: "OO",
                    letters: "Ꝏ"
                }, {
                    base: "OU",
                    letters: "Ȣ"
                }, {
                    base: "P",
                    letters: "PⓅＰṔṖƤⱣꝐꝒꝔ"
                }, {
                    base: "Q",
                    letters: "QⓆＱꝖꝘɊ"
                }, {
                    base: "R",
                    letters: "RⓇＲŔṘŘȐȒṚṜŖṞɌⱤꝚꞦꞂ"
                }, {
                    base: "S",
                    letters: "SⓈＳẞŚṤŜṠŠṦṢṨȘŞⱾꞨꞄ"
                }, {
                    base: "T",
                    letters: "TⓉＴṪŤṬȚŢṰṮŦƬƮȾꞆ"
                }, {
                    base: "TZ",
                    letters: "Ꜩ"
                }, {
                    base: "U",
                    letters: "UⓊＵ\xd9\xda\xdbŨṸŪṺŬ\xdcǛǗǕǙỦŮŰǓȔȖƯỪỨỮỬỰỤṲŲṶṴɄ"
                }, {
                    base: "V",
                    letters: "VⓋＶṼṾƲꝞɅ"
                }, {
                    base: "VY",
                    letters: "Ꝡ"
                }, {
                    base: "W",
                    letters: "WⓌＷẀẂŴẆẄẈⱲ"
                }, {
                    base: "X",
                    letters: "XⓍＸẊẌ"
                }, {
                    base: "Y",
                    letters: "YⓎＹỲ\xddŶỸȲẎŸỶỴƳɎỾ"
                }, {
                    base: "Z",
                    letters: "ZⓏＺŹẐŻŽẒẔƵȤⱿⱫꝢ"
                }, {
                    base: "a",
                    letters: "aⓐａẚ\xe0\xe1\xe2ầấẫẩ\xe3āăằắẵẳȧǡ\xe4ǟả\xe5ǻǎȁȃạậặḁąⱥɐ"
                }, {
                    base: "aa",
                    letters: "ꜳ"
                }, {
                    base: "ae",
                    letters: "\xe6ǽǣ"
                }, {
                    base: "ao",
                    letters: "ꜵ"
                }, {
                    base: "au",
                    letters: "ꜷ"
                }, {
                    base: "av",
                    letters: "ꜹꜻ"
                }, {
                    base: "ay",
                    letters: "ꜽ"
                }, {
                    base: "b",
                    letters: "bⓑｂḃḅḇƀƃɓ"
                }, {
                    base: "c",
                    letters: "cⓒｃćĉċč\xe7ḉƈȼꜿↄ"
                }, {
                    base: "d",
                    letters: "dⓓｄḋďḍḑḓḏđƌɖɗꝺ"
                }, {
                    base: "dz",
                    letters: "ǳǆ"
                }, {
                    base: "e",
                    letters: "eⓔｅ\xe8\xe9\xeaềếễểẽēḕḗĕė\xebẻěȅȇẹệȩḝęḙḛɇɛǝ"
                }, {
                    base: "f",
                    letters: "fⓕｆḟƒꝼ"
                }, {
                    base: "g",
                    letters: "gⓖｇǵĝḡğġǧģǥɠꞡᵹꝿ"
                }, {
                    base: "h",
                    letters: "hⓗｈĥḣḧȟḥḩḫẖħⱨⱶɥ"
                }, {
                    base: "hv",
                    letters: "ƕ"
                }, {
                    base: "i",
                    letters: "iⓘｉ\xec\xed\xeeĩīĭ\xefḯỉǐȉȋịįḭɨı"
                }, {
                    base: "j",
                    letters: "jⓙｊĵǰɉ"
                }, {
                    base: "k",
                    letters: "kⓚｋḱǩḳķḵƙⱪꝁꝃꝅꞣ"
                }, {
                    base: "l",
                    letters: "lⓛｌŀĺľḷḹļḽḻſłƚɫⱡꝉꞁꝇ"
                }, {
                    base: "lj",
                    letters: "ǉ"
                }, {
                    base: "m",
                    letters: "mⓜｍḿṁṃɱɯ"
                }, {
                    base: "n",
                    letters: "nⓝｎǹń\xf1ṅňṇņṋṉƞɲŉꞑꞥ"
                }, {
                    base: "nj",
                    letters: "ǌ"
                }, {
                    base: "o",
                    letters: "oⓞｏ\xf2\xf3\xf4ồốỗổ\xf5ṍȭṏōṑṓŏȯȱ\xf6ȫỏőǒȍȏơờớỡởợọộǫǭ\xf8ǿɔꝋꝍɵ"
                }, {
                    base: "oi",
                    letters: "ƣ"
                }, {
                    base: "ou",
                    letters: "ȣ"
                }, {
                    base: "oo",
                    letters: "ꝏ"
                }, {
                    base: "p",
                    letters: "pⓟｐṕṗƥᵽꝑꝓꝕ"
                }, {
                    base: "q",
                    letters: "qⓠｑɋꝗꝙ"
                }, {
                    base: "r",
                    letters: "rⓡｒŕṙřȑȓṛṝŗṟɍɽꝛꞧꞃ"
                }, {
                    base: "s",
                    letters: "sⓢｓ\xdfśṥŝṡšṧṣṩșşȿꞩꞅẛ"
                }, {
                    base: "t",
                    letters: "tⓣｔṫẗťṭțţṱṯŧƭʈⱦꞇ"
                }, {
                    base: "tz",
                    letters: "ꜩ"
                }, {
                    base: "u",
                    letters: "uⓤｕ\xf9\xfa\xfbũṹūṻŭ\xfcǜǘǖǚủůűǔȕȗưừứữửựụṳųṷṵʉ"
                }, {
                    base: "v",
                    letters: "vⓥｖṽṿʋꝟʌ"
                }, {
                    base: "vy",
                    letters: "ꝡ"
                }, {
                    base: "w",
                    letters: "wⓦｗẁẃŵẇẅẘẉⱳ"
                }, {
                    base: "x",
                    letters: "xⓧｘẋẍ"
                }, {
                    base: "y",
                    letters: "yⓨｙỳ\xfdŷỹȳẏ\xffỷẙỵƴɏỿ"
                }, {
                    base: "z",
                    letters: "zⓩｚźẑżžẓẕƶȥɀⱬꝣ"
                }], na = RegExp("[" + nn.map(function(e) {
                    return e.letters
                }).join("") + "]", "g"), ni = {}, no = 0; no < nn.length; no++)
                for (var nr = nn[no], ns = 0; ns < nr.letters.length; ns++) ni[nr.letters[ns]] = nr.base;
            var nm = function(e) {
                    return e.replace(na, function(e) {
                        return ni[e]
                    })
                },
                nu = function(e, t) {
                    void 0 === t && (t = t8);
                    var n = null;

                    function a() {
                        for (var a = [], i = 0; i < arguments.length; i++) a[i] = arguments[i];
                        if (n && n.lastThis === this && t(a, n.lastArgs)) return n.lastResult;
                        var o = e.apply(this, a);
                        return n = {
                            lastResult: o,
                            lastArgs: a,
                            lastThis: this
                        }, o
                    }
                    return a.clear = function() {
                        n = null
                    }, a
                }(nm),
                nl = function(e) {
                    return e.replace(/^\s+|\s+$/g, "")
                },
                nc = function(e) {
                    return "".concat(e.label, " ").concat(e.value)
                },
                nf = ["innerRef"];

            function nd(e) {
                return eV("input", z({
                    ref: e.innerRef
                }, tm(f(e, nf), "onExited", "in", "enter", "exit", "appear"), {
                    css: eB({
                        label: "dummyInput",
                        background: 0,
                        border: 0,
                        caretColor: "transparent",
                        fontSize: "inherit",
                        gridArea: "1 / 1 / 2 / 3",
                        outline: 0,
                        padding: 0,
                        width: 1,
                        color: "transparent",
                        left: -100,
                        opacity: 0,
                        position: "relative",
                        transform: "scale(.01)"
                    }, "", "")
                }))
            }
            var ng = function(e) {
                    e.preventDefault(), e.stopPropagation()
                },
                np = ["boxSizing", "height", "overflow", "paddingRight", "position"],
                nb = {
                    boxSizing: "border-box",
                    overflow: "hidden",
                    position: "relative",
                    height: "100%"
                };

            function nh(e) {
                e.preventDefault()
            }

            function nT(e) {
                e.stopPropagation()
            }

            function nN() {
                var e = this.scrollTop,
                    t = this.scrollHeight,
                    n = e + this.offsetHeight;
                0 === e ? this.scrollTop = 1 : n === t && (this.scrollTop = e - 1)
            }

            function nv() {
                return "ontouchstart" in window || navigator.maxTouchPoints
            }
            var nC = !!("undefined" != typeof window && window.document && window.document.createElement),
                nO = 0,
                nz = {
                    capture: !1,
                    passive: !1
                },
                ny = function() {
                    return document.activeElement && document.activeElement.blur()
                },
                nA = {
                    name: "1kfdb0e",
                    styles: "position:fixed;left:0;bottom:0;right:0;top:0"
                };

            function nS(e) {
                var t, n, a, i, o, r, s, m, u, l, c, f, d, g, p, b, h, T, N, C, O, z, y, A, S = e.children,
                    E = e.lockEnabled,
                    U = e.captureEnabled,
                    M = (n = (t = {
                        isEnabled: void 0 === U || U,
                        onBottomArrive: e.onBottomArrive,
                        onBottomLeave: e.onBottomLeave,
                        onTopArrive: e.onTopArrive,
                        onTopLeave: e.onTopLeave
                    }).isEnabled, a = t.onBottomArrive, i = t.onBottomLeave, o = t.onTopArrive, r = t.onTopLeave, s = (0, v.useRef)(!1), m = (0, v.useRef)(!1), u = (0, v.useRef)(0), l = (0, v.useRef)(null), c = (0, v.useCallback)(function(e, t) {
                        if (null !== l.current) {
                            var n = l.current,
                                u = n.scrollTop,
                                c = n.scrollHeight,
                                f = n.clientHeight,
                                d = l.current,
                                g = t > 0,
                                p = c - f - u,
                                b = !1;
                            p > t && s.current && (i && i(e), s.current = !1), g && m.current && (r && r(e), m.current = !1), g && t > p ? (a && !s.current && a(e), d.scrollTop = c, b = !0, s.current = !0) : !g && -t > u && (o && !m.current && o(e), d.scrollTop = 0, b = !0, m.current = !0), b && ng(e)
                        }
                    }, [a, i, o, r]), f = (0, v.useCallback)(function(e) {
                        c(e, e.deltaY)
                    }, [c]), d = (0, v.useCallback)(function(e) {
                        u.current = e.changedTouches[0].clientY
                    }, []), g = (0, v.useCallback)(function(e) {
                        var t = u.current - e.changedTouches[0].clientY;
                        c(e, t)
                    }, [c]), p = (0, v.useCallback)(function(e) {
                        if (e) {
                            var t = !!tr && {
                                passive: !1
                            };
                            e.addEventListener("wheel", f, t), e.addEventListener("touchstart", d, t), e.addEventListener("touchmove", g, t)
                        }
                    }, [g, d, f]), b = (0, v.useCallback)(function(e) {
                        e && (e.removeEventListener("wheel", f, !1), e.removeEventListener("touchstart", d, !1), e.removeEventListener("touchmove", g, !1))
                    }, [g, d, f]), (0, v.useEffect)(function() {
                        if (n) {
                            var e = l.current;
                            return p(e),
                                function() {
                                    b(e)
                                }
                        }
                    }, [n, p, b]), function(e) {
                        l.current = e
                    }),
                    w = (T = (h = {
                        isEnabled: E
                    }).isEnabled, C = void 0 === (N = h.accountForScrollbars) || N, O = (0, v.useRef)({}), z = (0, v.useRef)(null), y = (0, v.useCallback)(function(e) {
                        if (nC) {
                            var t = document.body,
                                n = t && t.style;
                            if (C && np.forEach(function(e) {
                                    var t = n && n[e];
                                    O.current[e] = t
                                }), C && nO < 1) {
                                var a = parseInt(O.current.paddingRight, 10) || 0,
                                    i = document.body ? document.body.clientWidth : 0,
                                    o = window.innerWidth - i + a || 0;
                                Object.keys(nb).forEach(function(e) {
                                    var t = nb[e];
                                    n && (n[e] = t)
                                }), n && (n.paddingRight = "".concat(o, "px"))
                            }
                            t && nv() && (t.addEventListener("touchmove", nh, nz), e && (e.addEventListener("touchstart", nN, nz), e.addEventListener("touchmove", nT, nz))), nO += 1
                        }
                    }, [C]), A = (0, v.useCallback)(function(e) {
                        if (nC) {
                            var t = document.body,
                                n = t && t.style;
                            nO = Math.max(nO - 1, 0), C && nO < 1 && np.forEach(function(e) {
                                var t = O.current[e];
                                n && (n[e] = t)
                            }), t && nv() && (t.removeEventListener("touchmove", nh, nz), e && (e.removeEventListener("touchstart", nN, nz), e.removeEventListener("touchmove", nT, nz)))
                        }
                    }, [C]), (0, v.useEffect)(function() {
                        if (T) {
                            var e = z.current;
                            return y(e),
                                function() {
                                    A(e)
                                }
                        }
                    }, [T, y, A]), function(e) {
                        z.current = e
                    }),
                    P = function(e) {
                        M(e), w(e)
                    };
                return eV(v.Fragment, null, E && eV("div", {
                    onClick: ny,
                    css: nA
                }), S(P))
            }
            var nE = {
                    name: "1a0ro4n-requiredInput",
                    styles: "label:requiredInput;opacity:0;pointer-events:none;position:absolute;bottom:0;left:0;right:0;width:100%"
                },
                nU = function(e) {
                    return eV("input", {
                        required: !0,
                        name: e.name,
                        tabIndex: -1,
                        onFocus: e.onFocus,
                        css: nE,
                        value: "",
                        onChange: function() {}
                    })
                },
                nM = function(e) {
                    return e.label
                },
                nw = function(e) {
                    return e.label
                },
                nP = function(e) {
                    return e.value
                },
                nk = function(e) {
                    return !!e.isDisabled
                },
                nI = {
                    clearIndicator: tk,
                    container: tC,
                    control: tG,
                    dropdownIndicator: tk,
                    group: tj,
                    groupHeading: tW,
                    indicatorsContainer: tA,
                    indicatorSeparator: tR,
                    input: tZ,
                    loadingIndicator: tV,
                    loadingMessage: tb,
                    menu: tl,
                    menuList: tg,
                    menuPortal: tN,
                    multiValue: tJ,
                    multiValueLabel: tQ,
                    multiValueRemove: t0,
                    noOptionsMessage: tb,
                    option: t3,
                    placeholder: t6,
                    singleValue: t2,
                    valueContainer: tz
                },
                nx = {
                    borderRadius: 4,
                    colors: {
                        primary: "#2684FF",
                        primary75: "#4C9AFF",
                        primary50: "#B2D4FF",
                        primary25: "#DEEBFF",
                        danger: "#DE350B",
                        dangerLight: "#FFBDAD",
                        neutral0: "hsl(0, 0%, 100%)",
                        neutral5: "hsl(0, 0%, 95%)",
                        neutral10: "hsl(0, 0%, 90%)",
                        neutral20: "hsl(0, 0%, 80%)",
                        neutral30: "hsl(0, 0%, 70%)",
                        neutral40: "hsl(0, 0%, 60%)",
                        neutral50: "hsl(0, 0%, 50%)",
                        neutral60: "hsl(0, 0%, 40%)",
                        neutral70: "hsl(0, 0%, 30%)",
                        neutral80: "hsl(0, 0%, 20%)",
                        neutral90: "hsl(0, 0%, 10%)"
                    },
                    spacing: {
                        baseUnit: 4,
                        controlHeight: 38,
                        menuGutter: 8
                    }
                },
                nR = {
                    "aria-live": "polite",
                    backspaceRemovesValue: !0,
                    blurInputOnSelect: tn(),
                    captureMenuScroll: !tn(),
                    classNames: {},
                    closeMenuOnSelect: !0,
                    closeMenuOnScroll: !1,
                    components: {},
                    controlShouldRenderValue: !0,
                    escapeClearsValue: !1,
                    filterOption: function(e, t) {
                        if (e.data.__isNew__) return !0;
                        var n = m({
                                ignoreCase: !0,
                                ignoreAccents: !0,
                                stringify: nc,
                                trim: !0,
                                matchFrom: "any"
                            }, void 0),
                            a = n.ignoreCase,
                            i = n.ignoreAccents,
                            o = n.stringify,
                            r = n.trim,
                            s = n.matchFrom,
                            u = r ? nl(t) : t,
                            l = r ? nl(o(e)) : o(e);
                        return a && (u = u.toLowerCase(), l = l.toLowerCase()), i && (u = nu(u), l = nm(l)), "start" === s ? l.substr(0, u.length) === u : l.indexOf(u) > -1
                    },
                    formatGroupLabel: nM,
                    getOptionLabel: nw,
                    getOptionValue: nP,
                    isDisabled: !1,
                    isLoading: !1,
                    isMulti: !1,
                    isRtl: !1,
                    isSearchable: !0,
                    isOptionDisabled: nk,
                    loadingMessage: function() {
                        return "Loading..."
                    },
                    maxMenuHeight: 300,
                    minMenuHeight: 140,
                    menuIsOpen: !1,
                    menuPlacement: "bottom",
                    menuPosition: "absolute",
                    menuShouldBlockScroll: !1,
                    menuShouldScrollIntoView: ! function() {
                        try {
                            return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)
                        } catch (e) {
                            return !1
                        }
                    }(),
                    noOptionsMessage: function() {
                        return "No options"
                    },
                    openMenuOnFocus: !1,
                    openMenuOnClick: !0,
                    options: [],
                    pageSize: 5,
                    placeholder: "Select...",
                    screenReaderStatus: function(e) {
                        var t = e.count;
                        return "".concat(t, " result").concat(1 !== t ? "s" : "", " available")
                    },
                    styles: {},
                    tabIndex: 0,
                    tabSelectsValue: !0,
                    unstyled: !1
                };

            function nD(e, t, n, a) {
                var i = nH(e, t, n),
                    o = n_(e, t, n),
                    r = nF(e, t),
                    s = nG(e, t);
                return {
                    type: "option",
                    data: t,
                    isDisabled: i,
                    isSelected: o,
                    label: r,
                    value: s,
                    index: a
                }
            }

            function nL(e, t) {
                return e.options.map(function(n, a) {
                    if ("options" in n) {
                        var i = n.options.map(function(n, a) {
                            return nD(e, n, t, a)
                        }).filter(function(t) {
                            return nB(e, t)
                        });
                        return i.length > 0 ? {
                            type: "group",
                            data: n,
                            options: i,
                            index: a
                        } : void 0
                    }
                    var o = nD(e, n, t, a);
                    return nB(e, o) ? o : void 0
                }).filter(ts)
            }

            function nV(e) {
                return e.reduce(function(e, t) {
                    return "group" === t.type ? e.push.apply(e, E(t.options.map(function(e) {
                        return e.data
                    }))) : e.push(t.data), e
                }, [])
            }

            function nB(e, t) {
                var n = e.inputValue,
                    a = t.data,
                    i = t.isSelected,
                    o = t.label,
                    r = t.value;
                return (!nK(e) || !i) && nj(e, {
                    label: o,
                    value: r,
                    data: a
                }, void 0 === n ? "" : n)
            }
            var nF = function(e, t) {
                    return e.getOptionLabel(t)
                },
                nG = function(e, t) {
                    return e.getOptionValue(t)
                };

            function nH(e, t, n) {
                return "function" == typeof e.isOptionDisabled && e.isOptionDisabled(t, n)
            }

            function n_(e, t, n) {
                if (n.indexOf(t) > -1) return !0;
                if ("function" == typeof e.isOptionSelected) return e.isOptionSelected(t, n);
                var a = nG(e, t);
                return n.some(function(t) {
                    return nG(e, t) === a
                })
            }

            function nj(e, t, n) {
                return !e.filterOption || e.filterOption(t, n)
            }
            var nK = function(e) {
                    var t = e.hideSelectedOptions,
                        n = e.isMulti;
                    return void 0 === t ? n : t
                },
                nW = 1,
                n$ = function(e) {
                    ! function(e, t) {
                        if ("function" != typeof t && null !== t) throw TypeError("Super expression must either be null or a function");
                        e.prototype = Object.create(t && t.prototype, {
                            constructor: {
                                value: e,
                                writable: !0,
                                configurable: !0
                            }
                        }), Object.defineProperty(e, "prototype", {
                            writable: !1
                        }), t && A(e, t)
                    }(r, e);
                    var t, n, a, o = (t = function() {
                        if ("undefined" == typeof Reflect || !Reflect.construct || Reflect.construct.sham) return !1;
                        if ("function" == typeof Proxy) return !0;
                        try {
                            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), !0
                        } catch (e) {
                            return !1
                        }
                    }(), function() {
                        var e, n = S(r);
                        if (t) {
                            var a = S(this).constructor;
                            e = Reflect.construct(n, arguments, a)
                        } else e = n.apply(this, arguments);
                        return function(e, t) {
                            if (t && ("object" === i(t) || "function" == typeof t)) return t;
                            if (void 0 !== t) throw TypeError("Derived constructors may only return object or undefined");
                            return function(e) {
                                if (void 0 === e) throw ReferenceError("this hasn't been initialised - super() hasn't been called");
                                return e
                            }(e)
                        }(this, e)
                    });

                    function r(e) {
                        var t;
                        if (! function(e, t) {
                                if (!(e instanceof t)) throw TypeError("Cannot call a class as a function")
                            }(this, r), (t = o.call(this, e)).state = {
                                ariaSelection: null,
                                focusedOption: null,
                                focusedValue: null,
                                inputIsHidden: !1,
                                isFocused: !1,
                                selectValue: [],
                                clearFocusValueOnUpdate: !1,
                                prevWasFocused: !1,
                                inputIsHiddenAfterUpdate: void 0,
                                prevProps: void 0
                            }, t.blockOptionHover = !1, t.isComposing = !1, t.commonProps = void 0, t.initialTouchX = 0, t.initialTouchY = 0, t.instancePrefix = "", t.openAfterFocus = !1, t.scrollToFocusedOptionOnUpdate = !1, t.userIsDragging = void 0, t.controlRef = null, t.getControlRef = function(e) {
                                t.controlRef = e
                            }, t.focusedOptionRef = null, t.getFocusedOptionRef = function(e) {
                                t.focusedOptionRef = e
                            }, t.menuListRef = null, t.getMenuListRef = function(e) {
                                t.menuListRef = e
                            }, t.inputRef = null, t.getInputRef = function(e) {
                                t.inputRef = e
                            }, t.focus = t.focusInput, t.blur = t.blurInput, t.onChange = function(e, n) {
                                var a = t.props,
                                    i = a.onChange,
                                    o = a.name;
                                n.name = o, t.ariaOnChange(e, n), i(e, n)
                            }, t.setValue = function(e, n, a) {
                                var i = t.props,
                                    o = i.closeMenuOnSelect,
                                    r = i.isMulti,
                                    s = i.inputValue;
                                t.onInputChange("", {
                                    action: "set-value",
                                    prevInputValue: s
                                }), o && (t.setState({
                                    inputIsHiddenAfterUpdate: !r
                                }), t.onMenuClose()), t.setState({
                                    clearFocusValueOnUpdate: !0
                                }), t.onChange(e, {
                                    action: n,
                                    option: a
                                })
                            }, t.selectOption = function(e) {
                                var n = t.props,
                                    a = n.blurInputOnSelect,
                                    i = n.isMulti,
                                    o = n.name,
                                    r = t.state.selectValue,
                                    s = i && t.isOptionSelected(e, r),
                                    m = t.isOptionDisabled(e, r);
                                if (s) {
                                    var u = t.getOptionValue(e);
                                    t.setValue(r.filter(function(e) {
                                        return t.getOptionValue(e) !== u
                                    }), "deselect-option", e)
                                } else if (m) {
                                    t.ariaOnChange(e, {
                                        action: "select-option",
                                        option: e,
                                        name: o
                                    });
                                    return
                                } else i ? t.setValue([].concat(E(r), [e]), "select-option", e) : t.setValue(e, "select-option");
                                a && t.blurInput()
                            }, t.removeValue = function(e) {
                                var n, a = t.props.isMulti,
                                    i = t.state.selectValue,
                                    o = t.getOptionValue(e),
                                    r = i.filter(function(e) {
                                        return t.getOptionValue(e) !== o
                                    }),
                                    s = (n = r[0] || null, a ? r : n);
                                t.onChange(s, {
                                    action: "remove-value",
                                    removedValue: e
                                }), t.focusInput()
                            }, t.clearValue = function() {
                                var e = t.state.selectValue;
                                t.onChange(t.props.isMulti ? [] : null, {
                                    action: "clear",
                                    removedValues: e
                                })
                            }, t.popValue = function() {
                                var e, n = t.props.isMulti,
                                    a = t.state.selectValue,
                                    i = a[a.length - 1],
                                    o = a.slice(0, a.length - 1),
                                    r = (e = o[0] || null, n ? o : e);
                                t.onChange(r, {
                                    action: "pop-value",
                                    removedValue: i
                                })
                            }, t.getValue = function() {
                                return t.state.selectValue
                            }, t.cx = function() {
                                for (var e = arguments.length, n = Array(e), a = 0; a < e; a++) n[a] = arguments[a];
                                return e6.apply(void 0, [t.props.classNamePrefix].concat(n))
                            }, t.getOptionLabel = function(e) {
                                return nF(t.props, e)
                            }, t.getOptionValue = function(e) {
                                return nG(t.props, e)
                            }, t.getStyles = function(e, n) {
                                var a = t.props.unstyled,
                                    i = nI[e](n, a);
                                i.boxSizing = "border-box";
                                var o = t.props.styles[e];
                                return o ? o(i, n) : i
                            }, t.getClassNames = function(e, n) {
                                var a, i;
                                return null === (a = (i = t.props.classNames)[e]) || void 0 === a ? void 0 : a.call(i, n)
                            }, t.getElementId = function(e) {
                                return "".concat(t.instancePrefix, "-").concat(e)
                            }, t.getComponents = function() {
                                var e;
                                return e = t.props, m(m({}, t5), e.components)
                            }, t.buildCategorizedOptions = function() {
                                return nL(t.props, t.state.selectValue)
                            }, t.getCategorizedOptions = function() {
                                return t.props.menuIsOpen ? t.buildCategorizedOptions() : []
                            }, t.buildFocusableOptions = function() {
                                return nV(t.buildCategorizedOptions())
                            }, t.getFocusableOptions = function() {
                                return t.props.menuIsOpen ? t.buildFocusableOptions() : []
                            }, t.ariaOnChange = function(e, n) {
                                t.setState({
                                    ariaSelection: m({
                                        value: e
                                    }, n)
                                })
                            }, t.onMenuMouseDown = function(e) {
                                0 === e.button && (e.stopPropagation(), e.preventDefault(), t.focusInput())
                            }, t.onMenuMouseMove = function(e) {
                                t.blockOptionHover = !1
                            }, t.onControlMouseDown = function(e) {
                                if (!e.defaultPrevented) {
                                    var n = t.props.openMenuOnClick;
                                    t.state.isFocused ? t.props.menuIsOpen ? "INPUT" !== e.target.tagName && "TEXTAREA" !== e.target.tagName && t.onMenuClose() : n && t.openMenu("first") : (n && (t.openAfterFocus = !0), t.focusInput()), "INPUT" !== e.target.tagName && "TEXTAREA" !== e.target.tagName && e.preventDefault()
                                }
                            }, t.onDropdownIndicatorMouseDown = function(e) {
                                if ((!e || "mousedown" !== e.type || 0 === e.button) && !t.props.isDisabled) {
                                    var n = t.props,
                                        a = n.isMulti,
                                        i = n.menuIsOpen;
                                    t.focusInput(), i ? (t.setState({
                                        inputIsHiddenAfterUpdate: !a
                                    }), t.onMenuClose()) : t.openMenu("first"), e.preventDefault()
                                }
                            }, t.onClearIndicatorMouseDown = function(e) {
                                e && "mousedown" === e.type && 0 !== e.button || (t.clearValue(), e.preventDefault(), t.openAfterFocus = !1, "touchend" === e.type ? t.focusInput() : setTimeout(function() {
                                    return t.focusInput()
                                }))
                            }, t.onScroll = function(e) {
                                "boolean" == typeof t.props.closeMenuOnScroll ? e.target instanceof HTMLElement && e8(e.target) && t.props.onMenuClose() : "function" == typeof t.props.closeMenuOnScroll && t.props.closeMenuOnScroll(e) && t.props.onMenuClose()
                            }, t.onCompositionStart = function() {
                                t.isComposing = !0
                            }, t.onCompositionEnd = function() {
                                t.isComposing = !1
                            }, t.onTouchStart = function(e) {
                                var n = e.touches,
                                    a = n && n.item(0);
                                a && (t.initialTouchX = a.clientX, t.initialTouchY = a.clientY, t.userIsDragging = !1)
                            }, t.onTouchMove = function(e) {
                                var n = e.touches,
                                    a = n && n.item(0);
                                if (a) {
                                    var i = Math.abs(a.clientX - t.initialTouchX),
                                        o = Math.abs(a.clientY - t.initialTouchY);
                                    t.userIsDragging = i > 5 || o > 5
                                }
                            }, t.onTouchEnd = function(e) {
                                t.userIsDragging || (t.controlRef && !t.controlRef.contains(e.target) && t.menuListRef && !t.menuListRef.contains(e.target) && t.blurInput(), t.initialTouchX = 0, t.initialTouchY = 0)
                            }, t.onControlTouchEnd = function(e) {
                                t.userIsDragging || t.onControlMouseDown(e)
                            }, t.onClearIndicatorTouchEnd = function(e) {
                                t.userIsDragging || t.onClearIndicatorMouseDown(e)
                            }, t.onDropdownIndicatorTouchEnd = function(e) {
                                t.userIsDragging || t.onDropdownIndicatorMouseDown(e)
                            }, t.handleInputChange = function(e) {
                                var n = t.props.inputValue,
                                    a = e.currentTarget.value;
                                t.setState({
                                    inputIsHiddenAfterUpdate: !1
                                }), t.onInputChange(a, {
                                    action: "input-change",
                                    prevInputValue: n
                                }), t.props.menuIsOpen || t.onMenuOpen()
                            }, t.onInputFocus = function(e) {
                                t.props.onFocus && t.props.onFocus(e), t.setState({
                                    inputIsHiddenAfterUpdate: !1,
                                    isFocused: !0
                                }), (t.openAfterFocus || t.props.openMenuOnFocus) && t.openMenu("first"), t.openAfterFocus = !1
                            }, t.onInputBlur = function(e) {
                                var n = t.props.inputValue;
                                if (t.menuListRef && t.menuListRef.contains(document.activeElement)) {
                                    t.inputRef.focus();
                                    return
                                }
                                t.props.onBlur && t.props.onBlur(e), t.onInputChange("", {
                                    action: "input-blur",
                                    prevInputValue: n
                                }), t.onMenuClose(), t.setState({
                                    focusedValue: null,
                                    isFocused: !1
                                })
                            }, t.onOptionHover = function(e) {
                                t.blockOptionHover || t.state.focusedOption === e || t.setState({
                                    focusedOption: e
                                })
                            }, t.shouldHideSelectedOptions = function() {
                                return nK(t.props)
                            }, t.onValueInputFocus = function(e) {
                                e.preventDefault(), e.stopPropagation(), t.focus()
                            }, t.onKeyDown = function(e) {
                                var n = t.props,
                                    a = n.isMulti,
                                    i = n.backspaceRemovesValue,
                                    o = n.escapeClearsValue,
                                    r = n.inputValue,
                                    s = n.isClearable,
                                    m = n.isDisabled,
                                    u = n.menuIsOpen,
                                    l = n.onKeyDown,
                                    c = n.tabSelectsValue,
                                    f = n.openMenuOnFocus,
                                    d = t.state,
                                    g = d.focusedOption,
                                    p = d.focusedValue,
                                    b = d.selectValue;
                                if (!m) {
                                    if ("function" == typeof l && (l(e), e.defaultPrevented)) return;
                                    switch (t.blockOptionHover = !0, e.key) {
                                        case "ArrowLeft":
                                            if (!a || r) return;
                                            t.focusValue("previous");
                                            break;
                                        case "ArrowRight":
                                            if (!a || r) return;
                                            t.focusValue("next");
                                            break;
                                        case "Delete":
                                        case "Backspace":
                                            if (r) return;
                                            if (p) t.removeValue(p);
                                            else {
                                                if (!i) return;
                                                a ? t.popValue() : s && t.clearValue()
                                            }
                                            break;
                                        case "Tab":
                                            if (t.isComposing || e.shiftKey || !u || !c || !g || f && t.isOptionSelected(g, b)) return;
                                            t.selectOption(g);
                                            break;
                                        case "Enter":
                                            if (229 === e.keyCode) break;
                                            if (u) {
                                                if (!g || t.isComposing) return;
                                                t.selectOption(g);
                                                break
                                            }
                                            return;
                                        case "Escape":
                                            u ? (t.setState({
                                                inputIsHiddenAfterUpdate: !1
                                            }), t.onInputChange("", {
                                                action: "menu-close",
                                                prevInputValue: r
                                            }), t.onMenuClose()) : s && o && t.clearValue();
                                            break;
                                        case " ":
                                            if (r) return;
                                            if (!u) {
                                                t.openMenu("first");
                                                break
                                            }
                                            if (!g) return;
                                            t.selectOption(g);
                                            break;
                                        case "ArrowUp":
                                            u ? t.focusOption("up") : t.openMenu("last");
                                            break;
                                        case "ArrowDown":
                                            u ? t.focusOption("down") : t.openMenu("first");
                                            break;
                                        case "PageUp":
                                            if (!u) return;
                                            t.focusOption("pageup");
                                            break;
                                        case "PageDown":
                                            if (!u) return;
                                            t.focusOption("pagedown");
                                            break;
                                        case "Home":
                                            if (!u) return;
                                            t.focusOption("first");
                                            break;
                                        case "End":
                                            if (!u) return;
                                            t.focusOption("last");
                                            break;
                                        default:
                                            return
                                    }
                                    e.preventDefault()
                                }
                            }, t.instancePrefix = "react-select-" + (t.props.instanceId || ++nW), t.state.selectValue = e2(e.value), e.menuIsOpen && t.state.selectValue.length) {
                            var n = t.buildFocusableOptions(),
                                a = n.indexOf(t.state.selectValue[0]);
                            t.state.focusedOption = n[a]
                        }
                        return t
                    }
                    return n = [{
                        key: "componentDidMount",
                        value: function() {
                            this.startListeningComposition(), this.startListeningToTouch(), this.props.closeMenuOnScroll && document && document.addEventListener && document.addEventListener("scroll", this.onScroll, !0), this.props.autoFocus && this.focusInput(), this.props.menuIsOpen && this.state.focusedOption && this.menuListRef && this.focusedOptionRef && tt(this.menuListRef, this.focusedOptionRef)
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function(e) {
                            var t = this.props,
                                n = t.isDisabled,
                                a = t.menuIsOpen,
                                i = this.state.isFocused;
                            (i && !n && e.isDisabled || i && a && !e.menuIsOpen) && this.focusInput(), i && n && !e.isDisabled ? this.setState({
                                isFocused: !1
                            }, this.onMenuClose) : i || n || !e.isDisabled || this.inputRef !== document.activeElement || this.setState({
                                isFocused: !0
                            }), this.menuListRef && this.focusedOptionRef && this.scrollToFocusedOptionOnUpdate && (tt(this.menuListRef, this.focusedOptionRef), this.scrollToFocusedOptionOnUpdate = !1)
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            this.stopListeningComposition(), this.stopListeningToTouch(), document.removeEventListener("scroll", this.onScroll, !0)
                        }
                    }, {
                        key: "onMenuOpen",
                        value: function() {
                            this.props.onMenuOpen()
                        }
                    }, {
                        key: "onMenuClose",
                        value: function() {
                            this.onInputChange("", {
                                action: "menu-close",
                                prevInputValue: this.props.inputValue
                            }), this.props.onMenuClose()
                        }
                    }, {
                        key: "onInputChange",
                        value: function(e, t) {
                            this.props.onInputChange(e, t)
                        }
                    }, {
                        key: "focusInput",
                        value: function() {
                            this.inputRef && this.inputRef.focus()
                        }
                    }, {
                        key: "blurInput",
                        value: function() {
                            this.inputRef && this.inputRef.blur()
                        }
                    }, {
                        key: "openMenu",
                        value: function(e) {
                            var t = this,
                                n = this.state,
                                a = n.selectValue,
                                i = n.isFocused,
                                o = this.buildFocusableOptions(),
                                r = "first" === e ? 0 : o.length - 1;
                            if (!this.props.isMulti) {
                                var s = o.indexOf(a[0]);
                                s > -1 && (r = s)
                            }
                            this.scrollToFocusedOptionOnUpdate = !(i && this.menuListRef), this.setState({
                                inputIsHiddenAfterUpdate: !1,
                                focusedValue: null,
                                focusedOption: o[r]
                            }, function() {
                                return t.onMenuOpen()
                            })
                        }
                    }, {
                        key: "focusValue",
                        value: function(e) {
                            var t = this.state,
                                n = t.selectValue,
                                a = t.focusedValue;
                            if (this.props.isMulti) {
                                this.setState({
                                    focusedOption: null
                                });
                                var i = n.indexOf(a);
                                a || (i = -1);
                                var o = n.length - 1,
                                    r = -1;
                                if (n.length) {
                                    switch (e) {
                                        case "previous":
                                            r = 0 === i ? 0 : -1 === i ? o : i - 1;
                                            break;
                                        case "next":
                                            i > -1 && i < o && (r = i + 1)
                                    }
                                    this.setState({
                                        inputIsHidden: -1 !== r,
                                        focusedValue: n[r]
                                    })
                                }
                            }
                        }
                    }, {
                        key: "focusOption",
                        value: function() {
                            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "first",
                                t = this.props.pageSize,
                                n = this.state.focusedOption,
                                a = this.getFocusableOptions();
                            if (a.length) {
                                var i = 0,
                                    o = a.indexOf(n);
                                n || (o = -1), "up" === e ? i = o > 0 ? o - 1 : a.length - 1 : "down" === e ? i = (o + 1) % a.length : "pageup" === e ? (i = o - t) < 0 && (i = 0) : "pagedown" === e ? (i = o + t) > a.length - 1 && (i = a.length - 1) : "last" === e && (i = a.length - 1), this.scrollToFocusedOptionOnUpdate = !0, this.setState({
                                    focusedOption: a[i],
                                    focusedValue: null
                                })
                            }
                        }
                    }, {
                        key: "getTheme",
                        value: function() {
                            return this.props.theme ? "function" == typeof this.props.theme ? this.props.theme(nx) : m(m({}, nx), this.props.theme) : nx
                        }
                    }, {
                        key: "getCommonProps",
                        value: function() {
                            var e = this.clearValue,
                                t = this.cx,
                                n = this.getStyles,
                                a = this.getClassNames,
                                i = this.getValue,
                                o = this.selectOption,
                                r = this.setValue,
                                s = this.props,
                                m = s.isMulti,
                                u = s.isRtl,
                                l = s.options;
                            return {
                                clearValue: e,
                                cx: t,
                                getStyles: n,
                                getClassNames: a,
                                getValue: i,
                                hasValue: this.hasValue(),
                                isMulti: m,
                                isRtl: u,
                                options: l,
                                selectOption: o,
                                selectProps: s,
                                setValue: r,
                                theme: this.getTheme()
                            }
                        }
                    }, {
                        key: "hasValue",
                        value: function() {
                            return this.state.selectValue.length > 0
                        }
                    }, {
                        key: "hasOptions",
                        value: function() {
                            return !!this.getFocusableOptions().length
                        }
                    }, {
                        key: "isClearable",
                        value: function() {
                            var e = this.props,
                                t = e.isClearable,
                                n = e.isMulti;
                            return void 0 === t ? n : t
                        }
                    }, {
                        key: "isOptionDisabled",
                        value: function(e, t) {
                            return nH(this.props, e, t)
                        }
                    }, {
                        key: "isOptionSelected",
                        value: function(e, t) {
                            return n_(this.props, e, t)
                        }
                    }, {
                        key: "filterOption",
                        value: function(e, t) {
                            return nj(this.props, e, t)
                        }
                    }, {
                        key: "formatOptionLabel",
                        value: function(e, t) {
                            if ("function" != typeof this.props.formatOptionLabel) return this.getOptionLabel(e);
                            var n = this.props.inputValue,
                                a = this.state.selectValue;
                            return this.props.formatOptionLabel(e, {
                                context: t,
                                inputValue: n,
                                selectValue: a
                            })
                        }
                    }, {
                        key: "formatGroupLabel",
                        value: function(e) {
                            return this.props.formatGroupLabel(e)
                        }
                    }, {
                        key: "startListeningComposition",
                        value: function() {
                            document && document.addEventListener && (document.addEventListener("compositionstart", this.onCompositionStart, !1), document.addEventListener("compositionend", this.onCompositionEnd, !1))
                        }
                    }, {
                        key: "stopListeningComposition",
                        value: function() {
                            document && document.removeEventListener && (document.removeEventListener("compositionstart", this.onCompositionStart), document.removeEventListener("compositionend", this.onCompositionEnd))
                        }
                    }, {
                        key: "startListeningToTouch",
                        value: function() {
                            document && document.addEventListener && (document.addEventListener("touchstart", this.onTouchStart, !1), document.addEventListener("touchmove", this.onTouchMove, !1), document.addEventListener("touchend", this.onTouchEnd, !1))
                        }
                    }, {
                        key: "stopListeningToTouch",
                        value: function() {
                            document && document.removeEventListener && (document.removeEventListener("touchstart", this.onTouchStart), document.removeEventListener("touchmove", this.onTouchMove), document.removeEventListener("touchend", this.onTouchEnd))
                        }
                    }, {
                        key: "renderInput",
                        value: function() {
                            var e = this.props,
                                t = e.isDisabled,
                                n = e.isSearchable,
                                a = e.inputId,
                                i = e.inputValue,
                                o = e.tabIndex,
                                r = e.form,
                                s = e.menuIsOpen,
                                u = e.required,
                                l = this.getComponents().Input,
                                c = this.state,
                                f = c.inputIsHidden,
                                d = c.ariaSelection,
                                g = this.commonProps,
                                p = a || this.getElementId("input"),
                                b = m(m(m({
                                    "aria-autocomplete": "list",
                                    "aria-expanded": s,
                                    "aria-haspopup": !0,
                                    "aria-errormessage": this.props["aria-errormessage"],
                                    "aria-invalid": this.props["aria-invalid"],
                                    "aria-label": this.props["aria-label"],
                                    "aria-labelledby": this.props["aria-labelledby"],
                                    "aria-required": u,
                                    role: "combobox"
                                }, s && {
                                    "aria-controls": this.getElementId("listbox"),
                                    "aria-owns": this.getElementId("listbox")
                                }), !n && {
                                    "aria-readonly": !0
                                }), this.hasValue() ? (null == d ? void 0 : d.action) === "initial-input-focus" && {
                                    "aria-describedby": this.getElementId("live-region")
                                } : {
                                    "aria-describedby": this.getElementId("placeholder")
                                });
                            return n ? v.createElement(l, z({}, g, {
                                autoCapitalize: "none",
                                autoComplete: "off",
                                autoCorrect: "off",
                                id: p,
                                innerRef: this.getInputRef,
                                isDisabled: t,
                                isHidden: f,
                                onBlur: this.onInputBlur,
                                onChange: this.handleInputChange,
                                onFocus: this.onInputFocus,
                                spellCheck: "false",
                                tabIndex: o,
                                form: r,
                                type: "text",
                                value: i
                            }, b)) : v.createElement(nd, z({
                                id: p,
                                innerRef: this.getInputRef,
                                onBlur: this.onInputBlur,
                                onChange: e3,
                                onFocus: this.onInputFocus,
                                disabled: t,
                                tabIndex: o,
                                inputMode: "none",
                                form: r,
                                value: ""
                            }, b))
                        }
                    }, {
                        key: "renderPlaceholderOrValue",
                        value: function() {
                            var e = this,
                                t = this.getComponents(),
                                n = t.MultiValue,
                                a = t.MultiValueContainer,
                                i = t.MultiValueLabel,
                                o = t.MultiValueRemove,
                                r = t.SingleValue,
                                s = t.Placeholder,
                                m = this.commonProps,
                                u = this.props,
                                l = u.controlShouldRenderValue,
                                c = u.isDisabled,
                                f = u.isMulti,
                                d = u.inputValue,
                                g = u.placeholder,
                                p = this.state,
                                b = p.selectValue,
                                h = p.focusedValue,
                                T = p.isFocused;
                            if (!this.hasValue() || !l) return d ? null : v.createElement(s, z({}, m, {
                                key: "placeholder",
                                isDisabled: c,
                                isFocused: T,
                                innerProps: {
                                    id: this.getElementId("placeholder")
                                }
                            }), g);
                            if (f) return b.map(function(t, r) {
                                var s = "".concat(e.getOptionLabel(t), "-").concat(e.getOptionValue(t));
                                return v.createElement(n, z({}, m, {
                                    components: {
                                        Container: a,
                                        Label: i,
                                        Remove: o
                                    },
                                    isFocused: t === h,
                                    isDisabled: c,
                                    key: s,
                                    index: r,
                                    removeProps: {
                                        onClick: function() {
                                            return e.removeValue(t)
                                        },
                                        onTouchEnd: function() {
                                            return e.removeValue(t)
                                        },
                                        onMouseDown: function(e) {
                                            e.preventDefault()
                                        }
                                    },
                                    data: t
                                }), e.formatOptionLabel(t, "value"))
                            });
                            if (d) return null;
                            var N = b[0];
                            return v.createElement(r, z({}, m, {
                                data: N,
                                isDisabled: c
                            }), this.formatOptionLabel(N, "value"))
                        }
                    }, {
                        key: "renderClearIndicator",
                        value: function() {
                            var e = this.getComponents().ClearIndicator,
                                t = this.commonProps,
                                n = this.props,
                                a = n.isDisabled,
                                i = n.isLoading,
                                o = this.state.isFocused;
                            if (!this.isClearable() || !e || a || !this.hasValue() || i) return null;
                            var r = {
                                onMouseDown: this.onClearIndicatorMouseDown,
                                onTouchEnd: this.onClearIndicatorTouchEnd,
                                "aria-hidden": "true"
                            };
                            return v.createElement(e, z({}, t, {
                                innerProps: r,
                                isFocused: o
                            }))
                        }
                    }, {
                        key: "renderLoadingIndicator",
                        value: function() {
                            var e = this.getComponents().LoadingIndicator,
                                t = this.commonProps,
                                n = this.props,
                                a = n.isDisabled,
                                i = n.isLoading,
                                o = this.state.isFocused;
                            return e && i ? v.createElement(e, z({}, t, {
                                innerProps: {
                                    "aria-hidden": "true"
                                },
                                isDisabled: a,
                                isFocused: o
                            })) : null
                        }
                    }, {
                        key: "renderIndicatorSeparator",
                        value: function() {
                            var e = this.getComponents(),
                                t = e.DropdownIndicator,
                                n = e.IndicatorSeparator;
                            if (!t || !n) return null;
                            var a = this.commonProps,
                                i = this.props.isDisabled,
                                o = this.state.isFocused;
                            return v.createElement(n, z({}, a, {
                                isDisabled: i,
                                isFocused: o
                            }))
                        }
                    }, {
                        key: "renderDropdownIndicator",
                        value: function() {
                            var e = this.getComponents().DropdownIndicator;
                            if (!e) return null;
                            var t = this.commonProps,
                                n = this.props.isDisabled,
                                a = this.state.isFocused,
                                i = {
                                    onMouseDown: this.onDropdownIndicatorMouseDown,
                                    onTouchEnd: this.onDropdownIndicatorTouchEnd,
                                    "aria-hidden": "true"
                                };
                            return v.createElement(e, z({}, t, {
                                innerProps: i,
                                isDisabled: n,
                                isFocused: a
                            }))
                        }
                    }, {
                        key: "renderMenu",
                        value: function() {
                            var e, t = this,
                                n = this.getComponents(),
                                a = n.Group,
                                i = n.GroupHeading,
                                o = n.Menu,
                                r = n.MenuList,
                                s = n.MenuPortal,
                                m = n.LoadingMessage,
                                u = n.NoOptionsMessage,
                                l = n.Option,
                                c = this.commonProps,
                                f = this.state.focusedOption,
                                d = this.props,
                                g = d.captureMenuScroll,
                                p = d.inputValue,
                                b = d.isLoading,
                                h = d.loadingMessage,
                                T = d.minMenuHeight,
                                N = d.maxMenuHeight,
                                C = d.menuIsOpen,
                                O = d.menuPlacement,
                                y = d.menuPosition,
                                A = d.menuPortalTarget,
                                S = d.menuShouldBlockScroll,
                                E = d.menuShouldScrollIntoView,
                                U = d.noOptionsMessage,
                                M = d.onMenuScrollToTop,
                                w = d.onMenuScrollToBottom;
                            if (!C) return null;
                            var P = function(e, n) {
                                var a = e.type,
                                    i = e.data,
                                    o = e.isDisabled,
                                    r = e.isSelected,
                                    s = e.label,
                                    m = e.value,
                                    u = f === i,
                                    d = o ? void 0 : function() {
                                        return t.onOptionHover(i)
                                    },
                                    g = "".concat(t.getElementId("option"), "-").concat(n);
                                return v.createElement(l, z({}, c, {
                                    innerProps: {
                                        id: g,
                                        onClick: o ? void 0 : function() {
                                            return t.selectOption(i)
                                        },
                                        onMouseMove: d,
                                        onMouseOver: d,
                                        tabIndex: -1
                                    },
                                    data: i,
                                    isDisabled: o,
                                    isSelected: r,
                                    key: g,
                                    label: s,
                                    type: a,
                                    value: m,
                                    isFocused: u,
                                    innerRef: u ? t.getFocusedOptionRef : void 0
                                }), t.formatOptionLabel(e.data, "menu"))
                            };
                            if (this.hasOptions()) e = this.getCategorizedOptions().map(function(e) {
                                if ("group" === e.type) {
                                    var n = e.data,
                                        o = e.options,
                                        r = e.index,
                                        s = "".concat(t.getElementId("group"), "-").concat(r);
                                    return v.createElement(a, z({}, c, {
                                        key: s,
                                        data: n,
                                        options: o,
                                        Heading: i,
                                        headingProps: {
                                            id: "".concat(s, "-heading"),
                                            data: e.data
                                        },
                                        label: t.formatGroupLabel(e.data)
                                    }), e.options.map(function(e) {
                                        return P(e, "".concat(r, "-").concat(e.index))
                                    }))
                                }
                                if ("option" === e.type) return P(e, "".concat(e.index))
                            });
                            else if (b) {
                                var k = h({
                                    inputValue: p
                                });
                                if (null === k) return null;
                                e = v.createElement(m, c, k)
                            } else {
                                var I = U({
                                    inputValue: p
                                });
                                if (null === I) return null;
                                e = v.createElement(u, c, I)
                            }
                            var x = {
                                    minMenuHeight: T,
                                    maxMenuHeight: N,
                                    menuPlacement: O,
                                    menuPosition: y,
                                    menuShouldScrollIntoView: E
                                },
                                R = v.createElement(tf, z({}, c, x), function(n) {
                                    var a = n.ref,
                                        i = n.placerProps,
                                        s = i.placement,
                                        m = i.maxHeight;
                                    return v.createElement(o, z({}, c, x, {
                                        innerRef: a,
                                        innerProps: {
                                            onMouseDown: t.onMenuMouseDown,
                                            onMouseMove: t.onMenuMouseMove,
                                            id: t.getElementId("listbox")
                                        },
                                        isLoading: b,
                                        placement: s
                                    }), v.createElement(nS, {
                                        captureEnabled: g,
                                        onTopArrive: M,
                                        onBottomArrive: w,
                                        lockEnabled: S
                                    }, function(n) {
                                        return v.createElement(r, z({}, c, {
                                            innerRef: function(e) {
                                                t.getMenuListRef(e), n(e)
                                            },
                                            isLoading: b,
                                            maxHeight: m,
                                            focusedOption: f
                                        }), e)
                                    }))
                                });
                            return A || "fixed" === y ? v.createElement(s, z({}, c, {
                                appendTo: A,
                                controlElement: this.controlRef,
                                menuPlacement: O,
                                menuPosition: y
                            }), R) : R
                        }
                    }, {
                        key: "renderFormField",
                        value: function() {
                            var e = this,
                                t = this.props,
                                n = t.delimiter,
                                a = t.isDisabled,
                                i = t.isMulti,
                                o = t.name,
                                r = t.required,
                                s = this.state.selectValue;
                            if (o && !a) {
                                if (r && !this.hasValue()) return v.createElement(nU, {
                                    name: o,
                                    onFocus: this.onValueInputFocus
                                });
                                if (i) {
                                    if (n) {
                                        var m = s.map(function(t) {
                                            return e.getOptionValue(t)
                                        }).join(n);
                                        return v.createElement("input", {
                                            name: o,
                                            type: "hidden",
                                            value: m
                                        })
                                    }
                                    var u = s.length > 0 ? s.map(function(t, n) {
                                        return v.createElement("input", {
                                            key: "i-".concat(n),
                                            name: o,
                                            type: "hidden",
                                            value: e.getOptionValue(t)
                                        })
                                    }) : v.createElement("input", {
                                        name: o,
                                        type: "hidden",
                                        value: ""
                                    });
                                    return v.createElement("div", null, u)
                                }
                                var l = s[0] ? this.getOptionValue(s[0]) : "";
                                return v.createElement("input", {
                                    name: o,
                                    type: "hidden",
                                    value: l
                                })
                            }
                        }
                    }, {
                        key: "renderLiveRegion",
                        value: function() {
                            var e = this.commonProps,
                                t = this.state,
                                n = t.ariaSelection,
                                a = t.focusedOption,
                                i = t.focusedValue,
                                o = t.isFocused,
                                r = t.selectValue,
                                s = this.getFocusableOptions();
                            return v.createElement(nt, z({}, e, {
                                id: this.getElementId("live-region"),
                                ariaSelection: n,
                                focusedOption: a,
                                focusedValue: i,
                                isFocused: o,
                                selectValue: r,
                                focusableOptions: s
                            }))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var e = this.getComponents(),
                                t = e.Control,
                                n = e.IndicatorsContainer,
                                a = e.SelectContainer,
                                i = e.ValueContainer,
                                o = this.props,
                                r = o.className,
                                s = o.id,
                                m = o.isDisabled,
                                u = o.menuIsOpen,
                                l = this.state.isFocused,
                                c = this.commonProps = this.getCommonProps();
                            return v.createElement(a, z({}, c, {
                                className: r,
                                innerProps: {
                                    id: s,
                                    onKeyDown: this.onKeyDown
                                },
                                isDisabled: m,
                                isFocused: l
                            }), this.renderLiveRegion(), v.createElement(t, z({}, c, {
                                innerRef: this.getControlRef,
                                innerProps: {
                                    onMouseDown: this.onControlMouseDown,
                                    onTouchEnd: this.onControlTouchEnd
                                },
                                isDisabled: m,
                                isFocused: l,
                                menuIsOpen: u
                            }), v.createElement(i, z({}, c, {
                                isDisabled: m
                            }), this.renderPlaceholderOrValue(), this.renderInput()), v.createElement(n, z({}, c, {
                                isDisabled: m
                            }), this.renderClearIndicator(), this.renderLoadingIndicator(), this.renderIndicatorSeparator(), this.renderDropdownIndicator())), this.renderMenu(), this.renderFormField())
                        }
                    }], a = [{
                        key: "getDerivedStateFromProps",
                        value: function(e, t) {
                            var n, a = t.prevProps,
                                i = t.clearFocusValueOnUpdate,
                                o = t.inputIsHiddenAfterUpdate,
                                r = t.ariaSelection,
                                s = t.isFocused,
                                u = t.prevWasFocused,
                                l = e.options,
                                c = e.value,
                                f = e.menuIsOpen,
                                d = e.inputValue,
                                g = e.isMulti,
                                p = e2(c),
                                b = {};
                            if (a && (c !== a.value || l !== a.options || f !== a.menuIsOpen || d !== a.inputValue)) {
                                var h, T = f ? nV(nL(e, p)) : [],
                                    N = i ? function(e, t) {
                                        var n = e.focusedValue,
                                            a = e.selectValue.indexOf(n);
                                        if (a > -1) {
                                            if (t.indexOf(n) > -1) return n;
                                            if (a < t.length) return t[a]
                                        }
                                        return null
                                    }(t, p) : null,
                                    v = (h = t.focusedOption) && T.indexOf(h) > -1 ? h : T[0];
                                b = {
                                    selectValue: p,
                                    focusedOption: v,
                                    focusedValue: N,
                                    clearFocusValueOnUpdate: !1
                                }
                            }
                            var C = r,
                                O = s && u;
                            return s && !O && (C = {
                                value: (n = p[0] || null, g ? p : n),
                                options: p,
                                action: "initial-input-focus"
                            }, O = !u), (null == r ? void 0 : r.action) === "initial-input-focus" && (C = null), m(m(m({}, b), null != o && e !== a ? {
                                inputIsHidden: o,
                                inputIsHiddenAfterUpdate: void 0
                            } : {}), {}, {
                                prevProps: e,
                                ariaSelection: C,
                                prevWasFocused: O
                            })
                        }
                    }], n && y(r.prototype, n), a && y(r, a), Object.defineProperty(r, "prototype", {
                        writable: !1
                    }), r
                }(v.Component);
            n$.defaultProps = nR;
            var nY = (0, v.forwardRef)(function(e, t) {
                var n, a, i, o, r, s, u, l, d, g, p, b, h, T, N, C, y, A, S, E, U, M, w, P, k = (n = e.defaultInputValue, a = e.defaultMenuIsOpen, i = e.defaultValue, o = e.inputValue, r = e.menuIsOpen, s = e.onChange, u = e.onInputChange, l = e.onMenuClose, d = e.onMenuOpen, g = e.value, p = f(e, O), h = (b = c((0, v.useState)(void 0 !== o ? o : void 0 === n ? "" : n), 2))[0], T = b[1], C = (N = c((0, v.useState)(void 0 !== r ? r : void 0 !== a && a), 2))[0], y = N[1], S = (A = c((0, v.useState)(void 0 !== g ? g : void 0 === i ? null : i), 2))[0], E = A[1], U = (0, v.useCallback)(function(e, t) {
                    "function" == typeof s && s(e, t), E(e)
                }, [s]), M = (0, v.useCallback)(function(e, t) {
                    var n;
                    "function" == typeof u && (n = u(e, t)), T(void 0 !== n ? n : e)
                }, [u]), w = (0, v.useCallback)(function() {
                    "function" == typeof d && d(), y(!0)
                }, [d]), P = (0, v.useCallback)(function() {
                    "function" == typeof l && l(), y(!1)
                }, [l]), m(m({}, p), {}, {
                    inputValue: void 0 !== o ? o : h,
                    menuIsOpen: void 0 !== r ? r : C,
                    onChange: U,
                    onInputChange: M,
                    onMenuClose: P,
                    onMenuOpen: w,
                    value: void 0 !== g ? g : S
                }));
                return v.createElement(n$, z({
                    ref: t
                }, k))
            })
        },
        30862: function(e, t, n) {
            "use strict";
            n.d(t, {
                Q: function() {
                    return m
                }
            });
            var a = /\b(?:an?d?|a[st]|because|but|by|en|for|i[fn]|neither|nor|o[fnr]|only|over|per|so|some|tha[tn]|the|to|up|upon|vs?\.?|versus|via|when|with|without|yet)\b/i,
                i = /[^\s:–—-]+|./g,
                o = /\s/,
                r = /.(?=[A-Z]|\..)/,
                s = /[A-Za-z0-9\u00C0-\u00FF]/;

            function m(e) {
                for (var t, n = ""; null !== (t = i.exec(e));) {
                    var m = t[0],
                        u = t.index;
                    if (!r.test(m) && (!a.test(m) || 0 === u || u + m.length === e.length) && (":" !== e.charAt(u + m.length) || o.test(e.charAt(u + m.length + 1)))) {
                        n += m.replace(s, function(e) {
                            return e.toUpperCase()
                        });
                        continue
                    }
                    n += m
                }
                return n
            }
        },
        16782: function(e, t, n) {
            "use strict";
            n.d(t, {
                r: function() {
                    return L
                }
            });
            var a, i, o, r, s, m = n(67294),
                u = ((a = u || {})[a.None = 0] = "None", a[a.RenderStrategy = 1] = "RenderStrategy", a[a.Static = 2] = "Static", a),
                l = ((i = l || {})[i.Unmount = 0] = "Unmount", i[i.Hidden = 1] = "Hidden", i);

            function c({
                ourProps: e,
                theirProps: t,
                slot: n,
                defaultTag: a,
                features: i,
                visible: o = !0,
                name: r
            }) {
                let s = d(t, e);
                if (o) return f(s, n, a, r);
                let m = null != i ? i : 0;
                if (2 & m) {
                    let {
                        static: u = !1,
                        ...l
                    } = s;
                    if (u) return f(l, n, a, r)
                }
                if (1 & m) {
                    let {
                        unmount: c = !0,
                        ...g
                    } = s;
                    return function e(t, n, ...a) {
                        if (t in n) {
                            let i = n[t];
                            return "function" == typeof i ? i(...a) : i
                        }
                        let o = Error(`Tried to handle "${t}" but there is no handler defined. Only defined handlers are: ${Object.keys(n).map(e=>`"${e}"`).join(", ")}.`);
                        throw Error.captureStackTrace && Error.captureStackTrace(o, e), o
                    }(c ? 0 : 1, {
                        0: () => null,
                        1: () => f({ ...g,
                            hidden: !0,
                            style: {
                                display: "none"
                            }
                        }, n, a, r)
                    })
                }
                return f(s, n, a, r)
            }

            function f(e, t = {}, n, a) {
                let {
                    as: i = n,
                    children: o,
                    refName: r = "ref",
                    ...s
                } = b(e, ["unmount", "static"]), u = void 0 !== e.ref ? {
                    [r]: e.ref
                } : {}, l = "function" == typeof o ? o(t) : o;
                s.className && "function" == typeof s.className && (s.className = s.className(t));
                let c = {};
                if (t) {
                    let f = !1,
                        g = [];
                    for (let [h, T] of Object.entries(t)) "boolean" == typeof T && (f = !0), !0 === T && g.push(h);
                    f && (c["data-headlessui-state"] = g.join(" "))
                }
                if (i === m.Fragment && Object.keys(p(s)).length > 0) {
                    if (!(0, m.isValidElement)(l) || Array.isArray(l) && l.length > 1) throw Error(['Passing props on "Fragment"!', "", `The current component <${a} /> is rendering a "Fragment".`, "However we need to passthrough the following props:", Object.keys(s).map(e => `  - ${e}`).join(`
`), "", "You can apply a few solutions:", ['Add an `as="..."` prop, to ensure that we render an actual element instead of a "Fragment".', "Render a single element as the child so that we can forward the props onto that element."].map(e => `  - ${e}`).join(`
`)].join(`
`));
                    return (0, m.cloneElement)(l, Object.assign({}, d(l.props, p(b(s, ["ref"]))), c, u, function(...e) {
                        return {
                            ref: e.every(e => null == e) ? void 0 : t => {
                                for (let n of e) null != n && ("function" == typeof n ? n(t) : n.current = t)
                            }
                        }
                    }(l.ref, u.ref)))
                }
                return (0, m.createElement)(i, Object.assign({}, b(s, ["ref"]), i !== m.Fragment && u, i !== m.Fragment && c), l)
            }

            function d(...e) {
                if (0 === e.length) return {};
                if (1 === e.length) return e[0];
                let t = {},
                    n = {};
                for (let a of e)
                    for (let i in a) i.startsWith("on") && "function" == typeof a[i] ? (null != n[i] || (n[i] = []), n[i].push(a[i])) : t[i] = a[i];
                if (t.disabled || t["aria-disabled"]) return Object.assign(t, Object.fromEntries(Object.keys(n).map(e => [e, void 0])));
                for (let o in n) Object.assign(t, {
                    [o](e, ...t) {
                        let a = n[o];
                        for (let i of a) {
                            if ((e instanceof Event || (null == e ? void 0 : e.nativeEvent) instanceof Event) && e.defaultPrevented) return;
                            i(e, ...t)
                        }
                    }
                });
                return t
            }

            function g(e) {
                var t;
                return Object.assign((0, m.forwardRef)(e), {
                    displayName: null != (t = e.displayName) ? t : e.name
                })
            }

            function p(e) {
                let t = Object.assign({}, e);
                for (let n in t) void 0 === t[n] && delete t[n];
                return t
            }

            function b(e, t = []) {
                let n = Object.assign({}, e);
                for (let a of t) a in n && delete n[a];
                return n
            }
            let h = "undefined" == typeof window || "undefined" == typeof document,
                T = h ? m.useEffect : m.useLayoutEffect,
                N = {
                    serverHandoffComplete: !1
                },
                v = 0;

            function C() {
                return ++v
            }
            let O = null != (s = m.useId) ? s : function() {
                let e = function() {
                        let [e, t] = (0, m.useState)(N.serverHandoffComplete);
                        return (0, m.useEffect)(() => {
                            !0 !== e && t(!0)
                        }, [e]), (0, m.useEffect)(() => {
                            !1 === N.serverHandoffComplete && (N.serverHandoffComplete = !0)
                        }, []), e
                    }(),
                    [t, n] = m.useState(e ? C : null);
                return T(() => {
                    null === t && n(C())
                }, [t]), null != t ? "" + t : void 0
            };
            var z = ((o = z || {}).Space = " ", o.Enter = "Enter", o.Escape = "Escape", o.Backspace = "Backspace", o.Delete = "Delete", o.ArrowLeft = "ArrowLeft", o.ArrowUp = "ArrowUp", o.ArrowRight = "ArrowRight", o.ArrowDown = "ArrowDown", o.Home = "Home", o.End = "End", o.PageUp = "PageUp", o.PageDown = "PageDown", o.Tab = "Tab", o);
            let y = function(e) {
                    let t;
                    let n = (t = (0, m.useRef)(e), T(() => {
                        t.current = e
                    }, [e]), t);
                    return m.useCallback((...e) => n.current(...e), [n])
                },
                A = Symbol();

            function S(...e) {
                let t = (0, m.useRef)(e);
                (0, m.useEffect)(() => {
                    t.current = e
                }, [e]);
                let n = y(e => {
                    for (let n of t.current) null != n && ("function" == typeof n ? n(e) : n.current = e)
                });
                return e.every(e => null == e || (null == e ? void 0 : e[A])) ? void 0 : n
            }
            let E = (0, m.createContext)(null),
                U = g(function(e, t) {
                    let n = O(),
                        {
                            id: a = `headlessui-label-${n}`,
                            passive: i = !1,
                            ...o
                        } = e,
                        r = function e() {
                            let t = (0, m.useContext)(E);
                            if (null === t) {
                                let n = Error("You used a <Label /> component, but it is not inside a relevant parent.");
                                throw Error.captureStackTrace && Error.captureStackTrace(n, e), n
                            }
                            return t
                        }(),
                        s = S(t);
                    T(() => r.register(a), [a, r.register]);
                    let u = {
                        ref: s,
                        ...r.props,
                        id: a
                    };
                    return i && ("onClick" in u && delete u.onClick, "onClick" in o && delete o.onClick), c({
                        ourProps: u,
                        theirProps: o,
                        slot: r.slot || {},
                        defaultTag: "label",
                        name: r.name || "Label"
                    })
                }),
                M = (0, m.createContext)(null),
                w = g(function(e, t) {
                    let n = O(),
                        {
                            id: a = `headlessui-description-${n}`,
                            ...i
                        } = e,
                        o = function e() {
                            let t = (0, m.useContext)(M);
                            if (null === t) {
                                let n = Error("You used a <Description /> component, but it is not inside a relevant parent.");
                                throw Error.captureStackTrace && Error.captureStackTrace(n, e), n
                            }
                            return t
                        }(),
                        r = S(t);
                    return T(() => o.register(a), [a, o.register]), c({
                        ourProps: {
                            ref: r,
                            ...o.props,
                            id: a
                        },
                        theirProps: i,
                        slot: o.slot || {},
                        defaultTag: "p",
                        name: o.name || "Description"
                    })
                });

            function P(e) {
                var t;
                if (e.type) return e.type;
                let n = null != (t = e.as) ? t : "button";
                if ("string" == typeof n && "button" === n.toLowerCase()) return "button"
            }
            var k = ((r = k || {})[r.None = 1] = "None", r[r.Focusable = 2] = "Focusable", r[r.Hidden = 4] = "Hidden", r);
            let I = g(function(e, t) {
                let {
                    features: n = 1,
                    ...a
                } = e;
                return c({
                    ourProps: {
                        ref: t,
                        "aria-hidden": (2 & n) == 2 || void 0,
                        style: {
                            position: "fixed",
                            top: 1,
                            left: 1,
                            width: 1,
                            height: 0,
                            padding: 0,
                            margin: -1,
                            overflow: "hidden",
                            clip: "rect(0, 0, 0, 0)",
                            whiteSpace: "nowrap",
                            borderWidth: "0",
                            ...(4 & n) == 4 && (2 & n) != 2 && {
                                display: "none"
                            }
                        }
                    },
                    theirProps: a,
                    slot: {},
                    defaultTag: "div",
                    name: "Hidden"
                })
            });

            function x() {
                let e = [],
                    t = [],
                    n = {
                        enqueue(e) {
                            t.push(e)
                        },
                        addEventListener: (e, t, a, i) => (e.addEventListener(t, a, i), n.add(() => e.removeEventListener(t, a, i))),
                        requestAnimationFrame(...e) {
                            let t = requestAnimationFrame(...e);
                            return n.add(() => cancelAnimationFrame(t))
                        },
                        nextFrame: (...e) => n.requestAnimationFrame(() => n.requestAnimationFrame(...e)),
                        setTimeout(...e) {
                            let t = setTimeout(...e);
                            return n.add(() => clearTimeout(t))
                        },
                        microTask(...e) {
                            var t;
                            let a = {
                                current: !0
                            };
                            return t = () => {
                                a.current && e[0]()
                            }, "function" == typeof queueMicrotask ? queueMicrotask(t) : Promise.resolve().then(t).catch(e => setTimeout(() => {
                                throw e
                            })), n.add(() => {
                                a.current = !1
                            })
                        },
                        add: t => (e.push(t), () => {
                            let n = e.indexOf(t);
                            if (n >= 0) {
                                let [a] = e.splice(n, 1);
                                a()
                            }
                        }),
                        dispose() {
                            for (let t of e.splice(0)) t()
                        },
                        async workQueue() {
                            for (let e of t.splice(0)) await e()
                        }
                    };
                return n
            }
            let R = (0, m.createContext)(null);
            R.displayName = "GroupContext";
            let D = m.Fragment,
                L = Object.assign(g(function(e, t) {
                    let n = O(),
                        {
                            id: a = `headlessui-switch-${n}`,
                            checked: i,
                            defaultChecked: o = !1,
                            onChange: r,
                            name: s,
                            value: u,
                            ...l
                        } = e,
                        f = (0, m.useContext)(R),
                        d = (0, m.useRef)(null),
                        g = S(d, t, null === f ? null : f.setSwitch),
                        [b, h] = function(e, t, n) {
                            let [a, i] = (0, m.useState)(n), o = void 0 !== e, r = (0, m.useRef)(o), s = (0, m.useRef)(!1), u = (0, m.useRef)(!1);
                            return !o || r.current || s.current ? o || !r.current || u.current || (u.current = !0, r.current = o, console.error("A component is changing from controlled to uncontrolled. This may be caused by the value changing from a defined value to undefined, which should not happen.")) : (s.current = !0, r.current = o, console.error("A component is changing from uncontrolled to controlled. This may be caused by the value changing from undefined to a defined value, which should not happen.")), [o ? e : a, y(e => (o || i(e), null == t ? void 0 : t(e)))]
                        }(i, r, o),
                        N = y(() => null == h ? void 0 : h(!b)),
                        v = y(e => {
                            if (function(e) {
                                    let t = e.parentElement,
                                        n = null;
                                    for (; t && !(t instanceof HTMLFieldSetElement);) t instanceof HTMLLegendElement && (n = t), t = t.parentElement;
                                    let a = (null == t ? void 0 : t.getAttribute("disabled")) === "";
                                    return !(a && function(e) {
                                        if (!e) return !1;
                                        let t = e.previousElementSibling;
                                        for (; null !== t;) {
                                            if (t instanceof HTMLLegendElement) return !1;
                                            t = t.previousElementSibling
                                        }
                                        return !0
                                    }(n)) && a
                                }(e.currentTarget)) return e.preventDefault();
                            e.preventDefault(), N()
                        }),
                        C = y(e => {
                            e.key === z.Space ? (e.preventDefault(), N()) : e.key === z.Enter && function(e) {
                                var t;
                                let n = null != (t = null == e ? void 0 : e.form) ? t : e.closest("form");
                                if (n) {
                                    for (let a of n.elements)
                                        if ("INPUT" === a.tagName && "submit" === a.type || "BUTTON" === a.tagName && "submit" === a.type || "INPUT" === a.nodeName && "image" === a.type) {
                                            a.click();
                                            return
                                        }
                                }
                            }(e.currentTarget)
                        }),
                        A = y(e => e.preventDefault()),
                        E = (0, m.useMemo)(() => ({
                            checked: b
                        }), [b]),
                        U = {
                            id: a,
                            ref: g,
                            role: "switch",
                            type: function(e, t) {
                                let [n, a] = (0, m.useState)(() => P(e));
                                return T(() => {
                                    a(P(e))
                                }, [e.type, e.as]), T(() => {
                                    n || !t.current || t.current instanceof HTMLButtonElement && !t.current.hasAttribute("type") && a("button")
                                }, [n, t]), n
                            }(e, d),
                            tabIndex: 0,
                            "aria-checked": b,
                            "aria-labelledby": null == f ? void 0 : f.labelledby,
                            "aria-describedby": null == f ? void 0 : f.describedby,
                            onClick: v,
                            onKeyUp: C,
                            onKeyPress: A
                        },
                        M = function() {
                            let [e] = (0, m.useState)(x);
                            return (0, m.useEffect)(() => () => e.dispose(), [e]), e
                        }();
                    return (0, m.useEffect)(() => {
                        var e;
                        let t = null == (e = d.current) ? void 0 : e.closest("form");
                        t && void 0 !== o && M.addEventListener(t, "reset", () => {
                            h(o)
                        })
                    }, [d, h]), m.createElement(m.Fragment, null, null != s && b && m.createElement(I, {
                        features: k.Hidden,
                        ...p({
                            as: "input",
                            type: "checkbox",
                            hidden: !0,
                            readOnly: !0,
                            checked: b,
                            name: s,
                            value: u
                        })
                    }), c({
                        ourProps: U,
                        theirProps: l,
                        slot: E,
                        defaultTag: "button",
                        name: "Switch"
                    }))
                }), {
                    Group: function(e) {
                        let [t, n] = (0, m.useState)(null), [a, i] = function() {
                            let [e, t] = (0, m.useState)([]);
                            return [e.length > 0 ? e.join(" ") : void 0, (0, m.useMemo)(() => function(e) {
                                let n = y(e => (t(t => [...t, e]), () => t(t => {
                                        let n = t.slice(),
                                            a = n.indexOf(e);
                                        return -1 !== a && n.splice(a, 1), n
                                    }))),
                                    a = (0, m.useMemo)(() => ({
                                        register: n,
                                        slot: e.slot,
                                        name: e.name,
                                        props: e.props
                                    }), [n, e.slot, e.name, e.props]);
                                return m.createElement(E.Provider, {
                                    value: a
                                }, e.children)
                            }, [t])]
                        }(), [o, r] = function() {
                            let [e, t] = (0, m.useState)([]);
                            return [e.length > 0 ? e.join(" ") : void 0, (0, m.useMemo)(() => function(e) {
                                let n = y(e => (t(t => [...t, e]), () => t(t => {
                                        let n = t.slice(),
                                            a = n.indexOf(e);
                                        return -1 !== a && n.splice(a, 1), n
                                    }))),
                                    a = (0, m.useMemo)(() => ({
                                        register: n,
                                        slot: e.slot,
                                        name: e.name,
                                        props: e.props
                                    }), [n, e.slot, e.name, e.props]);
                                return m.createElement(M.Provider, {
                                    value: a
                                }, e.children)
                            }, [t])]
                        }(), s = (0, m.useMemo)(() => ({
                            switch: t,
                            setSwitch: n,
                            labelledby: a,
                            describedby: o
                        }), [t, n, a, o]);
                        return m.createElement(r, {
                            name: "Switch.Description"
                        }, m.createElement(i, {
                            name: "Switch.Label",
                            props: {
                                onClick() {
                                    t && (t.click(), t.focus({
                                        preventScroll: !0
                                    }))
                                }
                            }
                        }, m.createElement(R.Provider, {
                            value: s
                        }, c({
                            ourProps: {},
                            theirProps: e,
                            defaultTag: D,
                            name: "Switch.Group"
                        }))))
                    },
                    Label: U,
                    Description: w
                })
        }
    }
]);