(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4889], {
        96625: function(e, t, n) {
            "use strict";
            n.r(t);
            var a = n(85893);
            let i = e => {
                let {
                    color: t = "#fff",
                    className: n = "",
                    onClick: i,
                    ...o
                } = e;
                return (0, a.jsx)("button", {
                    style: {
                        color: t
                    },
                    className: "gradient btn rounded px-2 ".concat(n),
                    onClick: i,
                    children: o.children
                })
            };
            i.defaultProps = {}, t.default = i
        },
        73038: function(e, t, n) {
            "use strict";
            var a = n(85893);
            let i = () => (0, a.jsxs)(a.Fragment, {
                children: [(0, a.jsx)("link", {
                    rel: "icon",
                    href: "/favicon.ico"
                }), (0, a.jsx)("link", {
                    rel: "stylesheet",
                    type: "text/css",
                    href: "//fonts.googleapis.com/css?family=Nunito"
                }), (0, a.jsx)("meta", {
                    name: "viewport",
                    content: "width=device-width, initial-scale=1.0"
                }), (0, a.jsx)("meta", {
                    name: "twitter:card",
                    content: "summary"
                }), (0, a.jsx)("meta", {
                    name: "twitter:site",
                    content: "@tldrnewsletter"
                }), (0, a.jsx)("meta", {
                    name: "twitter:creator",
                    content: "@tldrnewsletter"
                }), (0, a.jsx)("meta", {
                    name: "og:type",
                    content: "article"
                }), (0, a.jsx)("meta", {
                    name: "facebook-domain-verification",
                    content: "xd5gavbgkeckfkehs4fca6k3qfaury"
                }), (0, a.jsx)("meta", {
                    name: "msvalidate.01",
                    content: "FDD395F24F26567C0EDEAAE5075CB44A"
                }), (0, a.jsx)("script", {
                    defer: !0,
                    src: "/analytics.js"
                })]
            });
            t.Z = i
        },
        98706: function(e, t, n) {
            "use strict";
            var a = n(85893),
                i = n(67294),
                o = n(96625),
                s = n(11163),
                r = n(41664),
                l = n.n(r),
                c = n(38597),
                u = n(47041);
            let d = e => {
                let {
                    description: t,
                    newsletter: n,
                    readers: r,
                    focus: d,
                    buttonText: p = "Subscribe",
                    ...m
                } = e, [h, f] = (0, i.useState)(""), [y, g] = (0, i.useState)(""), [b, x] = (0, i.useState)(!1), [D, j] = (0, i.useState)(!1), w = (0, i.useRef)(null), S = (0, s.useRouter)();
                (0, i.useEffect)(() => {
                    S.isReady && (S.query && S.query.email && g(S.query.email), d && w.current.focus())
                }, [S.isReady]);
                let v = e => String(e).toLowerCase().match(/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/),
                    C = async e => {
                        e.preventDefault();
                        let t = y.trim().toLowerCase();
                        if (x(!0), v(t)) {
                            if (b || (0, c.lp)(t)) {
                                if (!D) {
                                    j(!0);
                                    let i = await fetch("/api/subscribe", {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify({
                                            email: y,
                                            newsletters: [n],
                                            landingPage: (0, u.getCookie)("landingPage")
                                        })
                                    });
                                    await i.json(), i.ok ? "tech" == n ? window.location = "/subscribed?email=".concat(y) : window.location = "/".concat(n, "/subscribed?email=").concat(y) : f((0, a.jsxs)("div", {
                                        children: ["Please email us at ", (0, a.jsx)(l(), {
                                            href: "mailto:hello@tldr.tech",
                                            children: "hello@tldr.tech"
                                        }), " and we will add you manually."]
                                    })), await (0, c.Dc)(1e3), j(!1)
                                }
                            } else f('There might be a typo in your email. If it\'s correct, please click "Subscribe" again.')
                        } else f("Please enter a valid email")
                    };
                return (0, a.jsxs)("div", {
                    children: [(0, a.jsx)("div", {
                        children: t
                    }), (0, a.jsxs)("form", {
                        className: "mt-3 px-2 md:px-0 md:flex md:flex-row justify-center text-center",
                        onSubmit: C,
                        children: [(0, a.jsx)("input", {
                            ref: w,
                            className: "appearance-none min-w-[80%] w-9/12 md:min-w-0 md:w-60 md:mr-3 h-8 bg-gray-50 text-gray-800 border rounded py-1 px-1 leading-tight focus:outline-none focus:bg-white",
                            name: "email",
                            type: "email",
                            autoCapitalize: "none",
                            placeholder: "Email Address",
                            value: y,
                            onChange(e) {
                                g(e.target.value), f(""), x(!1)
                            },
                            required: !0
                        }), (0, a.jsx)(o.default, {
                            className: "h-8 min-w-[80%] w-9/12 mt-2 md:min-w-0 md:mt-0 md:w-fit",
                            onClick: C,
                            children: D ? "Subscribing..." : p || "Subscribe"
                        })]
                    }), 0 == r ? (0, a.jsx)("div", {
                        className: "mt-3 text-center",
                        children: "Launching Soon"
                    }) : (0, a.jsxs)("div", {
                        className: "mt-3 text-center",
                        children: ["Join ", r, " readers for ", (0, a.jsx)(l(), {
                            href: "/api/latest/".concat(n),
                            children: "one daily email"
                        })]
                    }), (0, a.jsx)("div", {
                        className: "pt-3 text-center",
                        style: {
                            height: "40px"
                        },
                        children: h
                    })]
                })
            };
            t.Z = d
        },
        65631: function(e, t, n) {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            let a = n(92648).Z,
                i = n(85893),
                o = a(n(41664)),
                s = a(n(95588)),
                r = n(89583),
                l = n(35594),
                c = n(67294),
                u = n(84053),
                d = a(n(96625)),
                p = a(n(76120)),
                m = () => {
                    let [e, t] = (0, c.useState)(!1), [n, a] = (0, c.useState)(!1), m = (0, u.useUser)();
                    return (0, c.useEffect)(() => {
                        m && a(!0)
                    }, [m]), (0, i.jsxs)(i.Fragment, {
                        children: [e && (0, i.jsx)("div", {
                            className: "bg-gray-800 w-full h-screen absolute z-10",
                            children: (0, i.jsx)("div", {
                                className: "mt-5 flex flex-col items-center",
                                children: (0, i.jsxs)("div", {
                                    className: "mt-3",
                                    children: [(0, i.jsx)("div", {
                                        className: "menu-title font-bold",
                                        children: "Newsletters"
                                    }), (0, i.jsx)("div", {
                                        className: "menu-item text-sm",
                                        children: (0, i.jsx)(o.default, {
                                            href: "/tech/archives",
                                            children: "Startups, Tech & Programming"
                                        })
                                    }), (0, i.jsx)("div", {
                                        className: "menu-item text-sm",
                                        children: (0, i.jsx)(o.default, {
                                            href: "/crypto/archives",
                                            children: "Crypto"
                                        })
                                    }), (0, i.jsx)("div", {
                                        className: "menu-item text-sm",
                                        children: (0, i.jsx)(o.default, {
                                            href: "/ai",
                                            children: "AI"
                                        })
                                    }), (0, i.jsx)("div", {
                                        className: "menu-item text-sm",
                                        children: (0, i.jsx)(o.default, {
                                            href: "/cybersecurity",
                                            children: "Cybersecurity"
                                        })
                                    }), (0, i.jsx)("div", {
                                        className: "menu-item text-sm",
                                        children: (0, i.jsx)(o.default, {
                                            href: "/engineering",
                                            children: "Web Development"
                                        })
                                    }), (0, i.jsx)("div", {
                                        className: "menu-item text-sm",
                                        children: (0, i.jsx)(o.default, {
                                            href: "/design",
                                            children: "Design"
                                        })
                                    }), (0, i.jsx)("div", {
                                        className: "menu-item text-sm",
                                        children: (0, i.jsx)(o.default, {
                                            href: "/product",
                                            children: "Product Management"
                                        })
                                    }), (0, i.jsx)("div", {
                                        className: "menu-item text-sm",
                                        children: (0, i.jsx)(o.default, {
                                            href: "/marketing",
                                            children: "Marketing"
                                        })
                                    }), (0, i.jsx)("div", {
                                        className: "menu-item text-sm",
                                        children: (0, i.jsx)(o.default, {
                                            href: "/founders",
                                            children: "Founders"
                                        })
                                    }), (0, i.jsx)("div", {
                                        className: "mt-3 font-bold",
                                        children: "Advertise"
                                    }), (0, i.jsx)("div", {
                                        className: "menu-item text-sm",
                                        children: (0, i.jsx)(o.default, {
                                            href: "/tech/advertise",
                                            children: "Startups, Tech & Programming"
                                        })
                                    }), (0, i.jsx)("div", {
                                        className: "menu-item text-sm",
                                        children: (0, i.jsx)(o.default, {
                                            href: "/crypto/advertise",
                                            children: "Crypto"
                                        })
                                    }), (0, i.jsx)("div", {
                                        className: "mt-3 font-bold",
                                        children: "Jobs"
                                    }), (0, i.jsx)("div", {
                                        className: "menu-item text-sm",
                                        children: (0, i.jsx)(o.default, {
                                            href: "/jobs",
                                            children: "Job Board"
                                        })
                                    }), (0, i.jsx)("div", {
                                        className: "menu-item text-sm",
                                        children: (0, i.jsx)(o.default, {
                                            href: "/employer/post-job",
                                            children: "Post New Job"
                                        })
                                    })]
                                })
                            })
                        }), (0, i.jsxs)("div", {
                            className: "navbar",
                            children: [(0, i.jsxs)("div", {
                                className: "desktop-navbar hidden md:flex pt-3 pl-3",
                                children: [(0, i.jsx)("span", {
                                    className: "pl-3",
                                    children: (0, i.jsx)(o.default, {
                                        href: "/",
                                        style: {
                                            textDecoration: "none"
                                        },
                                        children: (0, i.jsx)("div", {
                                            className: "text-center text-lg md:text-base",
                                            children: "TLDR"
                                        })
                                    })
                                }), (0, i.jsx)(l.Popover, {
                                    className: "ml-3",
                                    children(e) {
                                        let {
                                            open: t
                                        } = e;
                                        return (0, i.jsxs)(i.Fragment, {
                                            children: [(0, i.jsxs)(l.Popover.Button, {
                                                className: "border-0 outline-0",
                                                style: {
                                                    outline: "none !important",
                                                    border: "none !important",
                                                    overflow: "hidden",
                                                    whiteSpace: "nowrap"
                                                },
                                                children: [(0, i.jsx)("span", {
                                                    className: "inline",
                                                    children: "Newsletters "
                                                }), t ? (0, i.jsx)(r.FaChevronUp, {
                                                    className: "inline",
                                                    style: {
                                                        width: "15px"
                                                    }
                                                }) : (0, i.jsx)(r.FaChevronDown, {
                                                    className: "inline",
                                                    style: {
                                                        width: "15px"
                                                    }
                                                })]
                                            }), (0, i.jsx)(l.Popover.Panel, {
                                                className: "absolute z-10 w-3/6 rounded background-gradient p-5",
                                                style: {
                                                    border: "1px solid #fff"
                                                },
                                                children: (0, i.jsxs)("div", {
                                                    className: "grid grid-cols-2 w-full",
                                                    children: [(0, i.jsx)(p.default, {
                                                        name: "Startups, Tech & Programming",
                                                        href: "/tech/archives",
                                                        emoji: "\uD83D\uDC68‍\uD83D\uDCBB"
                                                    }), (0, i.jsx)(p.default, {
                                                        name: "Crypto",
                                                        href: "/crypto/archives",
                                                        emoji: "\uD83E\uDE99"
                                                    }), (0, i.jsx)(p.default, {
                                                        name: "AI, Machine Learning & Data Science",
                                                        href: "/ai",
                                                        emoji: "\uD83E\uDDE0"
                                                    }), (0, i.jsx)(p.default, {
                                                        name: "Web Development",
                                                        href: "/engineering",
                                                        emoji: "\uD83D\uDCBB"
                                                    }), (0, i.jsx)(p.default, {
                                                        name: "Cybersecurity",
                                                        href: "/cybersecurity",
                                                        emoji: "\uD83D\uDD12"
                                                    }), (0, i.jsx)(p.default, {
                                                        name: "Product Management",
                                                        href: "/product",
                                                        emoji: "\uD83E\uDDD1‍\uD83E\uDD1D‍\uD83E\uDDD1"
                                                    }), (0, i.jsx)(p.default, {
                                                        name: "Growth Marketing",
                                                        href: "/marketing",
                                                        emoji: "\uD83D\uDCC8"
                                                    }), (0, i.jsx)(p.default, {
                                                        name: "Design",
                                                        href: "/design",
                                                        emoji: "\uD83C\uDFA8"
                                                    }), (0, i.jsx)(p.default, {
                                                        name: "Founders & Entrepreneurs",
                                                        href: "/founders",
                                                        emoji: "\uD83D\uDC68‍\uD83D\uDCBC"
                                                    })]
                                                })
                                            })]
                                        })
                                    }
                                }), (0, i.jsx)(l.Popover, {
                                    className: "ml-3",
                                    children(e) {
                                        let {
                                            open: t
                                        } = e;
                                        return (0, i.jsxs)(i.Fragment, {
                                            children: [(0, i.jsxs)(l.Popover.Button, {
                                                className: "outline-0 border-0",
                                                style: {
                                                    overflow: "hidden",
                                                    whiteSpace: "nowrap",
                                                    outline: "none !important",
                                                    border: "none !important"
                                                },
                                                children: ["Advertise", " ", t ? (0, i.jsx)(r.FaChevronUp, {
                                                    className: "inline",
                                                    style: {
                                                        width: "15px"
                                                    }
                                                }) : (0, i.jsx)(r.FaChevronDown, {
                                                    className: "inline",
                                                    style: {
                                                        width: "15px"
                                                    }
                                                })]
                                            }), (0, i.jsx)(l.Popover.Panel, {
                                                className: "absolute z-10 w-3/6 rounded background-gradient p-5",
                                                style: {
                                                    border: "1px solid #fff"
                                                },
                                                children: (0, i.jsxs)("div", {
                                                    className: "grid grid-cols-2 w-full",
                                                    children: [(0, i.jsx)(p.default, {
                                                        name: "Startups, Tech & Programming",
                                                        description: "stuff",
                                                        href: "/tech/advertise",
                                                        emoji: "\uD83D\uDC68‍\uD83D\uDCBB"
                                                    }), (0, i.jsx)(p.default, {
                                                        name: "Crypto",
                                                        description: "stuff",
                                                        href: "/crypto/advertise",
                                                        emoji: "\uD83E\uDE99"
                                                    })]
                                                })
                                            })]
                                        })
                                    }
                                }), (0, i.jsx)("div", {
                                    className: "inline ml-3",
                                    children: (0, i.jsx)(o.default, {
                                        className: "no-underline",
                                        href: "/jobs",
                                        style: {
                                            overflow: "hidden",
                                            whiteSpace: "nowrap"
                                        },
                                        children: "Job Board"
                                    })
                                }), (0, i.jsxs)("div", {
                                    className: "w-full inline-flex flex-row justify-end mr-5",
                                    children: [(0, i.jsx)("div", {
                                        className: "inline mr-3",
                                        children: n ? (0, i.jsx)(o.default, {
                                            className: "no-underline",
                                            href: "/employer/jobs",
                                            style: {
                                                overflow: "hidden",
                                                whiteSpace: "nowrap"
                                            },
                                            children: "Dashboard"
                                        }) : (0, i.jsx)(o.default, {
                                            className: "no-underline",
                                            href: "/employer/sign-in",
                                            style: {
                                                overflow: "hidden",
                                                whiteSpace: "nowrap"
                                            },
                                            children: "Sign In"
                                        })
                                    }), (0, i.jsx)(o.default, {
                                        className: "no-underline",
                                        href: "/employer/post-job",
                                        children: (0, i.jsx)(d.default, {
                                            onClick() {},
                                            children: "Post Job"
                                        })
                                    })]
                                })]
                            }), (0, i.jsxs)("div", {
                                className: "mobile-navbar flex md:hidden pl-3 pt-3",
                                children: [(0, i.jsx)("span", {
                                    className: "pl-3 inline-flex",
                                    children: (0, i.jsx)(o.default, {
                                        href: "/",
                                        style: {
                                            textDecoration: "none"
                                        },
                                        children: (0, i.jsx)("div", {
                                            className: "mt-2 text-center text-xl",
                                            children: "TLDR"
                                        })
                                    })
                                }), (0, i.jsx)("span", {
                                    className: "w-full inline-flex flex-row justify-end",
                                    children: (0, i.jsx)("span", {
                                        className: "z-50 flex items-center justify-center pr-3",
                                        children: (0, i.jsx)(s.default, {
                                            toggled: e,
                                            toggle: t,
                                            size: 22
                                        })
                                    })
                                })]
                            })]
                        })]
                    })
                };
            e.exports = m
        },
        76120: function(e, t, n) {
            "use strict";
            n.r(t);
            var a = n(85893),
                i = n(41664),
                o = n.n(i);
            let s = e => {
                let {
                    name: t,
                    emoji: n,
                    href: i,
                    ...s
                } = e;
                return (0, a.jsx)(o(), {
                    href: i,
                    style: {
                        textDecoration: "none"
                    },
                    children: (0, a.jsxs)("div", {
                        className: "hover-underline p-4 text-center rounded",
                        children: [(0, a.jsx)("div", {
                            className: "text-3xl",
                            style: {
                                textDecoration: "none !important"
                            },
                            children: n
                        }), (0, a.jsx)("h3", {
                            className: "card-name",
                            style: {
                                height: "60px"
                            },
                            children: t
                        })]
                    })
                })
            };
            t.default = s
        },
        45090: function(e) {
            "use strict";
            e.exports = ["Visa Sponsorship", "Health Insurance", "Life Insurance", "Vision Insurance", "Dental Insurance", "401(k)", "401(k) Matching", "Reproductive Stipend", "Health/Fitness Stipend", "Home Office/Coworking Stipend", "Education Stipend", "Child Care Stipend", "Charitable Donation Match", "Maternity/Paternity Leave", "Family Medical Leave", "Unlimited Vacation", "Paid Time Off", "4 Day Week", "Sabbatical", "Equity Compensation", "Profit Sharing", "Free Meals", "No Whiteboard Interview"]
        },
        2604: function(e) {
            "use strict";
            let t = e => {
                let [t, n] = e.split("@");
                return (["gmail.com", "googlemail.com"].includes(n) ? t.split("+")[0].split(".").join("") : t.split("+")[0]) + "@" + n
            };
            e.exports = t
        },
        95499: function(e) {
            "use strict";
            e.exports = ["Software Engineer/Developer", "Designer", "SysAdmin & DevOps", "AI, ML & Data Science", "Security", "Product Management", "Marketing", "Other"]
        },
        80005: function(e) {
            "use strict";
            e.exports = {
                company: {
                    label: "Company ‎‍\uD83D\uDCBC",
                    properties: [{
                        name: "company_name",
                        type: "text",
                        optional: !1
                    }, {
                        name: "company_description",
                        type: "textarea",
                        optional: !1
                    }, {
                        name: "company_website_url",
                        type: "text",
                        optional: !1
                    }, {
                        name: "company_size",
                        type: "select",
                        options: ["1-10 Employees", "11-50 Employees", "51-200 Employees", "201-500 Employees", "501-1,000 Employees", "5,001-10,000 Employees", "10,001+ Employees"],
                        optional: !1
                    }, {
                        name: "industry",
                        type: "multiselect",
                        options: ["Advertising", "Agency", "Apps", "Ai", "Biotech", "Clothing", "Climate", "Cloud", "Crypto", "Data", "Design", "Ecommerce", "Education", "Energy", "Finance", "Food", "Gaming", "Government", "Hardware", "Health", "Saas", "Security", "Software", "Marketing", "Media", "Real Estate", "Travel", "Hospitality"],
                        optional: !1
                    }, {
                        name: "benefits",
                        type: "multiselect",
                        options: ["Visa Sponsorship", "Health Insurance", "Life Insurance", "Vision Insurance", "Dental Insurance", "401(k)", "401(k) Matching", "Reproductive Stipend", "Health/Fitness Stipend", "Home Office/Coworking Stipend", "Education Stipend", "Child Care Stipend", "Charitable Donation Match", "Maternity/Paternity Leave", "Family Medical Leave", "Unlimited Vacation", "Paid Time Off", "4 Day Week", "Sabbatical", "Equity Compensation", "Profit Sharing", "Free Meals", "No Whiteboard Interview"],
                        optional: !1
                    }]
                }
            }
        },
        12020: function(e, t, n) {
            "use strict";
            let a = n(51706),
                i = n(99691),
                o = n(67271),
                s = n(9128),
                r = n(17563),
                l = n(2604),
                c = n(65684),
                u = n(47291),
                d = async (e, t, n, d, p) => {
                    try {
                        e = l(e);
                        let [m, h, f, {
                            data: y
                        }] = await Promise.all([o(t), s(e), i(t), a.from("readers").select().eq("email", e).limit(1).single()]);
                        if (m) throw Error("blacklisted IP: ".concat(t, ", email: ").concat(e));
                        if (!p && !h) throw Error("Invalid Email: ".concat(e));
                        n && n.includes("?") && r.parse(n.split("?")[1]);
                        let g = {
                            email: e,
                            ip: t,
                            landing_page: n,
                            city: f && f.city,
                            country: f && f.country
                        };
                        for (let b = 0; b < d.length; b++) {
                            let x = d[b];
                            g["".concat(x, "_subscribed")] = !0, g["".concat(x, "_signup_date")] = new Date().toISOString().slice(0, 10)
                        }
                        let [D, j] = await Promise.all([a.from("readers").upsert(g, {
                            onConflict: "email"
                        }).select().limit(1).single(), ...d.map((t, n) => u(e, t, 0 == n && !y))]);
                        return D
                    } catch (w) {
                        throw await c(w), Error(w)
                    }
                };
            e.exports = d
        },
        51706: function(e, t, n) {
            "use strict";
            let {
                createClient: a
            } = n(49802), i = a("https://jwwrbzsvyukwfpbuimxf.supabase.co", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp3d3JienN2eXVrd2ZwYnVpbXhmIiwicm9sZSI6ImFub24iLCJpYXQiOjE2Njc0MTMwNjcsImV4cCI6MTk4Mjk4OTA2N30.qDCRabW7g-uIEgLPijOIjMWc3_GhfFn_fopYNbtp13I");
            e.exports = i
        },
        78871: function(e, t, n) {
            "use strict";
            let a = n(95493),
                i = (e, t) => {
                    if (e.size != t.size) return !1;
                    let n = [...e],
                        a = [...t];
                    for (let i of n)
                        if (!t.has(i)) return !1;
                    for (let o of a)
                        if (!e.has(o)) return !1;
                    return !0
                },
                o = e => {
                    let t = e,
                        n = ["gmail.com", "googlemail.com", "hotmail.com", "outlook.com", "yahoo.com"],
                        o = t.split("@");
                    for (let s = 0; s < n.length; s++) {
                        let r = n[s];
                        console.log(o[1]), console.log(r), console.log(a.get(o[1], r)), 1 == a.get(o[1], r) && (!o[1].includes("mail.com") || o[1].includes("gmail.")) && (console.log(r), t = o[0] + "@" + r)
                    }
                    if (2 == a.get(o[1], "gmail.com")) {
                        let l = new Set(Array.from("gmail.com")),
                            c = new Set(Array.from(o[1]));
                        i(l, c) && (t = o[0] + "@gmail.com")
                    }
                    return t == e
                };
            e.exports = o
        },
        57902: function(e) {
            "use strict";
            e.exports = {
                employer: {
                    properties: [{
                        name: "name",
                        type: "text"
                    }, {
                        name: "job_title",
                        type: "text"
                    }]
                }
            }
        },
        99691: function(e, t, n) {
            "use strict";
            let {
                IP_INFO_KEY: a
            } = n(48091), i = async e => {
                try {
                    let t = await fetch("https://ipinfo.io/".concat(e, "?token=").concat(a));
                    return t.json()
                } catch (n) {
                    return log(n), {
                        city: "undefined",
                        country: "undefined"
                    }
                }
            };
            e.exports = i
        },
        38597: function(e, t, n) {
            "use strict";
            n.d(t, {
                BL: function() {
                    return s
                },
                Dc: function() {
                    return a
                },
                KA: function() {
                    return o
                },
                PE: function() {
                    return r
                },
                lp: function() {
                    return i
                },
                r7: function() {
                    return l
                }
            });
            let a = n(37679);
            n(51706), n(12020), n(65684);
            let i = n(78871),
                o = n(32322);
            n(83047), n(47291), n(88416), n(49708), n(18994), n(35307), n(13665), n(45090), n(95499), n(91084);
            let s = n(47295),
                r = n(57902),
                l = n(80005);
            n(67888), n(67983)
        },
        49708: function(e, t, n) {
            "use strict";
            let a = n(43726);
            n(83047);
            let i = n(37679);
            n(65684);
            let o = n(51706),
                {
                    EMAIL_OCTOPUS_KEY: s
                } = n(48091),
                r = e => a(e, ["li", "ul", "a", "p"]),
                l = async (e, t) => {
                    let n, a;
                    await i(100);
                    let l = e.id,
                        c = new Date(e.sent_at).toISOString().slice(0, 10),
                        {
                            error: u
                        } = await o.from("campaigns").upsert({
                            subject: e.subject,
                            date: c,
                            eo_id: e.id,
                            newsletter: t
                        }, {
                            onConflict: "date,newsletter"
                        });
                    if (u) throw Error(u);
                    let d = await fetch("https://emailoctopus.com/api/1.5/campaigns/".concat(l, "?api_key=").concat(s));
                    if (!d.ok) throw Error("Problem fetching ".concat(l, " for ").concat(t, ", message: ").concat(d.status));
                    let {
                        content: {
                            html: p
                        }
                    } = await d.json();
                    "tech" == t ? (n = ["<strong>Big Tech", "Futuristic Technology", "Programming, Design", "Miscellaneous", "Quick Links"], a = ["sponsor", "big", "future", "programming", "miscellaneous", "quick"]) : "crypto" == t && (n = ["<strong>Markets", "<strong>Innovation", "<strong>Guides", "Miscellaneous", "Quick Links"], a = ["cryptosponsor", "markets", "innovation", "guides", "crypto", "cryptoquick"]);
                    let m = [];
                    for (let h = 0; h < n.length + 1; h++) {
                        let f;
                        f = 0 == h ? p.split(n[h])[0] : h == n.length + 1 ? p.split(n[h - 1])[1] : p.split(n[h - 1])[1].split(n[h])[0], m.push(f)
                    }
                    for (let y = 0; y < m.length; y++) {
                        let g = m[y].split('<span><a href="').slice(1);
                        for (let b = 0; b < g.length; b++) {
                            let x = g[b],
                                D = x.split('"')[0].trim(),
                                j = r(x.split(">").slice(1).join(">").split(")")[0].trim()) + ")",
                                w = r(x.split("</a>").slice(1).join("</a>").split("</span></span>")[0]).trim(),
                                S = a[y];
                            e.id;
                            let {
                                error: v
                            } = await o.from("stories").upsert({
                                url: D,
                                title: j,
                                tldr: w,
                                date: c,
                                category: S,
                                newsletter: t
                            }, {
                                onConflict: "url,date,newsletter"
                            });
                            if (v) throw Error(v)
                        }
                    }
                };
            e.exports = l
        },
        67271: function(e, t, n) {
            "use strict";
            let a = n(51706),
                i = async e => {
                    if ("::1" == e) return !1;
                    let t = await a.from("blacklisted_ips").select().eq("ip", e);
                    return t.data.length > 0
                };
            e.exports = i
        },
        9128: function(e, t, n) {
            "use strict";
            let {
                ZERO_BOUNCE_KEY: a
            } = n(48091), i = async e => {
                let t = e.split("@")[1];
                if (["hotmail.", "outlook.", "msn.", "aol.", "live.", "comcast.net", "posteo.de", "gmx.de", "web.de", "free.fr"].some(e => t.startsWith(e))) {
                    let n = await fetch("https://api.zerobounce.net/v2/validate?api_key=".concat(a, "&email=").concat(e)),
                        {
                            status: i
                        } = await n.json();
                    if (!["valid", "catch-all", "unknown"].includes(i)) return !1
                }
                return !0
            };
            e.exports = i
        },
        47295: function(e) {
            "use strict";
            e.exports = {
                job_title: {
                    label: "Job \uD83D\uDC68‍\uD83D\uDCBB ",
                    properties: [{
                        name: "employment_type",
                        type: "select",
                        options: ["Full Time", "Part Time", "Contractor", "Intern"],
                        optional: !1
                    }, {
                        name: "compensation_type",
                        type: "select",
                        options: ["Salary", "Hourly"],
                        optional: !1
                    }, {
                        name: "seniority",
                        type: "select",
                        options: ["Executive", "Manager", "Senior", "Junior"],
                        optional: !1
                    }, {
                        name: "job_category",
                        type: "select",
                        options: ["Software Engineer/Developer", "Designer", "SysAdmin & DevOps", "AI, ML & Data Science", "Security", "Product Management", "Marketing", "Sales", "Operations", "Other"],
                        optional: !1
                    }, {
                        name: "job_title",
                        type: "text",
                        optional: !1
                    }, {
                        name: "job_description",
                        type: "textarea",
                        optional: !1
                    }, {
                        name: "ideal_candidate_description",
                        type: "textarea",
                        optional: !1
                    }, {
                        name: "job_application_details",
                        type: "textarea",
                        optional: !0
                    }, {
                        name: "job_application_email_or_url",
                        type: "text",
                        optional: !1
                    }, {
                        label: "Minimum Years Experience",
                        name: "years_experience_min",
                        type: "number",
                        optional: !0
                    }, {
                        label: "Maximum Years Experience",
                        name: "years_experience_max",
                        type: "number",
                        optional: !0
                    }]
                },
                compensation: {
                    label: "Pay \uD83D\uDCB0",
                    properties: [{
                        label: "Total Annual Compensation Min (USD)",
                        name: "annual_compensation_range_min",
                        type: "number",
                        optional: !0
                    }, {
                        label: "Total Annual Compensation Max (USD)",
                        name: "annual_compensation_range_max",
                        type: "number",
                        optional: !0
                    }, {
                        label: "Hourly Compensation Min (USD/Hour)",
                        name: "hourly_compensation_range_min",
                        type: "number",
                        optional: !0
                    }, {
                        label: "Hourly Compensation Max (USD/Hour)",
                        name: "hourly_compensation_range_max",
                        type: "number",
                        optional: !0
                    }]
                },
                location: {
                    label: "Location \uD83C\uDF0E",
                    properties: [{
                        name: "remote_policy",
                        type: "select",
                        options: ["Fully Remote All Time Zones", "Full Remote Certain Time Zones", "Hybrid/Remote Part Time", "Fully In Person"],
                        optional: !1
                    }, {
                        name: "location",
                        type: "location",
                        optional: !1
                    }]
                },
                technology: {
                    label: "Tech \uD83D\uDC68‍\uD83D\uDCBB",
                    properties: [{
                        name: "technologies",
                        type: "multiselect",
                        options: ["JavaScript", "HTML", "CSS", "SQL", "Python", "TypeScript", "Java", "Bash", "C#", "C++", "PHP", "C", "PowerShell", "Go", "Rust", "Kotlin", "Dart", "Ruby", "Assembly", "Swift", "R", "VBA", "MATLAB", "Lua", "Groovy", "Delphi", "Scala", "Objective-C", "Perl", "Haskell", "Elixir", "Julia", "Clojure", "Solidity", "LISP", "F#", "Fortran", "Erlang", "APL", "COBOL", "SAS", "OCaml", "Crystal", "MySQL", "PostgreSQL", "SQLite", "MongoDB", "Microsoft SQL Server", "Redis", "MariaDB", "Elasticsearch", "Oracle", "Firebase Realtime Database", "DynamoDB", "Cloud Firestore", "Cassandra", "Neo4j", "IBM DB2", "Couchbase", "CouchDB", "AWS", "Microsoft Azure", "Google Cloud", "Firebase", "Heroku", "DigitalOcean", "VMware", "Managed Hosting", "Linode", "OVH", "Oracle Cloud Infrastructure", "OpenStack", "IBM Cloud", "Node.js", "React.js", "jQuery", "Express", "Angular", "Vue.js", "Bootstrap", "Tailwind CSS", "Foundation", "Bulma", "Skeleton", "UIkit", "Primer", "Material Design", "ASP.NET Core", "ASP.NET", "Django", "Flask", "Next.js", "Laravel", "Angular.js", "FastAPI", "Ruby on Rails", "Svelte", "Blazor", "Nuxt.js", "Symfony", "Gatsby", "Drupal", "Phoenix", "Fastify", "Deno", "Play Framework", ".NET", "NumPy", "Pandas", "Spring", "TensorFlow", "Flutter", "Scikit-learn", "React Native", "Apache Kafka", "Electron", "Torch/PyTorch", "Qt", "Keras", "Ionic", "Xamarin", "Apache Spark", "Cordova", "Hadoop", "GTK", "Capacitor", "Tidyverse", "Hugging Face Transformers", "Uno Platform", "npm", "Docker", "Yarn", "Homebrew", "Kubernetes", "Terraform", "Unity 3D", "Ansible", "Unreal Engine", "Puppet", "Chef", "Pulumi", "Flow", "Supabase"],
                        optional: !0
                    }]
                }
            }
        },
        67983: function(e) {
            "use strict";
            e.exports = "id, employment_type, job_title, job_description, ideal_candidate_description, job_application_details, job_application_email_or_url, annual_compensation_range_min, annual_compensation_range_max, hourly_compensation_range_min, hourly_compensation_range_max, years_experience_min, years_experience_max, remote_policy, location, technologies, created_at, companies(company_name, company_size, company_logo_url, company_description, industry, benefits);"
        },
        65684: function(e, t, n) {
            "use strict";
            let a;
            let i = n(39219),
                {
                    MEZMO_KEY: o
                } = n(48091),
                s = i.createLogger(o);
            a = (e, t) => {
                let n;
                n = e && e.toString ? e.toString() : JSON.stringify(e), e && e.stack && (n += e.stack), t ? s.log(n, t) : s.log(n, "error")
            }, e.exports = a
        },
        83047: function(e) {
            "use strict";
            let t = {
                    tech: "cfa2d55a-b7be-11e8-a3c9-06b79b628af2",
                    crypto: "514b3efb-6f16-11ec-96e5-06b4694bee2a",
                    ai: "eedf6b14-3de3-11ed-9a32-0241b9615763",
                    design: "e1c4e253-3e90-11ed-9a32-0241b9615763",
                    engineering: "e8d201ca-3e93-11ed-9a32-0241b9615763",
                    marketing: "7dbdbdcb-3e94-11ed-9a32-0241b9615763",
                    cybersecurity: "8d9cea11-3e94-11ed-9a32-0241b9615763",
                    product: "c8e26b12-3e94-11ed-9a32-0241b9615763",
                    founders: "33bb36cf-4024-11ed-9a32-0241b9615763"
                },
                n = e => t[e];
            e.exports = n
        },
        32322: function(e) {
            "use strict";
            let t = e => "tech" == e ? "TLDR" : "engineering" == e ? "TLDR Web Dev" : "design" == e ? "TLDR Design" : "ai" == e ? "TLDR AI" : "marketing" == e ? "TLDR Marketing" : "crypto" == e ? "TLDR Crypto" : "cybersecurity" == e ? "TLDR Cybersecurity" : "product" == e ? "TLDR Product Management" : "founders" == e ? "TLDR Founders" : void 0;
            e.exports = t
        },
        98562: function(e, t, n) {
            "use strict";
            let a = n(83047),
                i = e => "https://emailoctopus.com/api/1.6/lists/".concat(a(e));
            e.exports = i
        },
        35307: function(e) {
            "use strict";
            e.exports = ["tech", "crypto", "ai", "cybersecurity", "engineering", "design", "product", "marketing", "founders"]
        },
        48091: function(e) {
            "use strict";
            e.exports = {
                ZERO_BOUNCE_KEY: "cd6c09dc9972432ba50a91d186bb3d9e",
                AWS_ACCESS_KEY_ID: "AKIAIGTWDAUVSZKVRICQ",
                AWS_SECRET_ACCESS_KEY: "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",
                POSTMARK_KEY: "79de660a-14a8-42d4-870d-8931ed730610",
                IP_INFO_KEY: "96e0ffe5fa2b1a",
                MEZMO_KEY: "4c23665ce5d21af2b1b10344aaa53ad4",
                EMAIL_OCTOPUS_KEY: "38862674-1b90-43b5-a987-ea0345ad0f8f"
            }
        },
        93033: function(e, t, n) {
            "use strict";
            let a = n(31646),
                i = n(65684),
                o = n(32322),
                s = (e, t, n) => {
                    let a = o(t);
                    return '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html>\n	<head>\n		<title>Thanks for subscribing!</title>\n	</head>\n	<body>\n\n\n		<div class="main" style="max-width:700px; margin: 0 auto; padding: 15px; font-family: Arial, Helvetica, sans-serif;">\n      <p style="font-size: 16px;"><b>Welcome to '.concat(a, ", thank you so much for subscribing!</b></p>\n\n      ").concat(n ? '<p style="font-size: 16px;">To complete your signup:</p>\n      <p style="font-size: 16px;">1) <b>Reply \'OK\' to this email.</b> (You can skip this step if you\'re signing up an RSS reader, Google Group, or Slack Group you are automatically verified).</p> \n      <p style="font-size: 16px;">2) If this email is in the spam or promotions folder make sure to <b>move it to your primary inbox.</b> Here\'s how to do it:</p>\n<p><b>For Gmail on your phone:</b> Hit the 3 dots at top right corner, click "Move to" then "Primary."</p>\n<p><b>For Gmail on your computer:</b> Back out of this email then drag and drop this email into the "Primary" tab near the top left of your screen.</p>\n<p><b>For Apple mail users:</b> Tap on our email address at the top of this email (next to "From:" on mobile) and click "Add to VIPs."</p>\n<p><b>For everyone else:</b> <a href="https://help.aweber.com/hc/en-us/articles/204029246">Please follow these instructions</a>.</p>' : "", '\n<br>\n\n      <p style="font-size: 16px;"><b>Want more TLDR? \uD83E\uDDE0</b></p>\n      <p style="font-size: 16px;">In addition to ').concat(a, ", we also write newsletters for specific jobs and\n      industries within tech.</p>\n      ").concat("tech" !== t ? '<p style="font-size: 16px;"><a href="'.concat("https://signup.tldr.tech", "?email=").concat(e, '"><b>TLDR</b></a> - TLDR is our flagship newsletter with over half a million subscribers covering the most interesting news in startups, tech and programming.</p>') : "", "\n      ").concat("engineering" !== t ? '<p style="font-size: 16px;"><a href="'.concat("https://signup.tldr.tech", "/engineering?email=").concat(e, '"><b>TLDR Web Dev</b></a> - Deep dives and resources for frontend and backend web development</p>') : "", "\n      ").concat("ai" !== t ? '<p style="font-size: 16px;"><a href="'.concat("https://signup.tldr.tech", "/ai?email=").concat(e, '"><b>TLDR AI</b></a> - News, research, and tools for AI, machine learning, and data science</p>') : "", "\n      ").concat("crypto" !== t ? '<p style="font-size: 16px;"><a href="'.concat("https://signup.tldr.tech", "/crypto?email=").concat(e, '"><b>TLDR Crypto</b></a> - Innovations and launches in crypto and web3.</p>') : "", "\n      ").concat("cybersecurity" !== t ? '<p style="font-size: 16px;"><a href="'.concat("https://signup.tldr.tech", "/cybersecurity?email=").concat(e, '"><b>TLDR Cybersecurity</b></a> - Curated news, research, and tools for information security professionals</p>') : "", "\n      ").concat("product" !== t ? '<p style="font-size: 16px;"><a href="'.concat("https://signup.tldr.tech", "/product?email=").concat(e, '"><b>TLDR Product Management</b></a> - Deep dives, trends, and resources for effective product managers.</p>') : "", "\n      ").concat("marketing" !== t ? '<p style="font-size: 16px;"><a href="'.concat("https://signup.tldr.tech", "/marketing?email=").concat(e, '"><b>TLDR Marketing</b></a> - Curated tactics, trends, and tools for cutting edge marketers</p>') : "", "\n      ").concat("design" !== t ? '<p style="font-size: 16px;"><a href="'.concat("https://signup.tldr.tech", "/design?email=").concat(e, '"><b>TLDR Design</b></a> - Curated tools, trends, and inspiration for UI/UX and front-end designers</p>') : "", "\n      ").concat("founders" !== t ? '<p style="font-size: 16px;"><a href="'.concat("https://signup.tldr.tech", "/founders?email=").concat(e, '"><b>TLDR Founders</b></a> - Curated tools, trends, and tactics for startup founders and entrepreneurs</p>') : "", "\n      <br>\n      ").concat(["tech", "crypto"].includes(t) ? '\n          <p style="font-size: 16px;">\n            If you\'d like to see what you\'ve been missing out on, <a href="'.concat("https://signup.tldr.tech", "/").concat(t, '/latest">check out the latest issue of ').concat(a, "</a>.\n          </p>\n        ") : "", '\n      <br>\n\n      <p style="font-size: 16px;">Dan, Founder of TLDR</p>\n      <br>\n      <p style="font-size: 16px;">PS: If you didn\'t subscribe to ').concat(a, ', please <a href="').concat("https://signup.tldr.tech", "/api/unsubscribe/").concat(t, "?email=").concat(e, '">click here</a> to unsubscribe.</p>\n		</div>\n	</body>\n</html>')
                },
                r = async (e, t, n) => {
                    try {
                        a("TLDR <dan@tldrnewsletter.com>", e, "Confirm your ".concat(o(t), " sign up! \uD83C\uDF89"), s(e, t, n))
                    } catch (r) {
                        await i(r)
                    }
                };
            e.exports = r
        },
        91084: function(e) {
            "use strict";
            e.exports = ["Executive", "Manager", "Senior", "Junior"]
        },
        31646: function(e, t, n) {
            "use strict";
            let {
                AWS_ACCESS_KEY_ID: a,
                AWS_SECRET_ACCESS_KEY: i
            } = n(48091), o = n(98690), s = new o.SES({
                accessKeyId: a,
                secretAccessKey: i,
                region: "us-east-1"
            }), r = (e, t, n, a) => s.sendEmail({
                Source: e,
                Destination: {
                    ToAddresses: [t]
                },
                ReplyToAddresses: [],
                Message: {
                    Body: {
                        Html: {
                            Charset: "UTF-8",
                            Data: a
                        }
                    },
                    Subject: {
                        Charset: "UTF-8",
                        Data: n
                    }
                }
            }).promise();
            e.exports = r
        },
        47291: function(e, t, n) {
            "use strict";
            let a = n(93033);
            n(51706);
            let i = n(2568),
                o = n(98562),
                s = n(65684),
                {
                    EMAIL_OCTOPUS_KEY: r
                } = n(48091),
                l = async (e, t, n) => {
                    try {
                        try {
                            let [l, c] = await Promise.allSettled([fetch("".concat(o(t), "/contacts"), {
                                method: "POST",
                                headers: {
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify({
                                    api_key: r,
                                    email_address: e.toLowerCase(),
                                    status: "SUBSCRIBED",
                                    fields: {}
                                })
                            }), a(e, t, n)]);
                            if (!l.ok) throw Error("User exists")
                        } catch (d) {
                            let u = await fetch("".concat(o(t), "/contacts/").concat(i(e.toLowerCase())), {
                                method: "PUT",
                                headers: {
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify({
                                    api_key: r,
                                    status: "SUBSCRIBED"
                                })
                            });
                            u.ok || console.log("Problem signing up ".concat(e, " for ").concat(t, ", status: ").concat(u.status))
                        }
                    } catch (p) {
                        await s(p)
                    }
                };
            e.exports = l
        },
        13665: function(e) {
            "use strict";
            e.exports = ["JavaScript", "HTML", "CSS", "SQL", "Python", "TypeScript", "Java", "Bash", "C#", "C++", "PHP", "C", "PowerShell", "Go", "Rust", "Kotlin", "Dart", "Ruby", "Assembly", "Swift", "R", "VBA", "MATLAB", "Lua", "Groovy", "Delphi", "Scala", "Objective-C", "Perl", "Haskell", "Elixir", "Julia", "Clojure", "Solidity", "LISP", "F#", "Fortran", "Erlang", "APL", "COBOL", "SAS", "OCaml", "Crystal", "MySQL", "PostgreSQL", "SQLite", "MongoDB", "Microsoft SQL Server", "Redis", "MariaDB", "Elasticsearch", "Oracle", "Firebase Realtime Database", "DynamoDB", "Cloud Firestore", "Cassandra", "Neo4j", "IBM DB2", "Couchbase", "CouchDB", "AWS", "Microsoft Azure", "Google Cloud", "Firebase", "Heroku", "DigitalOcean", "VMware", "Managed Hosting", "Linode", "OVH", "Oracle Cloud Infrastructure", "OpenStack", "IBM Cloud", "Node.js", "React.js", "jQuery", "Express", "Angular", "Vue.js", "Bootstrap", "Tailwind CSS", "Foundation", "Bulma", "Skeleton", "UIkit", "Primer", "Material Design", "ASP.NET Core", "ASP.NET", "Django", "Flask", "Next.js", "Laravel", "Angular.js", "FastAPI", "Ruby on Rails", "Svelte", "Blazor", "Nuxt.js", "Symfony", "Gatsby", "Drupal", "Phoenix", "Fastify", "Deno", "Play Framework", ".NET", "NumPy", "Pandas", "Spring", "TensorFlow", "Flutter", "Scikit-learn", "React Native", "Apache Kafka", "Electron", "Torch/PyTorch", "Qt", "Keras", "Ionic", "Xamarin", "Apache Spark", "Cordova", "Hadoop", "GTK", "Capacitor", "Tidyverse", "Hugging Face Transformers", "Uno Platform", "npm", "Docker", "Yarn", "Homebrew", "Kubernetes", "Terraform", "Unity 3D", "Ansible", "Unreal Engine", "Puppet", "Chef", "Pulumi", "Flow", "Supabase"]
        },
        88416: function(e, t, n) {
            "use strict";
            let a = n(35307),
                i = n(18994),
                o = n(65684),
                s = async e => {
                    try {
                        for (let t of a) e["".concat(t, "_subscribed")] && await i(e.email, t)
                    } catch (n) {
                        await o(n)
                    }
                };
            e.exports = s
        },
        18994: function(e, t, n) {
            "use strict";
            let a = n(51706),
                i = n(2568),
                o = n(98562),
                s = n(65684),
                {
                    EMAIL_OCTOPUS_KEY: r
                } = n(48091),
                l = async (e, t) => {
                    try {
                        let n = await fetch("".concat(o(t), "/contacts/").concat(i(e.toLowerCase())), {
                            method: "PUT",
                            headers: {
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                api_key: r,
                                status: "UNSUBSCRIBED",
                                fields: {}
                            })
                        });
                        if (!n.ok) {
                            let l = await n.json();
                            throw Error("Problem unsubscribing ".concat(e, " for ").concat(t, ", message: ").concat(l))
                        }
                        let c = {};
                        c["".concat(t, "_subscribed")] = !1, await a.from("readers").update(c).match({
                            email: e
                        })
                    } catch (u) {
                        await s(u)
                    }
                };
            e.exports = l
        },
        67888: function(e, t, n) {
            "use strict";
            let a = n(47295),
                i = n(80005),
                o = [...Object.keys(a), ...Object.keys(i)],
                s = {};
            for (let r = 0; r < o.length; r++) {
                let l;
                let c = o[r],
                    u = !1;
                a[c] ? l = a[c] : (l = i[c], u = !0);
                for (let d = 0; d < l.properties.length; d++) s[l.properties[d].name] = {
                    type: l.properties[d].type,
                    companyField: u
                }
            }
            e.exports = s
        },
        37679: function(e) {
            "use strict";
            let t = e => new Promise(t => setTimeout(() => t("done waiting"), e));
            e.exports = t
        },
        28022: function() {}
    }
]);